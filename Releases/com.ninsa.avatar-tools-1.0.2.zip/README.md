# NINSA Avatar Tools

Includes Avatar Toggle Manager and Avatar Dynamics Overhaul as one compiled Editor DLL.

## Requirements

- Unity 2022.3 (built with Unity 2022.3.22f1).
- VRChat Avatar SDK 3.10.5 or newer, installed with VRChat Creator Companion.

## Install

1. Close the receiving Unity project.
2. Copy the entire `com.ninsa.avatar-tools` folder into that project's `Packages` folder.
3. Open the project and allow Unity to import the package.
4. Open the tools from the NINSA menu.

The final layout should be:

```text
Packages/
  com.ninsa.avatar-tools/
    package.json
    README.md
    Editor/
      Ninsa.AvatarTools.Editor.dll
      Ninsa.AvatarTools.Editor.dll.meta
```

Install only one copy of NINSA Avatar Tools in a project. The DLL package and the original C# scripts define the same classes and assembly, so they must not be installed together.

This package contains the tool DLL only. Unity and VRChat SDK libraries are supplied by the receiving project.

## License

A valid Gumroad license key is required to use the NINSA tools. Enter the key from your Gumroad receipt when prompted. The key is checked with Gumroad and reverified every seven days; verification does not increase its use count.

## Updating this package

The package is a snapshot of the compiled tool. After editing the original scripts, wait for Unity to compile successfully, then run `Update-Package.ps1` in the enclosing `PackageBuild~` folder. Copy the refreshed package into the receiving project's `Packages` folder to update it.
