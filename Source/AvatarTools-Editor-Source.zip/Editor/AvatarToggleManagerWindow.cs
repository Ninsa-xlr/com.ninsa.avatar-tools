using UnityEngine;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine.Animations;
using UnityEngine.Playables;
using System.Collections.Generic;
using System;
using System.IO;
using System.Linq;

using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDK3.Dynamics.PhysBone.Components;
using VRC.SDKBase;

namespace Ninsa.AvatarToggleManager.Editor
{
    public class AvatarToggleManagerWindow : EditorWindow
    {
        private enum MainTab
        {
            EditToggles,
            CreateToggle,
            FxAnalysis,
            Backups,
            PhysBones,
            Settings
        }

        public enum ToggleFilterType
        {
            All,
            GameObject,
            BlendShape,
            MaterialProperty,
            IntState,
            FloatState
        }

        private MainTab currentTab = MainTab.EditToggles;
        private ToggleFilterType currentToggleFilter = ToggleFilterType.All;
        private Vector2 scrollPosition;
        private bool radialPreviewMode = true;
        private AnimationClip previewAnimationClip;
        private float previewAnimationTime;
        private bool ownsAnimationPreviewMode;
        private PlayableGraph parameterPreviewGraph;
        private AnimatorControllerPlayable parameterPreviewController;
        private GameObject parameterPreviewAvatar;
        private Animator parameterPreviewAnimator;
        private HumanPoseHandler parameterPreviewHumanPoseHandler;
        private HumanPose parameterPreviewTPose;
        private AnimationClip parameterPreviewTPoseClip;
        private AnimationClipPlayable parameterPreviewTPosePlayable;
        private AvatarMask parameterPreviewTPoseMask;
        private bool parameterPreviewHasTPose;
        private string parameterPreviewPoseWarning;
        private readonly Dictionary<Transform, Vector3> previewRigPositions = new Dictionary<Transform, Vector3>();
        private readonly Dictionary<Transform, Vector3> previewRigScales = new Dictionary<Transform, Vector3>();
        private Quaternion previewRootRotation;
        private Quaternion previewAnimatorRootRotation;
        private readonly HashSet<ClothingToggleData> previewSessionToggles = new HashSet<ClothingToggleData>();
        private readonly HashSet<ClothingToggleData> previewEnabledToggles = new HashSet<ClothingToggleData>();
        private readonly Dictionary<Renderer, bool> parameterPreviewRendererStates = new Dictionary<Renderer, bool>();
        private double lastParameterPreviewUpdateTime;
        private readonly Dictionary<string, float> parameterPreviewValues = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase);
        private string parameterPreviewStatus;

        // --- Avatar Reference ---
        private VRCAvatarDescriptor avatarDescriptor; 
        private string avatarName = "No Avatar Selected";

        // --- Create Toggle State ---
        private string newToggleName = "New Clothing Toggle";
        private GameObject targetClothingObject;
        
        private bool enableOnOff = true;
        
        private bool enableBlendShape = false;
        private SkinnedMeshRenderer targetSkinnedMesh;
        private string blendShapeName = "";
        private float blendShapeOnValue = 100f;
        private float blendShapeOffValue = 0f;

        private bool enableMaterialProperty = false;
        private Renderer targetRenderer;
        private int materialIndex = 0;
        private string materialPropertyName = "_Dissolve";
        private AvatarToggleManagerWindow.MaterialPropertyType materialPropertyType = AvatarToggleManagerWindow.MaterialPropertyType.Float;
        private float matFloatOn = 1f;
        private float matFloatOff = 0f;
        private Color matColorOn = Color.white;
        private Color matColorOff = Color.black;

        private bool enableIntState = false;
        private int intStateValue = 1;
        private string intParameterName = "";

        private string createMenuPath = "Root";

        // --- Edit Toggles State ---
        private List<ClothingToggleData> detectedToggles = new List<ClothingToggleData>();
        private ClothingToggleData previewedToggle;
        private bool showMultiDeletePreview = false;
        private Vector2 deletionObjectListScroll;
        private Vector2 deletionBlacklistScroll;
        private List<GameObject> previewLinkedObjects = new List<GameObject>();
        private List<GameObject> previewObjectsToDelete = new List<GameObject>();
        private HashSet<GameObject> previewDeleteEligibleObjects = new HashSet<GameObject>();
        private HashSet<GameObject> previewObjectsToKeep = new HashSet<GameObject>();
        private readonly Dictionary<GameObject, bool> selectedToggleObjectOriginalActiveStates = new Dictionary<GameObject, bool>();
        private int previewLinkedObjectCount;
        private int previewRetainedObjectCount;
        private bool forceDeleteLinkedObjects;
        private bool useRadialView = true;

        // --- Radial Menu State & Smooth Animation ---
        private VRCExpressionsMenu currentRadialMenu;
        private Stack<VRCExpressionsMenu> menuHistory = new Stack<VRCExpressionsMenu>();
        private Stack<string> menuPathHistory = new Stack<string>();
        private string currentRadialMenuPath = "Root";
        
        private float[] sliceAnimWeights = new float[8];
        private float lastFrameTime;

        // --- FX Analysis State ---
        private AnimatorController fxController;
        private List<string> scannedFxParameters = new List<string>();
        private List<string> scannedFxLayers = new List<string>();
        private List<string> scannedFxConditions = new List<string>();
        private bool isFxScanned = false;

        // --- Backups State ---
        private List<string> availableBackups = new List<string>();

        // --- PhysBones State ---
        private List<VRCPhysBone> detectedPhysBones = new List<VRCPhysBone>();
        private Dictionary<int, global::UnityEditor.Editor> physBoneEditors = new Dictionary<int, global::UnityEditor.Editor>();
        private HashSet<int> expandedPhysBones = new HashSet<int>();
        private string physBoneSearch = "";

        // --- Settings State (Persistent via EditorPrefs) ---
        private bool settingCreateBackupBeforeChanges = true;
        private bool settingAllowFxModifications = false; 
        private bool settingScanFxControllers = true;
        
        private bool settingHighlightSelectedAsset = true;
        private Color settingHighlightColor = Color.green;
        private bool settingSelectDeletePreviewObject = true;
        private bool settingZoomToSelectedObject = true;
        private List<string> deletionBlacklistIds = new List<string>();

        // --- Radial Menu Custom Colors ---
        private Color radialBgColor = new Color(0.12f, 0.17f, 0.2f, 1f);
        private Color radialHoverColor = new Color(0.18f, 0.28f, 0.33f, 1f);
        private Color radialLineColor = new Color(0.13f, 0.35f, 0.4f, 1f);
        private Color radialDeleteColor = new Color(0.45f, 0.15f, 0.15f, 1f);

        public enum MaterialPropertyType
        {
            Float,
            Range,
            Color,
            Alpha,
            Emission
        }

        [Serializable]
        public class ClothingToggleData
        {
            public string toggleName;
            public string controlType;
            public GameObject clothingObject;
            public string menuPath;
            public string parameterName;
            public List<string> parameterNames = new List<string>();
            public List<string> parameterTypes = new List<string>();
            public List<AnimationClip> relatedClips = new List<AnimationClip>();
            public List<string> transitionRules = new List<string>();
            public float menuControlValue;
            public bool hasOnOff;
            public bool hasBlendShape;
            public bool hasMaterialProperty;
            public bool hasIntState;
            public bool hasFloatState;
            public List<GameObject> animatedObjects = new List<GameObject>();
            public List<string> sharedParameters = new List<string>();
            
            public VRCExpressionsMenu sourceMenu;
            public VRCExpressionsMenu.Control sourceControl;

            public bool isSelectedForRemoval = false;
            public bool isExpanded = false;
        }

        private sealed class MenuOption
        {
            public VRCExpressionsMenu menu;
            public string path;
        }

        [MenuItem("NINSA/Avatar Toggle Manager")]
        [MenuItem("Window/NINSA/Avatar Toggle Manager")]
        public static void ShowWindow()
        {
            var window = GetWindow<AvatarToggleManagerWindow>("Avatar Toggle Manager");
            window.minSize = new Vector2(720, 620);
            window.titleContent = new GUIContent("Avatar Toggles");
            window.wantsMouseMove = true; 
            window.Show();
        }

        private void OnEnable()
        {
            SceneView.duringSceneGui += OnSceneGUI;
            EditorSceneManager.sceneSaving += OnSceneSaving;
            EditorApplication.update += UpdateParameterPreviewGraph;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            VRC_AvatarParameterDriver.OnApplySettings += OnPreviewParameterDriverSettings;
            LoadSettings();
            RefreshBackupList();
            wantsMouseMove = true;
            lastFrameTime = (float)EditorApplication.timeSinceStartup;
        }

        private void OnDisable()
        {
            EditorSceneManager.sceneSaving -= OnSceneSaving;
            EditorApplication.update -= UpdateParameterPreviewGraph;
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            VRC_AvatarParameterDriver.OnApplySettings -= OnPreviewParameterDriverSettings;
            StopAnimationClipPreview();
            ClearParameterPreviewState();
            RestoreSelectedToggleObjectActiveStates();
            SceneView.duringSceneGui -= OnSceneGUI;
            ReleasePhysBoneEditors();
            SaveSettings();
        }

        private void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state != PlayModeStateChange.ExitingEditMode) return;
            StopAnimationClipPreview();
            previewedToggle = null;
            ClearParameterPreviewState();
            RestoreSelectedToggleObjectActiveStates();
            Repaint();
        }

        private void OnSceneSaving(UnityEngine.SceneManagement.Scene scene, string path)
        {
            if (avatarDescriptor == null || avatarDescriptor.gameObject.scene != scene) return;
            StopAnimationClipPreview();
            previewedToggle = null;
            ClearParameterPreviewState();
            RestoreSelectedToggleObjectActiveStates();
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!settingHighlightSelectedAsset || currentTab != MainTab.EditToggles) return;

            foreach (var toggle in detectedToggles)
            {
                if (toggle.isExpanded || previewedToggle == toggle || IsTogglePreviewActive(toggle))
                {
                    Handles.color = settingHighlightColor;
                    foreach (GameObject linkedObject in GetToggleLinkedObjects(toggle))
                    {
                        foreach (Renderer renderer in linkedObject.GetComponentsInChildren<Renderer>())
                            Handles.DrawWireCube(renderer.bounds.center, renderer.bounds.size);
                    }
                }
            }
            sceneView.Repaint();
        }

        private void OnGUI()
        {
            DrawHeader();
            DrawToolbar();

            scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition);
            {
                EditorGUILayout.Space(8);
                EditorGUILayout.BeginVertical(new GUIStyle(EditorStyles.helpBox) { padding = new RectOffset(10, 10, 10, 10) });
                {
                    switch (currentTab)
                    {
                        case MainTab.EditToggles:
                            DrawEditTogglesTab();
                            break;
                        case MainTab.CreateToggle:
                            DrawCreateToggleTab();
                            break;
                        case MainTab.FxAnalysis:
                            DrawFxAnalysisTab();
                            break;
                        case MainTab.Backups:
                            DrawBackupsTab();
                            break;
                        case MainTab.PhysBones:
                            DrawPhysBonesTab();
                            break;
                        case MainTab.Settings:
                            DrawSettingsTab();
                            break;
                    }
                }
                EditorGUILayout.EndVertical();
                EditorGUILayout.Space(12);
            }
            EditorGUILayout.EndScrollView();
        }

        private void DrawHeader()
        {
            EditorGUILayout.Space(8);
            EditorGUILayout.BeginVertical(new GUIStyle(EditorStyles.helpBox) { padding = new RectOffset(14, 14, 12, 12) });
            {
                EditorGUILayout.BeginHorizontal();
                {
                    EditorGUILayout.BeginVertical();
                    {
                        GUIStyle titleStyle = new GUIStyle(EditorStyles.boldLabel)
                        {
                            fontSize = 20,
                            alignment = TextAnchor.MiddleLeft
                        };
                        GUILayout.Label("Avatar Toggle Manager", titleStyle, GUILayout.Height(28));
                        GUILayout.Label("Create and manage VRChat expression toggles", EditorStyles.miniLabel);
                    }
                    EditorGUILayout.EndVertical();
                    GUILayout.FlexibleSpace();
                    GUIStyle badgeStyle = new GUIStyle(EditorStyles.helpBox)
                    {
                        alignment = TextAnchor.MiddleCenter,
                        fontStyle = FontStyle.Bold,
                        padding = new RectOffset(10, 10, 5, 5)
                    };
                    GUILayout.Label("NINSA  •  SDK3", badgeStyle, GUILayout.Height(34));
                }
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.Space(10);

                EditorGUI.BeginChangeCheck();
                avatarDescriptor = (VRCAvatarDescriptor)EditorGUILayout.ObjectField(
                    new GUIContent("Avatar", "Assign the avatar you want to manage"),
                    avatarDescriptor, typeof(VRCAvatarDescriptor), true);
                if (EditorGUI.EndChangeCheck())
                {
                    ReleasePhysBoneEditors();
                    if (avatarDescriptor != null)
                    {
                        avatarName = avatarDescriptor.gameObject.name;
                        ScanAvatarData();
                        ScanPhysBones();
                    }
                    else
                    {
                        StopAnimationClipPreview();
                        RestoreSelectedToggleObjectActiveStates();
                        previewedToggle = null;
                        ClearParameterPreviewState();
                        avatarName = "No Avatar Selected";
                        detectedToggles.Clear();
                        detectedPhysBones.Clear();
                        currentRadialMenu = null;
                        menuHistory.Clear();
                        menuPathHistory.Clear();
                        createMenuPath = "Root";
                    }
                    RefreshBackupList();
                }

                EditorGUILayout.Space(7);
                EditorGUILayout.BeginHorizontal();
                {
                    DrawMetricCard("AVATAR", avatarDescriptor != null ? avatarName : "Not selected");
                    DrawMetricCard("MENU CONTROLS", detectedToggles.Count.ToString());
                    DrawMetricCard("BACKUPS", availableBackups.Count.ToString());
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(8);
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            {
                DrawNavigationButton(MainTab.EditToggles, "Manage");
                DrawNavigationButton(MainTab.CreateToggle, "Create");
                DrawNavigationButton(MainTab.FxAnalysis, "FX Analysis");
                DrawNavigationButton(MainTab.Backups, "Backups");
                DrawNavigationButton(MainTab.PhysBones, "PhysBones");
                DrawNavigationButton(MainTab.Settings, "Settings");
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Dynamics Editor", EditorStyles.toolbarButton, GUILayout.Height(28)))
                    Ninsa.AvatarDynamicsOverhaul.AvatarDynamicsOverhaulWindow.OpenWindow();
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(4);
        }

        private void DrawNavigationButton(MainTab tab, string label)
        {
            bool selected = currentTab == tab;
            Color previousColor = GUI.backgroundColor;
            GUI.backgroundColor = selected
                ? (EditorGUIUtility.isProSkin ? new Color(0.28f, 0.68f, 0.72f) : new Color(0.72f, 0.9f, 0.9f))
                : Color.white;
            if (GUILayout.Toggle(selected, label, EditorStyles.toolbarButton, GUILayout.Height(28)) && currentTab != tab)
            {
                if (tab != MainTab.EditToggles && previewedToggle != null)
                {
                    StopAnimationClipPreview();
                    previewedToggle = null;
                    ClearParameterPreviewState();
                    RefreshSelectedToggleObjectActiveStates();
                }
                currentTab = tab;
            }
            GUI.backgroundColor = previousColor;
        }

        private void DrawMetricCard(string title, string value)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.MinWidth(120), GUILayout.ExpandWidth(true));
            GUILayout.Label(title, EditorStyles.miniLabel);
            GUILayout.Label(value, EditorStyles.boldLabel);
            EditorGUILayout.EndVertical();
        }

        #region Edit Toggles Tab
        private void DrawEditTogglesTab()
        {
            EditorGUILayout.LabelField("Manage menu controls", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Preview a menu control to see its linked avatar objects and the FX clips that turn objects on or off. Switch the radial click mode to mark controls for removal.", MessageType.Info);

            if (avatarDescriptor == null)
            {
                EditorGUILayout.HelpBox("Please assign a VRChat Avatar Descriptor above to begin scanning.", MessageType.Warning);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            {
                if (GUILayout.Button("Scan avatar", GUILayout.Height(30)))
                {
                    ScanAvatarData();
                }
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(10);
            
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            {
                GUILayout.Label("View Mode:", GUILayout.Width(75));
                if (GUILayout.Toggle(!useRadialView, "List View", EditorStyles.toolbarButton, GUILayout.Width(80))) useRadialView = false;
                if (GUILayout.Toggle(useRadialView, "Radial Menu", EditorStyles.toolbarButton, GUILayout.Width(80))) useRadialView = true;
                GUILayout.FlexibleSpace();
                
                if (!useRadialView)
                {
                    GUILayout.Label("Filter:", GUILayout.Width(40));
                    currentToggleFilter = (ToggleFilterType)EditorGUILayout.EnumPopup(currentToggleFilter, EditorStyles.toolbarPopup, GUILayout.Width(130));
                }
                else
                {
                    GUILayout.Label("Click:", GUILayout.Width(36));
                    if (GUILayout.Toggle(radialPreviewMode, "Preview", EditorStyles.toolbarButton, GUILayout.Width(68f)))
                        radialPreviewMode = true;
                    if (GUILayout.Toggle(!radialPreviewMode, "Mark for Removal", EditorStyles.toolbarButton, GUILayout.Width(112f)))
                        radialPreviewMode = false;
                }
            }
            EditorGUILayout.EndHorizontal();

            if (previewedToggle != null)
            {
                List<GameObject> previewTargets = GetToggleLinkedObjects(previewedToggle);
                EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                EditorGUILayout.LabelField("Previewing: " + previewedToggle.toggleName + "  ·  " +
                    previewTargets.Count + " linked object(s)", EditorStyles.boldLabel);
                if (GUILayout.Button("Stop Preview", GUILayout.Width(105f)))
                {
                    StopAnimationClipPreview();
                    previewedToggle = null;
                    ClearParameterPreviewState();
                    RefreshSelectedToggleObjectActiveStates();
                }
                EditorGUILayout.EndHorizontal();
                EditorGUILayout.HelpBox(
                    "Click controls to switch them on or off together. Controls sharing the same Int parameter remain mutually exclusive. Stop Preview restores the avatar.",
                    MessageType.None);
                DrawPreviewToggleList();
                DrawParameterPreviewControls(previewedToggle);
                if (previewAnimationClip != null && ownsAnimationPreviewMode)
                {
                    EditorGUI.BeginChangeCheck();
                    previewAnimationTime = EditorGUILayout.Slider("FX Clip Time", previewAnimationTime, 0f,
                        Mathf.Max(previewAnimationClip.length, 0.001f));
                    if (EditorGUI.EndChangeCheck()) SamplePreviewAnimationClip();
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField("Sampling: " + previewAnimationClip.name, EditorStyles.miniLabel);
                    if (GUILayout.Button("Stop Clip Sample", GUILayout.Width(125f))) StopAnimationClipPreview();
                    EditorGUILayout.EndHorizontal();
                }
            }

            if (detectedToggles.Count == 0)
            {
                EditorGUILayout.Space(10);
                EditorGUILayout.HelpBox("No controls found in the avatar's Expression Menus or Expression Parameters.", MessageType.Info);
                return;
            }

            int selectedCount = detectedToggles.Count(t => t.isSelectedForRemoval);
            int protectedObjectCount = previewLinkedObjects.Count(target => !previewDeleteEligibleObjects.Contains(target));
            List<ClothingToggleData> previewSelectedToggles = detectedToggles
                .Where(toggle => toggle.isSelectedForRemoval)
                .ToList();
            HashSet<GameObject> forceDeleteEligibleObjects = forceDeleteLinkedObjects
                ? previewDeleteEligibleObjects
                : GetObjectsToDelete(previewSelectedToggles, true);
            int forceableProtectedObjectCount = forceDeleteEligibleObjects.Count(target => !previewDeleteEligibleObjects.Contains(target));
            HashSet<GameObject> deletionBlacklist = GetDeletionBlacklistObjects();
            EditorGUILayout.Space(5);
            EditorGUILayout.BeginHorizontal();
            {
                bool selectionControlsEnabled = GUI.enabled;
                GUI.enabled = selectionControlsEnabled && !showMultiDeletePreview;
                if (GUILayout.Button("Select All", GUILayout.Width(100)))
                {
                    foreach (ClothingToggleData toggle in detectedToggles) toggle.isSelectedForRemoval = true;
                    RefreshSelectedToggleObjectActiveStates();
                }
                if (GUILayout.Button("Deselect All", GUILayout.Width(100)))
                {
                    foreach (ClothingToggleData toggle in detectedToggles) toggle.isSelectedForRemoval = false;
                    RefreshSelectedToggleObjectActiveStates();
                }
                GUI.enabled = selectionControlsEnabled;
                
                GUILayout.FlexibleSpace();

                if (selectedCount > 0)
                {
                    GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
                    if (GUILayout.Button($"Remove selected ({selectedCount})", GUILayout.Width(200), GUILayout.Height(25)))
                    {
                        showMultiDeletePreview = true;
                        forceDeleteLinkedObjects = false;
                        previewObjectsToKeep.Clear();
                        RefreshDeletionPreview();
                    }
                    GUI.backgroundColor = Color.white;
                }
            }
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(5);

            if (showMultiDeletePreview && selectedCount > 0)
            {
                EditorGUILayout.BeginVertical(new GUIStyle(EditorStyles.helpBox) { padding = new RectOffset(15, 15, 15, 15) });
                {
                    GUI.color = new Color(1f, 0.6f, 0.6f);
                    EditorGUILayout.LabelField("Review removal", EditorStyles.boldLabel);
                    GUI.color = Color.white;
                    EditorGUILayout.Space(5);
                    EditorGUILayout.LabelField($"You are about to remove {selectedCount} menu control(s).");
                    EditorGUILayout.LabelField("Menu entries will be removed from the selected menus.");
                    EditorGUILayout.LabelField("Parameters still used by other controls or FX states will be kept.");
                    EditorGUILayout.LabelField("NINSA FX layers for removed parameters are cleaned up when possible.");

                    if (previewLinkedObjects.Count > 0)
                    {
                        EditorGUILayout.Space(5);
                        EditorGUILayout.LabelField("Linked objects — check Keep to prevent deletion:", EditorStyles.boldLabel);
                        EditorGUILayout.HelpBox("Deleting a parent also deletes its children. Keeping a listed child will protect its parent from deletion too.", MessageType.None);
                        deletionObjectListScroll = EditorGUILayout.BeginScrollView(deletionObjectListScroll, EditorStyles.helpBox, GUILayout.MaxHeight(190f));
                        foreach (GameObject target in previewLinkedObjects.ToArray())
                        {
                            if (target == null) continue;
                            bool hasKeptDescendant = previewLinkedObjects.Any(child => child != target &&
                                child.transform.IsChildOf(target.transform) &&
                                (!previewDeleteEligibleObjects.Contains(child) || previewObjectsToKeep.Contains(child)));
                            bool canDelete = previewDeleteEligibleObjects.Contains(target) && !hasKeptDescendant;
                            bool keep = !canDelete || previewObjectsToKeep.Contains(target);
                            EditorGUILayout.BeginHorizontal();
                            EditorGUI.BeginDisabledGroup(!canDelete);
                            EditorGUI.BeginChangeCheck();
                            bool nextKeep = EditorGUILayout.ToggleLeft("Keep", keep, GUILayout.Width(58f));
                            bool keepChanged = EditorGUI.EndChangeCheck();
                            EditorGUI.EndDisabledGroup();
                            if (keepChanged && canDelete)
                            {
                                if (nextKeep) previewObjectsToKeep.Add(target);
                                else previewObjectsToKeep.Remove(target);
                                UpdateDeletionObjectSelection();
                            }
                            string objectPath = GetRelativePath(avatarDescriptor.transform, target.transform);
                            objectPath = string.IsNullOrEmpty(objectPath) ? target.name : objectPath;
                            if (settingSelectDeletePreviewObject)
                            {
                                if (GUILayout.Button(new GUIContent(objectPath, "Click to select and frame this object in Unity."),
                                        EditorStyles.label, GUILayout.ExpandWidth(true)))
                                    SelectObjectInUnity(target);
                            }
                            else
                            {
                                EditorGUILayout.LabelField(objectPath, EditorStyles.miniLabel);
                            }
                            if (!canDelete)
                            {
                                string status = hasKeptDescendant ? "Child kept" :
                                    IsBlockedByDeletionBlacklist(target, deletionBlacklist) ? "Blacklisted" : "Protected";
                                GUILayout.Label(status, EditorStyles.miniLabel, GUILayout.Width(70f));
                            }
                            EditorGUILayout.EndHorizontal();
                        }
                        EditorGUILayout.EndScrollView();

                        EditorGUILayout.Space(4f);
                        EditorGUILayout.LabelField("Objects that will be deleted:", EditorStyles.boldLabel);
                        if (previewObjectsToDelete.Count == 0)
                        {
                            EditorGUILayout.LabelField("None", EditorStyles.miniLabel);
                        }
                        else
                        {
                            foreach (GameObject target in previewObjectsToDelete.Take(8))
                            {
                                if (target == null) continue;
                                string objectPath = GetRelativePath(avatarDescriptor.transform, target.transform);
                                string displayPath = "• " + (string.IsNullOrEmpty(objectPath) ? target.name : objectPath);
                                if (settingSelectDeletePreviewObject)
                                {
                                    if (GUILayout.Button(new GUIContent(displayPath, "Click to select and frame this object in Unity."),
                                            EditorStyles.miniLabel))
                                        SelectObjectInUnity(target);
                                }
                                else
                                {
                                    EditorGUILayout.LabelField(displayPath, EditorStyles.miniLabel);
                                }
                            }
                        }
                        if (previewObjectsToDelete.Count > 8)
                            EditorGUILayout.LabelField("and " + (previewObjectsToDelete.Count - 8) + " more…", EditorStyles.miniLabel);

                        if (previewRetainedObjectCount > 0)
                            EditorGUILayout.HelpBox($"{previewRetainedObjectCount} linked object(s) will be kept. Some may be protected because they are used elsewhere.", MessageType.Info);
                    }
                    else if (previewLinkedObjectCount > 0)
                    {
                        EditorGUILayout.HelpBox(
                            $"{previewRetainedObjectCount} linked object(s) will be kept because another detected menu toggle still uses them.",
                            MessageType.Info);
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("No directly animated avatar objects were found for the selected toggles. Their objects will be kept.", MessageType.Info);
                    }

                    if (protectedObjectCount > 0)
                        EditorGUILayout.HelpBox(protectedObjectCount + " linked object(s) are protected. Blacklisted objects stay protected even during force deletion.", MessageType.Info);

                    if (forceableProtectedObjectCount > 0 && !forceDeleteLinkedObjects)
                    {
                        EditorGUILayout.HelpBox(forceableProtectedObjectCount + " shared object(s) can be included with force delete. Blacklisted objects will still be kept.", MessageType.Warning);
                        GUI.backgroundColor = new Color(1f, 0.55f, 0.35f);
                        if (GUILayout.Button("Force Delete Linked Objects Anyway", GUILayout.Height(28)))
                        {
                            forceDeleteLinkedObjects = true;
                            RefreshDeletionPreview();
                        }
                        GUI.backgroundColor = Color.white;
                    }
                    else if (forceDeleteLinkedObjects)
                    {
                        EditorGUILayout.HelpBox("Force delete is enabled. Objects still referenced by other toggles may break those toggles.", MessageType.Warning);
                        if (GUILayout.Button("Return to Safe Deletion"))
                        {
                            forceDeleteLinkedObjects = false;
                            RefreshDeletionPreview();
                        }
                    }

                    EditorGUILayout.Space(10);
                    EditorGUILayout.BeginHorizontal();
                    {
                        GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
                        if (GUILayout.Button(forceDeleteLinkedObjects ? "Confirm Force Deletion" : "Confirm Deletion", GUILayout.Height(30))) ExecuteMultiDeletion();
                        GUI.backgroundColor = Color.white;
                        
                        if (GUILayout.Button("Cancel", GUILayout.Height(30)))
                        {
                            showMultiDeletePreview = false;
                            forceDeleteLinkedObjects = false;
                            previewObjectsToKeep.Clear();
                            previewObjectsToDelete.Clear();
                        }
                    }
                    EditorGUILayout.EndHorizontal();
                }
                EditorGUILayout.EndVertical();
                EditorGUILayout.Space(10);
            }

            if (useRadialView) DrawRadialMenu();
            else DrawListView();
        }

        private void DrawListView()
        {
            var filteredToggles = detectedToggles.Where(PassesFilter).ToList();
            var groupedToggles = filteredToggles.GroupBy(t => t.menuPath).OrderBy(g => g.Key).ToList();
            
            int displayedCount = 0;

            foreach (var group in groupedToggles)
            {
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                {
                    EditorGUILayout.LabelField(group.Key, EditorStyles.boldLabel);
                    EditorGUILayout.Space(2);

                    foreach (var toggle in group)
                    {
                        displayedCount++;
                        EditorGUILayout.BeginHorizontal();
                        {
                            bool previousGuiEnabled = GUI.enabled;
                            GUI.enabled = previousGuiEnabled && !showMultiDeletePreview;
                            EditorGUI.BeginChangeCheck();
                            bool selectedForRemoval = EditorGUILayout.Toggle(toggle.isSelectedForRemoval, GUILayout.Width(20));
                            if (EditorGUI.EndChangeCheck())
                            {
                                SetToggleSelectedForRemoval(toggle, selectedForRemoval);
                                if (selectedForRemoval && settingSelectDeletePreviewObject)
                                    SelectToggleObjectsInUnity(toggle);
                            }
                            GUI.enabled = previousGuiEnabled;

                            GUIContent toggleLabel = new GUIContent(toggle.toggleName,
                                settingSelectDeletePreviewObject ? "Click to preview this control and select its linked Unity object(s)." : null);
                            GUIStyle labelStyle = new GUIStyle(EditorStyles.label);
                            if (toggle.isSelectedForRemoval) labelStyle.normal.textColor = new Color(1f, 0.4f, 0.4f);

                            if (settingSelectDeletePreviewObject)
                            {
                                if (GUILayout.Button(toggleLabel, labelStyle, GUILayout.ExpandWidth(true)))
                                    PreviewToggleInUnity(toggle);
                            }
                            else
                            {
                                EditorGUILayout.LabelField(toggleLabel, labelStyle);
                            }
                            GUILayout.Label(toggle.controlType ?? "Control", EditorStyles.miniLabel, GUILayout.Width(92));

                            string previewButtonLabel = IsTogglePreviewActive(toggle) ? "Turn Off" : "Turn On";
                            if (GUILayout.Button(previewButtonLabel, GUILayout.Width(78f)))
                            {
                                PreviewToggleInUnity(toggle);
                            }

                            if (GUILayout.Button(toggle.isExpanded ? "Hide ▲" : "Details ▼", GUILayout.Width(80)))
                            {
                                toggle.isExpanded = !toggle.isExpanded;
                                if (toggle.isExpanded && toggle.clothingObject != null)
                                {
                                    if (previewSessionToggles.Contains(toggle))
                                    {
                                        previewedToggle = toggle;
                                        SelectToggleObjectsInUnity(toggle);
                                    }
                                    else PreviewToggleInUnity(toggle);
                                }
                            }
                        }
                        EditorGUILayout.EndHorizontal();

                        if (toggle.isExpanded)
                        {
                            EditorGUI.indentLevel++;
                            EditorGUILayout.BeginVertical(new GUIStyle(EditorStyles.helpBox) { margin = new RectOffset(20, 0, 5, 5) });
                            {
                                EditorGUILayout.LabelField("Parameter:", string.IsNullOrEmpty(toggle.parameterName) ? "<None>" : toggle.parameterName);
                                if (toggle.parameterNames != null && toggle.parameterNames.Count > 0)
                                {
                                    var parameterDescriptions = toggle.parameterNames.Select((name, index) => name + " (" +
                                        (toggle.parameterTypes != null && index < toggle.parameterTypes.Count ? toggle.parameterTypes[index] : "Unknown") + ")");
                                    EditorGUILayout.LabelField("Control Parameters:", string.Join(", ", parameterDescriptions));
                                    EditorGUILayout.LabelField("Menu Default Value:", toggle.menuControlValue.ToString("0.###"));
                                }
                                EditorGUILayout.LabelField("Control Type:", string.IsNullOrEmpty(toggle.controlType) ? "<Unknown>" : toggle.controlType);
                                string targetSummary = toggle.clothingObject != null
                                    ? toggle.clothingObject.name
                                    : toggle.animatedObjects != null && toggle.animatedObjects.Count > 0
                                        ? toggle.animatedObjects.Count + " animated object(s)"
                                        : "<Not Resolved>";
                                EditorGUILayout.LabelField("Target Object:", targetSummary);
                                
                                EditorGUILayout.Space(3);
                                EditorGUILayout.LabelField("Dependency Breakdown:", EditorStyles.miniBoldLabel);
                                EditorGUILayout.LabelField($"- GameObject Active State: {(toggle.hasOnOff ? "Yes" : "No")}", EditorStyles.miniLabel);
                                EditorGUILayout.LabelField($"- BlendShape Action: {(toggle.hasBlendShape ? "Yes" : "No")}", EditorStyles.miniLabel);
                                EditorGUILayout.LabelField($"- Material Property Action: {(toggle.hasMaterialProperty ? "Yes" : "No")}", EditorStyles.miniLabel);
                                EditorGUILayout.LabelField($"- INT State Value: {(toggle.hasIntState ? "Yes" : "No")}", EditorStyles.miniLabel);
                                EditorGUILayout.LabelField($"- FLOAT Parameter: {(toggle.hasFloatState ? "Yes" : "No")}", EditorStyles.miniLabel);

                                EditorGUILayout.Space(3f);
                                EditorGUILayout.LabelField("FX Clips Found: " + (toggle.relatedClips != null ? toggle.relatedClips.Count : 0), EditorStyles.miniBoldLabel);
                                if (toggle.transitionRules != null && toggle.transitionRules.Count > 0)
                                {
                                    EditorGUILayout.LabelField("FX Parameter Conditions:", EditorStyles.miniBoldLabel);
                                    foreach (string rule in toggle.transitionRules.Take(8))
                                        EditorGUILayout.LabelField("• " + rule, EditorStyles.miniLabel);
                                    if (toggle.transitionRules.Count > 8)
                                        EditorGUILayout.LabelField("and " + (toggle.transitionRules.Count - 8) + " more…", EditorStyles.miniLabel);
                                }
                                if (toggle.relatedClips != null && toggle.relatedClips.Count > 0)
                                {
                                    foreach (AnimationClip clip in toggle.relatedClips.Take(8))
                                    {
                                        if (clip == null) continue;
                                        EditorGUILayout.BeginHorizontal();
                                        EditorGUILayout.LabelField("• " + clip.name, EditorStyles.miniLabel);
                                        EditorGUI.BeginDisabledGroup(previewedToggle != toggle || !CanStartAnimationClipPreview());
                                        if (GUILayout.Button(previewAnimationClip == clip ? "Sampling" : "Sample", GUILayout.Width(76f)))
                                            StartAnimationClipPreview(clip);
                                        EditorGUI.EndDisabledGroup();
                                        EditorGUILayout.EndHorizontal();
                                    }
                                    if (toggle.relatedClips.Count > 8)
                                        EditorGUILayout.LabelField("and " + (toggle.relatedClips.Count - 8) + " more…", EditorStyles.miniLabel);
                                }
                                else
                                {
                                    EditorGUILayout.LabelField("No FX clips matched these control parameters.", EditorStyles.miniLabel);
                                }

                                if (toggle.animatedObjects != null && toggle.animatedObjects.Count > 0)
                                {
                                    EditorGUILayout.Space(3f);
                                    EditorGUILayout.LabelField("Animated GameObjects:", EditorStyles.miniBoldLabel);
                                    foreach (GameObject animatedObject in toggle.animatedObjects.Where(target => target != null))
                                    {
                                        string path = avatarDescriptor != null
                                            ? GetRelativePath(avatarDescriptor.transform, animatedObject.transform)
                                            : animatedObject.name;
                                        string state = animatedObject.activeSelf ? "Self On" : "Self Off";
                                        if (!animatedObject.activeInHierarchy) state += " / Hierarchy Off";
                                        string fxAction = GetActiveStateActionSummary(animatedObject, toggle.relatedClips);
                                        EditorGUILayout.LabelField(string.IsNullOrEmpty(path) ? animatedObject.name : path,
                                            state + (string.IsNullOrEmpty(fxAction) ? " · no active-state curve found" : " · " + fxAction));
                                    }
                                }
                                else if (toggle.hasOnOff)
                                {
                                    EditorGUILayout.HelpBox("An active-state animation was detected, but its target object could not be resolved in this avatar hierarchy.", MessageType.Warning);
                                }

                                if (toggle.sharedParameters.Count > 0)
                                {
                                    GUI.color = Color.yellow;
                                    EditorGUILayout.HelpBox("Warning: Parameters " + string.Join(", ", toggle.sharedParameters) +
                                        " are shared across multiple controls.", MessageType.Warning);
                                    GUI.color = Color.white;
                                }
                            }
                            EditorGUILayout.EndVertical();
                            EditorGUI.indentLevel--;
                            EditorGUILayout.Space(3);
                        }
                    }
                }
                EditorGUILayout.EndVertical();
                EditorGUILayout.Space(5);
            }

            if (displayedCount == 0)
            {
                EditorGUILayout.HelpBox($"No toggles match the selected filter: '{currentToggleFilter}'.", MessageType.Info);
            }
        }

        private void DrawRadialMenu()
        {
            if (currentRadialMenu == null)
            {
                EditorGUILayout.HelpBox("No Expressions Menu assigned to the Avatar Descriptor.", MessageType.Info);
                return;
            }

            if (currentRadialMenu.controls == null)
            {
                EditorGUILayout.HelpBox("This expression menu has no controls yet.", MessageType.Info);
                return;
            }

            EditorGUILayout.Space(10);
            
            // Header Path
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField(currentRadialMenuPath, EditorStyles.boldLabel, GUILayout.Width(200));
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space(5);

            Rect area = GUILayoutUtility.GetRect(350, 350);
            Vector2 center = area.center;
            float baseOuterRadius = 155f;
            float innerRadius = 45f;

            float currentTime = (float)EditorApplication.timeSinceStartup;
            float dt = currentTime - lastFrameTime;
            lastFrameTime = currentTime;
            if (dt > 0.1f) dt = 0.016f;

            Event e = Event.current;
            Vector2 mousePos = e.mousePosition;
            float dist = Vector2.Distance(mousePos, center);

            float angle = Mathf.Atan2(mousePos.y - center.y, mousePos.x - center.x) * Mathf.Rad2Deg;
            angle = (angle + 90) % 360; 
            if (angle < 0) angle += 360;

            int hoveredIndex = -1;
            bool hoverCenter = false;

            int controlCount = Mathf.Min(8, currentRadialMenu.controls.Count);
            float sliceAngle = controlCount > 0 ? 360f / controlCount : 360f;

            if (dist <= innerRadius) 
            {
                hoverCenter = true;
            }
            else if (dist <= baseOuterRadius + 15f && controlCount > 0) 
            {
                float adjustedAngle = (angle + (sliceAngle / 2f)) % 360f;
                if (adjustedAngle < 0) adjustedAngle += 360f;
                hoveredIndex = Mathf.FloorToInt(adjustedAngle / sliceAngle) % controlCount;
            }

            Color centerBgColor = new Color(radialBgColor.r * 1.2f, radialBgColor.g * 1.2f, radialBgColor.b * 1.2f, 1f);
            Color centerHoverColor = new Color(radialHoverColor.r * 1.3f, radialHoverColor.g * 1.3f, radialHoverColor.b * 1.3f, 1f);

            GUIStyle textStyle = new GUIStyle(EditorStyles.label)
            {
                alignment = TextAnchor.MiddleCenter,
                wordWrap = true,
                normal = { textColor = new Color(0.85f, 0.85f, 0.85f, 1f) }
            };

            for (int i = 0; i < controlCount; i++)
            {
                bool isHovered = (i == hoveredIndex) && !hoverCenter;
                VRCExpressionsMenu.Control control = currentRadialMenu.controls[i];
                
                ClothingToggleData toggleData = null;
                if (control != null)
                {
                    toggleData = detectedToggles.FirstOrDefault(t => t.sourceControl == control && t.sourceMenu == currentRadialMenu);
                }

                float targetWeight = isHovered ? 1f : 0f;
                sliceAnimWeights[i] = Mathf.Lerp(sliceAnimWeights[i], targetWeight, dt * 14f);
                float currentOuterRadius = baseOuterRadius + (sliceAnimWeights[i] * 12f);

                float startAngleDeg = (i * sliceAngle) - (sliceAngle / 2f);
                Vector3 startDir = new Vector3(Mathf.Sin(startAngleDeg * Mathf.Deg2Rad), -Mathf.Cos(startAngleDeg * Mathf.Deg2Rad), 0);

                Color sliceColor = radialBgColor;
                if (isHovered) sliceColor = radialHoverColor;
                if (control == null)
                {
                    Handles.color = sliceColor;
                    Handles.DrawSolidArc(center, Vector3.forward, startDir, sliceAngle, currentOuterRadius);
                    float emptyMidAngle = i * sliceAngle;
                    Vector2 emptyDirection = new Vector2(Mathf.Sin(emptyMidAngle * Mathf.Deg2Rad), -Mathf.Cos(emptyMidAngle * Mathf.Deg2Rad));
                    Vector2 emptyPosition = center + emptyDirection * ((innerRadius + currentOuterRadius) / 1.85f);
                    GUI.Label(new Rect(emptyPosition.x - 35, emptyPosition.y - 12, 70, 24), "Empty", textStyle);
                    continue;
                }
                if (toggleData != null && toggleData.isSelectedForRemoval) sliceColor = radialDeleteColor;
                else if (toggleData != null && IsTogglePreviewActive(toggleData)) sliceColor = new Color(0.16f, 0.42f, 0.24f, 1f);

                Handles.color = sliceColor;
                Handles.DrawSolidArc(center, Vector3.forward, startDir, sliceAngle, currentOuterRadius);

                if (controlCount > 1) 
                {
                    Handles.color = radialLineColor;
                    Handles.DrawLine(center + (Vector2)startDir * innerRadius, center + (Vector2)startDir * currentOuterRadius);
                }
                
                float midAngle = i * sliceAngle;
                Vector2 midDir = new Vector2(Mathf.Sin(midAngle * Mathf.Deg2Rad), -Mathf.Cos(midAngle * Mathf.Deg2Rad));
                Vector2 pos = center + midDir * ((innerRadius + currentOuterRadius) / 1.85f);
                
                if (control.icon != null)
                {
                    GUI.DrawTexture(new Rect(pos.x - 18, pos.y - 30, 36, 36), control.icon, ScaleMode.ScaleToFit);
                }
                else if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    GUI.Label(new Rect(pos.x - 20, pos.y - 30, 40, 20), "SUB", textStyle);
                }

                GUI.Label(new Rect(pos.x - 35, pos.y + 5, 70, 35), control.name, textStyle);

                if (e.type == EventType.MouseDown && e.button == 0 && isHovered)
                {
                    if (control.type == VRCExpressionsMenu.Control.ControlType.SubMenu && control.subMenu != null)
                    {
                        menuHistory.Push(currentRadialMenu);
                        menuPathHistory.Push(currentRadialMenuPath);
                        currentRadialMenu = control.subMenu;
                        currentRadialMenuPath += $" > {control.name}";
                        System.Array.Clear(sliceAnimWeights, 0, sliceAnimWeights.Length);
                    }
                    else if (toggleData != null && !showMultiDeletePreview)
                    {
                        if (radialPreviewMode)
                        {
                            PreviewToggleInUnity(toggleData);
                        }
                        else
                        {
                            bool selectedForRemoval = !toggleData.isSelectedForRemoval;
                            SetToggleSelectedForRemoval(toggleData, selectedForRemoval);
                            if (selectedForRemoval && settingSelectDeletePreviewObject)
                                SelectToggleObjectsInUnity(toggleData);
                        }
                    }
                    e.Use();
                }
            }

            Handles.color = hoverCenter ? centerHoverColor : centerBgColor;
            Handles.DrawSolidDisc(center, Vector3.forward, innerRadius);
            
            Handles.color = radialLineColor;
            Handles.DrawWireDisc(center, Vector3.forward, innerRadius);

            if (menuHistory.Count > 0)
            {
                GUIStyle centerStyle = new GUIStyle(EditorStyles.boldLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } };
                GUI.Label(new Rect(center.x - 20, center.y - 10, 40, 20), "BACK", centerStyle);

                if (e.type == EventType.MouseDown && e.button == 0 && hoverCenter)
                {
                    currentRadialMenu = menuHistory.Pop();
                    currentRadialMenuPath = menuPathHistory.Pop();
                    System.Array.Clear(sliceAnimWeights, 0, sliceAnimWeights.Length);
                    e.Use();
                }
            }
            else
            {
                GUIStyle centerStyle = new GUIStyle(EditorStyles.miniLabel) { alignment = TextAnchor.MiddleCenter, normal = { textColor = new Color(0.6f, 0.6f, 0.6f) } };
                GUI.Label(new Rect(center.x - 20, center.y - 10, 40, 20), "ROOT", centerStyle);
            }

            Repaint();
        }

        private bool PassesFilter(ClothingToggleData toggle)
        {
            switch (currentToggleFilter)
            {
                case ToggleFilterType.GameObject: return toggle.hasOnOff;
                case ToggleFilterType.BlendShape: return toggle.hasBlendShape;
                case ToggleFilterType.MaterialProperty: return toggle.hasMaterialProperty;
                case ToggleFilterType.IntState: return toggle.hasIntState;
                case ToggleFilterType.FloatState: return toggle.hasFloatState;
                default: return true;
            }
        }
        #endregion

        #region Create Toggle Tab
        private void DrawCreateToggleTab()
        {
            EditorGUILayout.LabelField("Create a toggle", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("This creates the animation clips, FX states, expression parameters, and menu control, then assigns the generated assets to this avatar.", MessageType.Info);

            if (avatarDescriptor == null)
            {
                EditorGUILayout.HelpBox("Select an avatar above to begin.", MessageType.Warning);
                return;
            }

            List<MenuOption> menuOptions = GetMenuOptions();
            VRCExpressionsMenu targetMenu = null;
            if (menuOptions.Count > 0)
            {
                string[] paths = menuOptions.Select(option => option.path).ToArray();
                int selectedIndex = menuOptions.FindIndex(option => option.path == createMenuPath);
                if (selectedIndex < 0) selectedIndex = 0;
                selectedIndex = EditorGUILayout.Popup("Add to menu", selectedIndex, paths);
                createMenuPath = paths[selectedIndex];
                targetMenu = menuOptions[selectedIndex].menu;
            }
            else
            {
                EditorGUILayout.HelpBox("No expression menu is assigned yet. A new root menu will be created with this toggle.", MessageType.Info);
            }

            EditorGUILayout.Space(6);
            EditorGUILayout.LabelField("Toggle setup", EditorStyles.boldLabel);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                newToggleName = EditorGUILayout.TextField("Toggle Name", newToggleName);
                targetClothingObject = (GameObject)EditorGUILayout.ObjectField("Clothing Object", targetClothingObject, typeof(GameObject), true);
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(8);
            EditorGUILayout.LabelField("What should the toggle change?", EditorStyles.boldLabel);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                enableOnOff = EditorGUILayout.ToggleLeft("Show or hide a GameObject", enableOnOff);
                EditorGUILayout.Space(4);
                enableBlendShape = EditorGUILayout.ToggleLeft("Change a blend shape", enableBlendShape);
                if (enableBlendShape)
                {
                    EditorGUI.indentLevel++;
                    targetSkinnedMesh = (SkinnedMeshRenderer)EditorGUILayout.ObjectField("Skinned Mesh", targetSkinnedMesh, typeof(SkinnedMeshRenderer), true);
                    blendShapeName = EditorGUILayout.TextField("BlendShape Name", blendShapeName);
                    blendShapeOnValue = EditorGUILayout.Slider("ON Value", blendShapeOnValue, 0f, 100f);
                    blendShapeOffValue = EditorGUILayout.Slider("OFF Value", blendShapeOffValue, 0f, 100f);
                    EditorGUI.indentLevel--;
                }

                EditorGUILayout.Space(4);
                enableMaterialProperty = EditorGUILayout.ToggleLeft("Change a material property", enableMaterialProperty);
                if (enableMaterialProperty)
                {
                    EditorGUI.indentLevel++;
                    targetRenderer = (Renderer)EditorGUILayout.ObjectField("Target Renderer", targetRenderer, typeof(Renderer), true);
                    int materialCount = targetRenderer != null ? targetRenderer.sharedMaterials.Length : 0;
                    if (materialCount > 0)
                        materialIndex = EditorGUILayout.IntSlider("Material Slot", materialIndex, 0, materialCount - 1);
                    else
                        materialIndex = EditorGUILayout.IntField("Material Slot", materialIndex);
                    materialPropertyName = EditorGUILayout.TextField("Property Name", materialPropertyName);
                    materialPropertyType = (MaterialPropertyType)EditorGUILayout.EnumPopup("Property Type", materialPropertyType);

                    if (materialPropertyType == MaterialPropertyType.Color)
                    {
                        matColorOn = EditorGUILayout.ColorField("ON Color", matColorOn);
                        matColorOff = EditorGUILayout.ColorField("OFF Color", matColorOff);
                    }
                    else if (materialPropertyType == MaterialPropertyType.Float || materialPropertyType == MaterialPropertyType.Range ||
                             materialPropertyType == MaterialPropertyType.Alpha || materialPropertyType == MaterialPropertyType.Emission)
                    {
                        matFloatOn = EditorGUILayout.FloatField("ON Value", matFloatOn);
                        matFloatOff = EditorGUILayout.FloatField("OFF Value", matFloatOff);
                    }
                    if (materialPropertyType == MaterialPropertyType.Emission)
                        EditorGUILayout.HelpBox("Emission values multiply the selected emission color. Use a color property such as _EmissionColor.", MessageType.None);
                    EditorGUI.indentLevel--;
                }

                EditorGUILayout.Space(4);
                enableIntState = EditorGUILayout.ToggleLeft("Also drive an integer state", enableIntState);
                if (enableIntState)
                {
                    EditorGUI.indentLevel++;
                    intParameterName = EditorGUILayout.TextField("State Parameter", intParameterName);
                    EditorGUILayout.HelpBox("Leave the name blank to make a new parameter. It will be set to 0 when off and to this value when on.", MessageType.None);
                    intStateValue = EditorGUILayout.IntSlider("ON Value", intStateValue, 1, 255);
                    EditorGUI.indentLevel--;
                }
            }
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(8);
            int menuControlCount = targetMenu != null && targetMenu.controls != null ? targetMenu.controls.Count : 0;
            if (menuControlCount >= 8)
                EditorGUILayout.HelpBox("This menu is full. Choose a different menu with an empty slot.", MessageType.Warning);

            EditorGUI.BeginDisabledGroup(menuControlCount >= 8);
            Color previousColor = GUI.backgroundColor;
            GUI.backgroundColor = EditorGUIUtility.isProSkin ? new Color(0.35f, 0.75f, 0.6f) : new Color(0.7f, 0.95f, 0.8f);
            if (GUILayout.Button("Create Toggle", GUILayout.Height(36))) CreateToggleAction(targetMenu);
            GUI.backgroundColor = previousColor;
            EditorGUI.EndDisabledGroup();
        }

        private List<MenuOption> GetMenuOptions()
        {
            var options = new List<MenuOption>();
            if (avatarDescriptor == null || avatarDescriptor.expressionsMenu == null) return options;
            CollectMenuOptions(avatarDescriptor.expressionsMenu, "Root", options, new HashSet<VRCExpressionsMenu>());
            return options;
        }

        private void CollectMenuOptions(VRCExpressionsMenu menu, string path, List<MenuOption> options,
            HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu)) return;
            options.Add(new MenuOption { menu = menu, path = path });
            if (menu.controls == null) return;
            foreach (VRCExpressionsMenu.Control control in menu.controls)
            {
                if (control == null || control.subMenu == null) continue;
                CollectMenuOptions(control.subMenu, path + " / " + control.name, options, visited);
            }
        }
        #endregion

        #region FX Analysis Tab
        private void DrawFxAnalysisTab()
        {
            EditorGUILayout.LabelField("FX controller", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Review the parameters, layers, and transition conditions in the avatar's FX Animator Controller.", MessageType.Info);

            if (avatarDescriptor == null)
            {
                EditorGUILayout.HelpBox("Assign an Avatar Descriptor to analyze FX Controller.", MessageType.Warning);
                return;
            }

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                fxController = GetFxController(avatarDescriptor);
                EditorGUILayout.ObjectField("Current FX Controller", fxController, typeof(AnimatorController), false);

                EditorGUILayout.Space(5);
                EditorGUI.BeginDisabledGroup(fxController == null);
                if (GUILayout.Button("Scan Controller", GUILayout.Height(30))) ScanFxControllerData();
                EditorGUI.EndDisabledGroup();
            }
            EditorGUILayout.EndVertical();

            if (!isFxScanned)
            {
                EditorGUILayout.HelpBox(fxController == null
                    ? "This avatar does not have a custom FX controller assigned."
                    : "Select Scan Controller to inspect it.", MessageType.None);
            }
            else
            {
                EditorGUILayout.Space(8);
                EditorGUILayout.LabelField("Parameters  ·  " + scannedFxParameters.Count, EditorStyles.boldLabel);
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                {
                    foreach (var param in scannedFxParameters)
                        EditorGUILayout.LabelField(param, EditorStyles.label);
                }
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Layers  ·  " + scannedFxLayers.Count, EditorStyles.boldLabel);
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                {
                    if (scannedFxLayers.Count == 0) EditorGUILayout.LabelField("No layers found.", EditorStyles.miniLabel);
                    foreach (var layer in scannedFxLayers) EditorGUILayout.LabelField(layer, EditorStyles.label);
                }
                EditorGUILayout.EndVertical();

                EditorGUILayout.Space(6);
                EditorGUILayout.LabelField("Transition parameters  ·  " + scannedFxConditions.Count, EditorStyles.boldLabel);
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                {
                    if (scannedFxConditions.Count == 0) EditorGUILayout.LabelField("No transition conditions found.", EditorStyles.miniLabel);
                    foreach (var condition in scannedFxConditions) EditorGUILayout.LabelField(condition, EditorStyles.label);
                }
                EditorGUILayout.EndVertical();
            }
        }
        #endregion

        #region Backups Tab
        private void DrawBackupsTab()
        {
            EditorGUILayout.LabelField("Backup & Restore System", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Each backup saves the avatar prefab plus linked copies of its expression menus, parameters, and FX controller. Menu controls and their Bool, Int, and Float parameter links are preserved. Select the prefab in the Project window and drag it into the scene to recover the avatar or an object.", MessageType.Info);

            if (avatarDescriptor == null)
            {
                EditorGUILayout.HelpBox("Assign an Avatar Descriptor to automatically name and backup its current configuration.", MessageType.Warning);
            }

            EditorGUI.BeginDisabledGroup(avatarDescriptor == null);
            if (GUILayout.Button("Create Backup Now", GUILayout.Height(35))) CreateBackupNow();
            EditorGUI.EndDisabledGroup();
            if (GUILayout.Button("Refresh Backup List", GUILayout.Height(20))) RefreshBackupList();

            EditorGUILayout.Space(15);
            EditorGUILayout.LabelField($"Available Backups ({availableBackups.Count})", EditorStyles.boldLabel);

            if (availableBackups.Count == 0)
            {
                EditorGUILayout.HelpBox("No backups found in 'Assets/AvatarToggleManager_Backups'.", MessageType.None);
            }
            else
            {
                scrollPosition = EditorGUILayout.BeginScrollView(scrollPosition, EditorStyles.helpBox, GUILayout.Height(300));
                for (int i = availableBackups.Count - 1; i >= 0; i--)
                {
                    string backupFolder = availableBackups[i];
                    string backupPath = "Assets/AvatarToggleManager_Backups/" + backupFolder;
                    EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                    {
                        EditorGUILayout.LabelField(backupFolder);
                        GameObject backupPrefab = AvatarToggleBackup.LoadAvatarPrefab(backupPath);
                        EditorGUI.BeginDisabledGroup(backupPrefab == null);
                        if (GUILayout.Button("Select Avatar Prefab", GUILayout.Width(135)))
                        {
                            Selection.activeObject = backupPrefab;
                            EditorGUIUtility.PingObject(backupPrefab);
                        }
                        EditorGUI.EndDisabledGroup();
                        if (GUILayout.Button("Restore Assets", GUILayout.Width(110)))
                        {
                            RestoreBackup(backupPath);
                        }
                    }
                    EditorGUILayout.EndHorizontal();
                }
                EditorGUILayout.EndScrollView();
            }
        }
        #endregion

        #region PhysBones Tab
        private void DrawPhysBonesTab()
        {
            EditorGUILayout.LabelField("PhysBone Manager", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Each entry uses VRChat's own VRC PhysBone inspector, including its Transforms, Forces, Limits, Collisions, Grab & Pose, Options, and Gizmos sections.", MessageType.Info);
            if (GUILayout.Button("Open Full Avatar Dynamics Overhaul", GUILayout.Height(28f)))
                global::Ninsa.AvatarDynamicsOverhaul.AvatarDynamicsOverhaulWindow.OpenForAvatar(
                    avatarDescriptor != null ? avatarDescriptor.gameObject : null);

            if (avatarDescriptor == null)
            {
                EditorGUILayout.HelpBox("Assign an Avatar Descriptor above to find its PhysBones.", MessageType.Warning);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            physBoneSearch = EditorGUILayout.TextField("Search", physBoneSearch);
            if (GUILayout.Button("Refresh", GUILayout.Width(78)))
            {
                ReleasePhysBoneEditors();
                ScanPhysBones();
            }
            EditorGUILayout.EndHorizontal();

            List<VRCPhysBone> visiblePhysBones = detectedPhysBones
                .Where(component => component != null &&
                    (string.IsNullOrEmpty(physBoneSearch) ||
                     component.gameObject.name.IndexOf(physBoneSearch, StringComparison.OrdinalIgnoreCase) >= 0 ||
                     GetRelativePath(avatarDescriptor.transform, component.transform).IndexOf(physBoneSearch, StringComparison.OrdinalIgnoreCase) >= 0))
                .ToList();

            EditorGUILayout.Space(5);
            EditorGUILayout.LabelField($"Found {visiblePhysBones.Count} PhysBone(s)", EditorStyles.miniBoldLabel);
            if (visiblePhysBones.Count == 0)
            {
                EditorGUILayout.HelpBox("No matching PhysBone components were found under this avatar.", MessageType.None);
                return;
            }

            foreach (VRCPhysBone physBone in visiblePhysBones)
            {
                int id = physBone.GetInstanceID();
                EditorGUILayout.BeginVertical(EditorStyles.helpBox);
                EditorGUILayout.BeginHorizontal();
                bool isExpanded = expandedPhysBones.Contains(id);
                bool nextExpanded = EditorGUILayout.Foldout(isExpanded,
                    physBone.gameObject.name + "  ·  " + GetRelativePath(avatarDescriptor.transform, physBone.transform), true,
                    EditorStyles.foldout);
                if (nextExpanded) expandedPhysBones.Add(id);
                else expandedPhysBones.Remove(id);

                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Select", GUILayout.Width(65)))
                {
                    Selection.activeObject = physBone.gameObject;
                    EditorGUIUtility.PingObject(physBone.gameObject);
                }
                EditorGUILayout.EndHorizontal();

                if (nextExpanded)
                {
                    EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
                    EditorGUI.BeginChangeCheck();
                    bool componentEnabled = EditorGUILayout.Toggle(physBone.enabled, GUILayout.Width(18));
                    GUILayout.Label("VRC PhysBone", EditorStyles.boldLabel);
                    GUILayout.FlexibleSpace();
                    if (EditorGUI.EndChangeCheck())
                    {
                        Undo.RecordObject(physBone, "Toggle PhysBone Component");
                        physBone.enabled = componentEnabled;
                        EditorUtility.SetDirty(physBone);
                        PrefabUtility.RecordPrefabInstancePropertyModifications(physBone);
                    }
                    EditorGUILayout.EndHorizontal();

                    global::UnityEditor.Editor inspector;
                    if (!physBoneEditors.TryGetValue(id, out inspector) || inspector == null)
                    {
                        inspector = global::UnityEditor.Editor.CreateEditor(physBone);
                        if (inspector != null) physBoneEditors[id] = inspector;
                    }

                    if (inspector != null)
                    {
                        inspector.serializedObject.Update();
                        inspector.OnInspectorGUI();
                        inspector.serializedObject.ApplyModifiedProperties();
                    }
                    else
                    {
                        EditorGUILayout.HelpBox("Unity could not create an inspector for this PhysBone.", MessageType.Warning);
                    }
                }
                EditorGUILayout.EndVertical();
            }
        }

        private void ScanPhysBones()
        {
            detectedPhysBones = avatarDescriptor == null
                ? new List<VRCPhysBone>()
                : avatarDescriptor.GetComponentsInChildren<VRCPhysBone>(true)
                    .OrderBy(component => GetRelativePath(avatarDescriptor.transform, component.transform), StringComparer.OrdinalIgnoreCase)
                    .ToList();
            Repaint();
        }

        private void ReleasePhysBoneEditors()
        {
            foreach (global::UnityEditor.Editor inspector in physBoneEditors.Values)
                if (inspector != null) UnityEngine.Object.DestroyImmediate(inspector);
            physBoneEditors.Clear();
            expandedPhysBones.Clear();
        }
        #endregion

        #region Settings Tab
        private void DrawSettingsTab()
        {
            EditorGUILayout.LabelField("Tool Settings & Preferences", EditorStyles.boldLabel);
            EditorGUILayout.Space(5);

            EditorGUI.BeginChangeCheck();

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                EditorGUILayout.LabelField("Safety & Backups", EditorStyles.boldLabel);
                settingCreateBackupBeforeChanges = EditorGUILayout.Toggle("Auto-backup Before Edits", settingCreateBackupBeforeChanges);
                settingAllowFxModifications = EditorGUILayout.Toggle(new GUIContent("Remove generated FX layers", "When enabled, deleting a toggle can also remove its NINSA-generated FX layer."), settingAllowFxModifications);
                settingScanFxControllers = EditorGUILayout.Toggle("Scan FX Controllers", settingScanFxControllers);
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                EditorGUILayout.LabelField("Force Delete Toggle Objects", EditorStyles.boldLabel);
                int selectedToggleCount = detectedToggles.Count(toggle => toggle.isSelectedForRemoval);
                EditorGUILayout.HelpBox(
                    "Select toggle(s) on the Manage tab first. This opens the removal review with linked objects included, even if other toggles still use them.",
                    MessageType.Warning);
                EditorGUI.BeginDisabledGroup(avatarDescriptor == null || selectedToggleCount == 0);
                if (GUILayout.Button("Review Force Delete for Selected Toggles", GUILayout.Height(28)))
                {
                    forceDeleteLinkedObjects = true;
                    showMultiDeletePreview = true;
                    previewObjectsToKeep.Clear();
                    RefreshDeletionPreview();
                    currentTab = MainTab.EditToggles;
                }
                EditorGUI.EndDisabledGroup();
                if (selectedToggleCount == 0)
                    EditorGUILayout.LabelField("No toggles are selected for removal.", EditorStyles.miniLabel);
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                EditorGUILayout.LabelField("Delete Preview & Blacklist", EditorStyles.boldLabel);
                settingSelectDeletePreviewObject = EditorGUILayout.Toggle(
                    "Clicking a toggle name starts its Unity preview", settingSelectDeletePreviewObject);
                EditorGUILayout.HelpBox(
                    "Use Preview in the Manage tab to temporarily show a control's linked objects, including objects under inactive parents. Objects and parents that were inactive are restored when preview stops or this window closes.",
                    MessageType.None);
                EditorGUILayout.HelpBox(
                    "Click a toggle name or its Preview button to inspect its linked scene objects. Parameter types and FX on/off clips are shown in Details. The blacklist is independent of the menu list. Select any scene object in the Hierarchy and add it here; matching objects stay protected during all toggle cleanup, including force delete.",
                    MessageType.Info);

                EditorGUILayout.BeginHorizontal();
                EditorGUI.BeginDisabledGroup(Selection.gameObjects == null || Selection.gameObjects.Length == 0);
                if (GUILayout.Button("Add Selected Unity Objects")) AddSelectedObjectsToDeletionBlacklist();
                EditorGUI.EndDisabledGroup();
                EditorGUI.BeginDisabledGroup(deletionBlacklistIds.Count == 0);
                if (GUILayout.Button("Clear Blacklist", GUILayout.Width(110f)))
                {
                    deletionBlacklistIds.Clear();
                    SaveDeletionBlacklist();
                    if (showMultiDeletePreview) RefreshDeletionPreview();
                }
                EditorGUI.EndDisabledGroup();
                EditorGUILayout.EndHorizontal();

                if (deletionBlacklistIds.Count == 0)
                {
                    EditorGUILayout.LabelField("No protected objects yet.", EditorStyles.miniLabel);
                }
                else
                {
                    deletionBlacklistScroll = EditorGUILayout.BeginScrollView(
                        deletionBlacklistScroll, EditorStyles.helpBox, GUILayout.MaxHeight(160f));
                    foreach (string objectId in deletionBlacklistIds.ToArray())
                    {
                        GameObject blacklistedObject = ResolveBlacklistedObject(objectId);
                        EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                        if (blacklistedObject != null)
                        {
                            string objectPath = GetBlacklistObjectPath(blacklistedObject);
                            EditorGUILayout.LabelField(string.IsNullOrEmpty(objectPath) ? blacklistedObject.name : objectPath, EditorStyles.miniLabel);
                            if (GUILayout.Button("Select", GUILayout.Width(52f))) SelectObjectInUnity(blacklistedObject);
                        }
                        else
                        {
                            EditorGUILayout.LabelField("Missing or unloaded scene object", EditorStyles.miniLabel);
                        }

                        if (GUILayout.Button("Remove", GUILayout.Width(62f)))
                        {
                            deletionBlacklistIds.Remove(objectId);
                            SaveDeletionBlacklist();
                            if (showMultiDeletePreview) RefreshDeletionPreview();
                            Repaint();
                        }
                        EditorGUILayout.EndHorizontal();
                    }
                    EditorGUILayout.EndScrollView();
                }
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                EditorGUILayout.LabelField("Scene View Highlight", EditorStyles.boldLabel);
                settingHighlightSelectedAsset = EditorGUILayout.Toggle("Highlight Target Asset", settingHighlightSelectedAsset);
                settingZoomToSelectedObject = EditorGUILayout.Toggle(
                    "Frame Scene View on Selection", settingZoomToSelectedObject);
                if (settingHighlightSelectedAsset)
                {
                    settingHighlightColor = EditorGUILayout.ColorField("Highlight Color", settingHighlightColor);
                }
            }
            EditorGUILayout.EndVertical();
            EditorGUILayout.Space(5);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            {
                EditorGUILayout.LabelField("Radial Menu Customization", EditorStyles.boldLabel);
                radialBgColor = EditorGUILayout.ColorField("Background Color", radialBgColor);
                radialHoverColor = EditorGUILayout.ColorField("Hover Color", radialHoverColor);
                radialLineColor = EditorGUILayout.ColorField("Line/Border Color", radialLineColor);
                radialDeleteColor = EditorGUILayout.ColorField("Deletion Color", radialDeleteColor);
                
                if (GUILayout.Button("Reset Radial Colors", GUILayout.Width(150)))
                {
                    radialBgColor = new Color(0.12f, 0.17f, 0.2f, 1f);
                    radialHoverColor = new Color(0.18f, 0.28f, 0.33f, 1f);
                    radialLineColor = new Color(0.13f, 0.35f, 0.4f, 1f);
                    radialDeleteColor = new Color(0.45f, 0.15f, 0.15f, 1f);
                }
            }
            EditorGUILayout.EndVertical();

            if (EditorGUI.EndChangeCheck())
            {
                SaveSettings();
            }
        }

        private void LoadSettings()
        {
            settingCreateBackupBeforeChanges = EditorPrefs.GetBool("Ninsa_AutoBackup", true);
            settingAllowFxModifications = EditorPrefs.GetBool("Ninsa_AllowFXMods", false);
            settingScanFxControllers = EditorPrefs.GetBool("Ninsa_ScanFX", true);
            
            settingHighlightSelectedAsset = EditorPrefs.GetBool("Ninsa_HighlightAsset", true);
            settingHighlightColor = LoadColor("Ninsa_HighlightColor", Color.green);
            settingSelectDeletePreviewObject = EditorPrefs.GetBool("Ninsa_SelectDeletePreviewObject", true);
            settingZoomToSelectedObject = EditorPrefs.GetBool("Ninsa_ZoomToSelectedObject", true);
            LoadDeletionBlacklist();

            radialBgColor = LoadColor("Ninsa_RadialBg", new Color(0.12f, 0.17f, 0.2f, 1f));
            radialHoverColor = LoadColor("Ninsa_RadialHover", new Color(0.18f, 0.28f, 0.33f, 1f));
            radialLineColor = LoadColor("Ninsa_RadialLine", new Color(0.13f, 0.35f, 0.4f, 1f));
            radialDeleteColor = LoadColor("Ninsa_RadialDel", new Color(0.45f, 0.15f, 0.15f, 1f));
        }

        private void SaveSettings()
        {
            EditorPrefs.SetBool("Ninsa_AutoBackup", settingCreateBackupBeforeChanges);
            EditorPrefs.SetBool("Ninsa_AllowFXMods", settingAllowFxModifications);
            EditorPrefs.SetBool("Ninsa_ScanFX", settingScanFxControllers);
            
            EditorPrefs.SetBool("Ninsa_HighlightAsset", settingHighlightSelectedAsset);
            SaveColor("Ninsa_HighlightColor", settingHighlightColor);
            EditorPrefs.SetBool("Ninsa_SelectDeletePreviewObject", settingSelectDeletePreviewObject);
            EditorPrefs.SetBool("Ninsa_ZoomToSelectedObject", settingZoomToSelectedObject);
            SaveDeletionBlacklist();

            SaveColor("Ninsa_RadialBg", radialBgColor);
            SaveColor("Ninsa_RadialHover", radialHoverColor);
            SaveColor("Ninsa_RadialLine", radialLineColor);
            SaveColor("Ninsa_RadialDel", radialDeleteColor);
        }

        private string GetDeletionBlacklistPrefsKey()
        {
            return "Ninsa_ToggleManager_DeleteBlacklist_" + Application.dataPath.Replace('\\', '/');
        }

        private void LoadDeletionBlacklist()
        {
            string serialized = EditorPrefs.GetString(GetDeletionBlacklistPrefsKey(), "");
            deletionBlacklistIds = serialized
                .Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Distinct(StringComparer.Ordinal)
                .ToList();
        }

        private void SaveDeletionBlacklist()
        {
            EditorPrefs.SetString(GetDeletionBlacklistPrefsKey(), string.Join("\n", deletionBlacklistIds.Distinct(StringComparer.Ordinal)));
        }

        private GameObject ResolveBlacklistedObject(string objectId)
        {
            if (string.IsNullOrEmpty(objectId) || !GlobalObjectId.TryParse(objectId, out GlobalObjectId globalObjectId))
                return null;
            return GlobalObjectId.GlobalObjectIdentifierToObjectSlow(globalObjectId) as GameObject;
        }

        private string GetBlacklistObjectPath(GameObject target)
        {
            if (target == null) return string.Empty;

            if (avatarDescriptor != null &&
                (target == avatarDescriptor.gameObject || target.transform.IsChildOf(avatarDescriptor.transform)))
            {
                string avatarPath = GetRelativePath(avatarDescriptor.transform, target.transform);
                return string.IsNullOrEmpty(avatarPath) ? target.name : avatarPath;
            }

            Transform root = target.transform.root;
            string scenePath = GetRelativePath(root, target.transform);
            return string.IsNullOrEmpty(scenePath) ? root.name : root.name + "/" + scenePath;
        }

        private HashSet<GameObject> GetDeletionBlacklistObjects()
        {
            HashSet<GameObject> objects = new HashSet<GameObject>();
            foreach (string objectId in deletionBlacklistIds)
            {
                GameObject target = ResolveBlacklistedObject(objectId);
                if (target != null) objects.Add(target);
            }
            return objects;
        }

        private static bool IsBlockedByDeletionBlacklist(GameObject target, HashSet<GameObject> blacklist)
        {
            return target != null && blacklist.Any(blocked => blocked != null &&
                (blocked == target || blocked.transform.IsChildOf(target.transform)));
        }

        private void AddSelectedObjectsToDeletionBlacklist()
        {
            int addedCount = 0;
            foreach (GameObject target in Selection.gameObjects ?? new GameObject[0])
            {
                if (target == null || EditorUtility.IsPersistent(target) || !target.scene.IsValid())
                    continue;

                string objectId = GlobalObjectId.GetGlobalObjectIdSlow(target).ToString();
                if (string.IsNullOrEmpty(objectId) || deletionBlacklistIds.Contains(objectId)) continue;
                deletionBlacklistIds.Add(objectId);
                addedCount++;
            }

            SaveDeletionBlacklist();
            if (showMultiDeletePreview) RefreshDeletionPreview();
            Repaint();
            if (addedCount == 0)
                EditorUtility.DisplayDialog("No Scene Objects Added", "Select one or more scene objects in the Hierarchy, then try again.", "OK");
        }

        private void SelectObjectInUnity(GameObject target)
        {
            if (target == null) return;
            Selection.activeGameObject = target;
            EditorGUIUtility.PingObject(target);
            if (settingZoomToSelectedObject && SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.FrameSelected();
        }

        private void SelectToggleObjectsInUnity(ClothingToggleData toggle)
        {
            if (toggle == null) return;
            List<GameObject> targets = GetToggleLinkedObjects(toggle);
            if (targets.Count == 0)
            {
                if (avatarDescriptor != null && Selection.objects.Contains(avatarDescriptor.gameObject))
                    Selection.objects = Selection.objects.Where(target => target != avatarDescriptor.gameObject).ToArray();
                return;
            }

            Selection.objects = targets.Cast<UnityEngine.Object>().ToArray();
            EditorGUIUtility.PingObject(targets[0]);
            if (settingZoomToSelectedObject && SceneView.lastActiveSceneView != null)
                SceneView.lastActiveSceneView.FrameSelected();
        }

        private void PreviewToggleInUnity(ClothingToggleData toggle)
        {
            if (toggle == null) return;
            bool enabled = !IsTogglePreviewActive(toggle);
            if (ownsAnimationPreviewMode) StopAnimationClipPreview();
            SetTogglePreviewOnOff(toggle, enabled);
            SelectToggleObjectsInUnity(toggle);
        }

        private float GetToggleOnValue(ClothingToggleData toggle)
        {
            if (toggle.sourceControl != null) return toggle.sourceControl.value;
            float value = GetDefaultPreviewParameterValue(toggle.parameterName);
            return Mathf.Approximately(value, 0f) ? 1f : value;
        }

        private bool IsTogglePreviewActive(ClothingToggleData toggle)
        {
            if (toggle == null || !previewEnabledToggles.Contains(toggle)) return false;
            List<string> names = GetToggleParameterNames(toggle);
            if (names.Count == 0) return true;
            float value;
            if (GetPlayableParameterType(names[0]).HasValue)
                value = GetPlayableParameterValue(names[0]);
            else if (!parameterPreviewValues.TryGetValue(names[0], out value)) return false;
            if (toggle.sourceControl == null) return !Mathf.Approximately(value, 0f);
            return Mathf.Approximately(value, GetToggleOnValue(toggle));
        }

        private void DrawPreviewToggleList()
        {
            foreach (ClothingToggleData toggle in previewSessionToggles.ToArray())
            {
                EditorGUILayout.BeginHorizontal();
                bool active = IsTogglePreviewActive(toggle);
                bool next = EditorGUILayout.ToggleLeft(toggle.toggleName, active);
                if (next != active) SetTogglePreviewOnOff(toggle, next);
                if (GUILayout.Button("Edit", GUILayout.Width(45f))) previewedToggle = toggle;
                EditorGUILayout.EndHorizontal();
            }
        }

        private bool HasPreviewableParameter(ClothingToggleData toggle)
        {
            return toggle != null && (toggle.hasIntState || toggle.hasFloatState ||
                (toggle.parameterTypes != null && toggle.parameterTypes.Any(type =>
                    string.Equals(type, "Int", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(type, "Float", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(type, "Bool", StringComparison.OrdinalIgnoreCase))));
        }

        private void DrawParameterPreviewControls(ClothingToggleData toggle)
        {
            if (toggle == null) return;
            List<string> names = GetToggleParameterNames(toggle);
            if (names.Count == 0 || !HasPreviewableParameter(toggle)) return;

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Expression Parameter Preview", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Change the menu parameter value to preview the matching FX state in the avatar. This preview is temporary and is restored when stopped.", MessageType.None);

            if (toggle.sourceControl != null && toggle.sourceControl.type == VRCExpressionsMenu.Control.ControlType.Toggle)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Preview Off")) SetTogglePreviewOnOff(toggle, false);
                if (GUILayout.Button("Preview On")) SetTogglePreviewOnOff(toggle, true);
                EditorGUILayout.EndHorizontal();
            }

            for (int i = 0; i < names.Count; i++)
            {
                string parameterName = names[i];
                string type = toggle.parameterTypes != null && i < toggle.parameterTypes.Count
                    ? toggle.parameterTypes[i]
                    : "Unknown";
                if (i == 0 && string.Equals(type, "Unknown", StringComparison.OrdinalIgnoreCase) && toggle.hasIntState)
                    type = "Int";
                float value = parameterPreviewValues.TryGetValue(parameterName, out float storedValue)
                    ? storedValue
                    : GetDefaultPreviewParameterValue(parameterName);

                EditorGUI.BeginChangeCheck();
                if (string.Equals(type, "Int", StringComparison.OrdinalIgnoreCase))
                    value = EditorGUILayout.IntField(parameterName, Mathf.RoundToInt(value));
                else if (string.Equals(type, "Bool", StringComparison.OrdinalIgnoreCase))
                    value = EditorGUILayout.Toggle(parameterName, value != 0f) ? 1f : 0f;
                else if (string.Equals(type, "Float", StringComparison.OrdinalIgnoreCase))
                    value = EditorGUILayout.Slider(parameterName, value, -1f, 1f);
                else
                    value = EditorGUILayout.FloatField(parameterName, value);

                if (EditorGUI.EndChangeCheck())
                {
                    previewSessionToggles.Add(toggle);
                    previewEnabledToggles.Add(toggle);
                    parameterPreviewValues[parameterName] = value;
                    ApplyParameterDrivenPreview(toggle);
                }
            }

            if (!string.IsNullOrEmpty(parameterPreviewStatus))
                EditorGUILayout.HelpBox(parameterPreviewStatus, MessageType.Info);
            EditorGUILayout.EndVertical();
        }

        private void InitializeParameterPreviewValues(ClothingToggleData toggle, bool enabled)
        {
            parameterPreviewStatus = null;
            if (toggle == null) return;

            List<string> names = GetToggleParameterNames(toggle);
            foreach (string name in names)
                if (!parameterPreviewValues.ContainsKey(name))
                    parameterPreviewValues[name] = GetDefaultPreviewParameterValue(name);

            if (names.Count == 0) return;
            if (!enabled && toggle.sourceControl != null && GetPlayableParameterType(names[0]).HasValue &&
                !Mathf.Approximately(GetPlayableParameterValue(names[0]), GetToggleOnValue(toggle))) return;
            parameterPreviewValues[names[0]] = enabled ? GetToggleOnValue(toggle) : 0f;
        }

        private void ClearParameterPreviewState()
        {
            parameterPreviewValues.Clear();
            previewSessionToggles.Clear();
            previewEnabledToggles.Clear();
            parameterPreviewStatus = null;
        }

        private void SetTogglePreviewOnOff(ClothingToggleData toggle, bool enabled)
        {
            if (toggle == null) return;
            previewedToggle = toggle;
            previewSessionToggles.Add(toggle);
            if (enabled) previewEnabledToggles.Add(toggle);
            else previewEnabledToggles.Remove(toggle);
            InitializeParameterPreviewValues(toggle, enabled);
            if (HasPreviewableParameter(toggle)) ApplyParameterDrivenPreview(toggle);
            RefreshSelectedToggleObjectActiveStates();
        }

        private float GetDefaultPreviewParameterValue(string parameterName)
        {
            if (avatarDescriptor != null && avatarDescriptor.expressionParameters != null &&
                avatarDescriptor.expressionParameters.parameters != null)
            {
                VRCExpressionParameters.Parameter expressionParameter = avatarDescriptor.expressionParameters.parameters.FirstOrDefault(parameter =>
                    string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
                if (expressionParameter != null) return expressionParameter.defaultValue;
            }

            AnimatorController fx = avatarDescriptor != null ? GetFxController(avatarDescriptor) : null;
            if (fx != null)
            {
                AnimatorControllerParameter controllerParameter = fx.parameters.FirstOrDefault(parameter =>
                    string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase));
                if (controllerParameter != null)
                {
                    if (controllerParameter.type == AnimatorControllerParameterType.Int) return controllerParameter.defaultInt;
                    if (controllerParameter.type == AnimatorControllerParameterType.Bool) return controllerParameter.defaultBool ? 1f : 0f;
                    return controllerParameter.defaultFloat;
                }
            }
            return 0f;
        }

        private void ApplyParameterDrivenPreview(ClothingToggleData toggle)
        {
            if (toggle == null || toggle != previewedToggle) return;
            RuntimeAnimatorController fx = avatarDescriptor != null ? GetFxRuntimeController(avatarDescriptor) : null;
            if (fx == null)
            {
                StopParameterDrivenPreview();
                parameterPreviewStatus = "No custom FX Animator Controller is assigned, so there is no FX state to preview.";
                return;
            }

            if (ownsAnimationPreviewMode && AnimationMode.InAnimationMode())
            {
                AnimationMode.StopAnimationMode();
                ownsAnimationPreviewMode = false;
                previewAnimationClip = null;
            }

            bool graphCreated = false;
            if (!parameterPreviewGraph.IsValid() || parameterPreviewAvatar == null || parameterPreviewAnimator == null)
            {
                StopParameterDrivenPreview();
                if (!StartParameterDrivenPreview(fx))
                {
                    if (string.IsNullOrEmpty(parameterPreviewStatus))
                        parameterPreviewStatus = "Could not start the FX preview. Check that the avatar has a valid Animator and FX controller.";
                    return;
                }
                graphCreated = true;
            }

            if (graphCreated) ApplyExpressionParameterDefaults();
            ApplyParameterPreviewValues();
            parameterPreviewGraph.Evaluate(0f);
            ApplyPreviewTPose();
            parameterPreviewStatus = parameterPreviewHasTPose
                ? "Driving the FX Animator with the body held in its T-pose."
                : string.IsNullOrEmpty(parameterPreviewPoseWarning)
                    ? "Driving the FX Animator with these expression values."
                    : parameterPreviewPoseWarning;
            SceneView.RepaintAll();
        }

        private bool StartParameterDrivenPreview(RuntimeAnimatorController controller)
        {
            if (avatarDescriptor == null || controller == null) return false;
            GameObject sourceAvatar = avatarDescriptor.gameObject;
            if (EditorUtility.IsPersistent(sourceAvatar) || !sourceAvatar.scene.IsValid())
            {
                parameterPreviewStatus = "Assign an avatar instance from the open Scene to preview its FX controller.";
                return false;
            }
            Animator sourceAnimator = sourceAvatar.GetComponent<Animator>();
            if (sourceAnimator == null) sourceAnimator = sourceAvatar.GetComponentInChildren<Animator>(true);

            try
            {
                parameterPreviewAvatar = Instantiate(sourceAvatar, sourceAvatar.transform.parent, true);
                parameterPreviewAvatar.name = sourceAvatar.name + " [NINSA FX Preview]";
                parameterPreviewAvatar.hideFlags = HideFlags.HideInHierarchy | HideFlags.HideInInspector |
                    HideFlags.DontSaveInEditor | HideFlags.DontSaveInBuild;
                parameterPreviewAvatar.SetActive(true);

                foreach (Behaviour behaviour in parameterPreviewAvatar.GetComponentsInChildren<Behaviour>(true))
                {
                    if (behaviour is Animator) continue;
                    behaviour.enabled = false;
                }
                foreach (Collider collider in parameterPreviewAvatar.GetComponentsInChildren<Collider>(true))
                    collider.enabled = false;
                foreach (Renderer renderer in parameterPreviewAvatar.GetComponentsInChildren<Renderer>(true))
                    renderer.forceRenderingOff = false;

                parameterPreviewAnimator = null;
                if (sourceAnimator != null)
                {
                    string animatorPath = AnimationUtility.CalculateTransformPath(sourceAnimator.transform, sourceAvatar.transform);
                    Transform clonedAnimatorTransform = string.IsNullOrEmpty(animatorPath)
                        ? parameterPreviewAvatar.transform
                        : parameterPreviewAvatar.transform.Find(animatorPath);
                    if (clonedAnimatorTransform != null)
                        parameterPreviewAnimator = clonedAnimatorTransform.GetComponent<Animator>();
                }
                if (parameterPreviewAnimator == null)
                    parameterPreviewAnimator = parameterPreviewAvatar.GetComponent<Animator>();
                if (parameterPreviewAnimator == null)
                    parameterPreviewAnimator = parameterPreviewAvatar.AddComponent<Animator>();
                if (sourceAnimator != null) parameterPreviewAnimator.avatar = sourceAnimator.avatar;
                parameterPreviewAnimator.enabled = true;
                parameterPreviewAnimator.applyRootMotion = false;
                parameterPreviewAnimator.runtimeAnimatorController = null;
                parameterPreviewAnimator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                CapturePreviewRigPlacement();
                InitializePreviewTPose();

                foreach (Renderer renderer in sourceAvatar.GetComponentsInChildren<Renderer>(true))
                {
                    if (renderer == null || parameterPreviewRendererStates.ContainsKey(renderer)) continue;
                    parameterPreviewRendererStates.Add(renderer, renderer.forceRenderingOff);
                    renderer.forceRenderingOff = true;
                }

                parameterPreviewGraph = PlayableGraph.Create("NINSA FX Parameter Preview");
                parameterPreviewGraph.SetTimeUpdateMode(DirectorUpdateMode.Manual);
                parameterPreviewController = AnimatorControllerPlayable.Create(parameterPreviewGraph, controller);
                int layerCount = parameterPreviewTPoseClip != null ? 2 : 1;
                AnimationLayerMixerPlayable mixer = AnimationLayerMixerPlayable.Create(parameterPreviewGraph, layerCount);
                mixer.ConnectInput(0, parameterPreviewController, 0, 1f);
                AvatarMask fxMask = GetFxLayerMask(avatarDescriptor);
                if (fxMask != null) mixer.SetLayerMaskFromAvatarMask(0, fxMask);
                if (parameterPreviewTPoseClip != null)
                {
                    parameterPreviewTPosePlayable = AnimationClipPlayable.Create(parameterPreviewGraph, parameterPreviewTPoseClip);
                    parameterPreviewTPosePlayable.SetApplyFootIK(false);
                    parameterPreviewTPosePlayable.SetApplyPlayableIK(false);
                    parameterPreviewTPosePlayable.SetSpeed(0d);
                    mixer.ConnectInput(1, parameterPreviewTPosePlayable, 0, 1f);
                    parameterPreviewTPoseMask = CreatePreviewTPoseMask();
                    mixer.SetLayerMaskFromAvatarMask(1, parameterPreviewTPoseMask);
                    mixer.SetInputWeight(1, 1f);
                }
                AnimationPlayableOutput output = AnimationPlayableOutput.Create(parameterPreviewGraph,
                    "NINSA FX Preview", parameterPreviewAnimator);
                output.SetSourcePlayable(mixer);
                parameterPreviewGraph.Play();
                lastParameterPreviewUpdateTime = EditorApplication.timeSinceStartup;
                EditorApplication.DirtyHierarchyWindowSorting();
                return true;
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
                StopParameterDrivenPreview();
                return false;
            }
        }

        private AvatarMask GetFxLayerMask(VRCAvatarDescriptor descriptor)
        {
            if (descriptor == null || descriptor.baseAnimationLayers == null) return null;
            foreach (VRCAvatarDescriptor.CustomAnimLayer layer in descriptor.baseAnimationLayers)
                if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && !layer.isDefault)
                    return layer.mask;
            return null;
        }

        private static AvatarMask CreatePreviewTPoseMask()
        {
            AvatarMask mask = new AvatarMask { hideFlags = HideFlags.HideAndDontSave };
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.Root, false);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.Body, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.Head, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.LeftArm, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.RightArm, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.LeftFingers, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.RightFingers, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.LeftLeg, true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.RightLeg, true);
            return mask;
        }

        private void InitializePreviewTPose()
        {
            parameterPreviewHasTPose = false;
            parameterPreviewPoseWarning = null;
            if (parameterPreviewAnimator == null || parameterPreviewAnimator.avatar == null ||
                !parameterPreviewAnimator.avatar.isHuman)
            {
                parameterPreviewPoseWarning = "This avatar does not use a Humanoid rig, so its preview cannot be held in a T-pose.";
                return;
            }

            parameterPreviewTPoseClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(
                "Packages/com.vrchat.avatars/Samples/AV3 Demo Assets/Animation/ProxyAnim/proxy_tpose.anim");
            if (parameterPreviewTPoseClip == null)
            {
                string[] tPoseGuids = AssetDatabase.FindAssets("proxy_tpose t:AnimationClip");
                foreach (string guid in tPoseGuids)
                {
                    parameterPreviewTPoseClip = AssetDatabase.LoadAssetAtPath<AnimationClip>(AssetDatabase.GUIDToAssetPath(guid));
                    if (parameterPreviewTPoseClip != null) break;
                }
            }
            if (parameterPreviewTPoseClip != null)
            {
                parameterPreviewHasTPose = true;
                return;
            }

            try
            {
                parameterPreviewHumanPoseHandler = new HumanPoseHandler(
                    parameterPreviewAnimator.avatar, parameterPreviewAnimator.transform);
                parameterPreviewTPose.muscles = new float[HumanTrait.MuscleCount];
                parameterPreviewHumanPoseHandler.GetHumanPose(ref parameterPreviewTPose);
                Array.Clear(parameterPreviewTPose.muscles, 0, parameterPreviewTPose.muscles.Length);

                parameterPreviewTPose.bodyRotation = Quaternion.identity;
                parameterPreviewHumanPoseHandler.SetHumanPose(ref parameterPreviewTPose);
                parameterPreviewHasTPose = true;
            }
            catch (Exception exception)
            {
                if (parameterPreviewHumanPoseHandler != null)
                    parameterPreviewHumanPoseHandler.Dispose();
                parameterPreviewHumanPoseHandler = null;
                parameterPreviewPoseWarning = "Could not set a T-pose for this avatar: " + exception.Message;
                Debug.LogWarning(parameterPreviewPoseWarning, parameterPreviewAvatar);
            }
        }

        private void CapturePreviewRigPlacement()
        {
            previewRigPositions.Clear();
            previewRigScales.Clear();
            previewRootRotation = parameterPreviewAvatar.transform.localRotation;
            previewAnimatorRootRotation = parameterPreviewAnimator.transform.localRotation;
            HashSet<Transform> rig = new HashSet<Transform> { parameterPreviewAvatar.transform };
            if (parameterPreviewAnimator.avatar != null && parameterPreviewAnimator.avatar.isHuman)
            {
                foreach (HumanBodyBones bone in Enum.GetValues(typeof(HumanBodyBones)))
                {
                    if (bone == HumanBodyBones.LastBone) continue;
                    Transform joint = parameterPreviewAnimator.GetBoneTransform(bone);
                    while (joint != null && joint.IsChildOf(parameterPreviewAvatar.transform))
                    {
                        rig.Add(joint);
                        if (joint == parameterPreviewAvatar.transform) break;
                        joint = joint.parent;
                    }
                }
            }
            foreach (Transform joint in rig)
            {
                previewRigPositions[joint] = joint.localPosition;
                previewRigScales[joint] = joint.localScale;
            }
        }

        private void RestorePreviewRigPlacement()
        {
            foreach (KeyValuePair<Transform, Vector3> joint in previewRigPositions)
                if (joint.Key != null) joint.Key.localPosition = joint.Value;
            foreach (KeyValuePair<Transform, Vector3> joint in previewRigScales)
                if (joint.Key != null) joint.Key.localScale = joint.Value;
            if (parameterPreviewAvatar != null)
                parameterPreviewAvatar.transform.localRotation = previewRootRotation;
            if (parameterPreviewAnimator != null)
                parameterPreviewAnimator.transform.localRotation = previewAnimatorRootRotation;
        }

        private void ApplyPreviewTPose()
        {
            if (!parameterPreviewHasTPose || parameterPreviewHumanPoseHandler == null)
            {
                RestorePreviewRigPlacement();
                return;
            }
            try
            {
                parameterPreviewHumanPoseHandler.SetHumanPose(ref parameterPreviewTPose);
            }
            catch (Exception exception)
            {
                parameterPreviewHasTPose = false;
                parameterPreviewPoseWarning = "Could not keep the preview avatar in a T-pose: " + exception.Message;
                parameterPreviewStatus = parameterPreviewPoseWarning;
                if (parameterPreviewHumanPoseHandler != null)
                    parameterPreviewHumanPoseHandler.Dispose();
                parameterPreviewHumanPoseHandler = null;
                Debug.LogWarning(parameterPreviewPoseWarning, parameterPreviewAvatar);
            }
            RestorePreviewRigPlacement();
        }

        private void ApplyExpressionParameterDefaults()
        {
            if (!parameterPreviewController.IsValid() || avatarDescriptor == null ||
                avatarDescriptor.expressionParameters == null || avatarDescriptor.expressionParameters.parameters == null) return;

            foreach (VRCExpressionParameters.Parameter parameter in avatarDescriptor.expressionParameters.parameters)
                SetPlayableParameterValue(parameter.name, parameter.defaultValue);
        }

        private void ApplyParameterPreviewValues()
        {
            if (!parameterPreviewController.IsValid()) return;
            foreach (KeyValuePair<string, float> parameter in parameterPreviewValues)
                SetPlayableParameterValue(parameter.Key, parameter.Value);
        }

        private void OnPreviewParameterDriverSettings(VRC_AvatarParameterDriver driver, Animator animator)
        {
            if (driver == null || animator == null || animator != parameterPreviewAnimator ||
                !parameterPreviewController.IsValid() || driver.parameters == null) return;

            foreach (VRC_AvatarParameterDriver.Parameter drivenParameter in driver.parameters)
            {
                if (string.IsNullOrWhiteSpace(drivenParameter.name)) continue;
                float currentValue = GetPlayableParameterValue(drivenParameter.name);
                float nextValue;

                switch (drivenParameter.type)
                {
                    case VRC_AvatarParameterDriver.ChangeType.Set:
                        nextValue = drivenParameter.value;
                        break;
                    case VRC_AvatarParameterDriver.ChangeType.Add:
                        nextValue = currentValue + drivenParameter.value;
                        break;
                    case VRC_AvatarParameterDriver.ChangeType.Copy:
                        nextValue = GetPlayableParameterValue(drivenParameter.source);
                        if (drivenParameter.convertRange)
                        {
                            float sourceLength = drivenParameter.sourceMax - drivenParameter.sourceMin;
                            float normalized = Mathf.Approximately(sourceLength, 0f)
                                ? 0f
                                : Mathf.Clamp01((nextValue - drivenParameter.sourceMin) / sourceLength);
                            nextValue = Mathf.Lerp(drivenParameter.destMin, drivenParameter.destMax, normalized);
                        }
                        break;
                    case VRC_AvatarParameterDriver.ChangeType.Random:
                        AnimatorControllerParameterType? targetType = GetPlayableParameterType(drivenParameter.name);
                        if (!targetType.HasValue) continue;
                        if (targetType.Value == AnimatorControllerParameterType.Int)
                        {
                            int min = (int)drivenParameter.valueMin;
                            int max = (int)drivenParameter.valueMax;
                            nextValue = UnityEngine.Random.Range(min, max == int.MaxValue ? max : max + 1);
                        }
                        else if (targetType.Value == AnimatorControllerParameterType.Bool ||
                                 targetType.Value == AnimatorControllerParameterType.Trigger)
                        {
                            nextValue = UnityEngine.Random.value < drivenParameter.chance ? 1f : 0f;
                        }
                        else
                        {
                            nextValue = UnityEngine.Random.Range(drivenParameter.valueMin, drivenParameter.valueMax);
                        }
                        break;
                    default:
                        continue;
                }

                SetPlayableParameterValue(drivenParameter.name, nextValue);
                parameterPreviewValues[drivenParameter.name] = nextValue;
            }

            Repaint();
        }

        private AnimatorControllerParameterType? GetPlayableParameterType(string parameterName)
        {
            if (!parameterPreviewController.IsValid() || string.IsNullOrWhiteSpace(parameterName)) return null;
            for (int i = 0; i < parameterPreviewController.GetParameterCount(); i++)
            {
                AnimatorControllerParameter parameter = parameterPreviewController.GetParameter(i);
                if (string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
                    return parameter.type;
            }
            return null;
        }

        private float GetPlayableParameterValue(string parameterName)
        {
            if (!parameterPreviewController.IsValid() || string.IsNullOrWhiteSpace(parameterName)) return 0f;
            for (int i = 0; i < parameterPreviewController.GetParameterCount(); i++)
            {
                AnimatorControllerParameter parameter = parameterPreviewController.GetParameter(i);
                if (!string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase)) continue;
                int hash = Animator.StringToHash(parameter.name);
                switch (parameter.type)
                {
                    case AnimatorControllerParameterType.Int:
                        return parameterPreviewController.GetInteger(hash);
                    case AnimatorControllerParameterType.Bool:
                    case AnimatorControllerParameterType.Trigger:
                        return parameterPreviewController.GetBool(hash) ? 1f : 0f;
                    case AnimatorControllerParameterType.Float:
                        return parameterPreviewController.GetFloat(hash);
                }
            }
            return 0f;
        }

        private void SetPlayableParameterValue(string parameterName, float value)
        {
            if (!parameterPreviewController.IsValid() || string.IsNullOrWhiteSpace(parameterName)) return;

            for (int i = 0; i < parameterPreviewController.GetParameterCount(); i++)
            {
                AnimatorControllerParameter parameter = parameterPreviewController.GetParameter(i);
                if (!string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase)) continue;
                int hash = Animator.StringToHash(parameter.name);
                if (parameterPreviewController.IsParameterControlledByCurve(hash)) return;
                switch (parameter.type)
                {
                    case AnimatorControllerParameterType.Int:
                        parameterPreviewController.SetInteger(hash, Mathf.RoundToInt(value));
                        break;
                    case AnimatorControllerParameterType.Bool:
                        parameterPreviewController.SetBool(hash, !Mathf.Approximately(value, 0f));
                        break;
                    case AnimatorControllerParameterType.Trigger:
                        if (!Mathf.Approximately(value, 0f)) parameterPreviewController.SetTrigger(hash);
                        else parameterPreviewController.ResetTrigger(hash);
                        break;
                    case AnimatorControllerParameterType.Float:
                        parameterPreviewController.SetFloat(hash, value);
                        break;
                }
                return;
            }
        }

        private void UpdateParameterPreviewGraph()
        {
            if (!parameterPreviewGraph.IsValid() || !parameterPreviewGraph.IsPlaying()) return;
            double now = EditorApplication.timeSinceStartup;
            float deltaTime = Mathf.Clamp((float)(now - lastParameterPreviewUpdateTime), 0f, 0.1f);
            lastParameterPreviewUpdateTime = now;
            if (parameterPreviewAvatar != null && !parameterPreviewAvatar.activeSelf)
                parameterPreviewAvatar.SetActive(true);
            parameterPreviewGraph.Evaluate(deltaTime);
            ApplyPreviewTPose();
            if (parameterPreviewAvatar != null && !parameterPreviewAvatar.activeSelf)
                parameterPreviewAvatar.SetActive(true);
            SceneView.RepaintAll();
        }

        private void StopParameterDrivenPreview()
        {
            if (parameterPreviewGraph.IsValid()) parameterPreviewGraph.Destroy();
            parameterPreviewController = default(AnimatorControllerPlayable);
            parameterPreviewTPosePlayable = default(AnimationClipPlayable);
            parameterPreviewTPoseClip = null;
            if (parameterPreviewTPoseMask != null) DestroyImmediate(parameterPreviewTPoseMask);
            parameterPreviewTPoseMask = null;
            parameterPreviewAnimator = null;
            if (parameterPreviewHumanPoseHandler != null)
                parameterPreviewHumanPoseHandler.Dispose();
            parameterPreviewHumanPoseHandler = null;
            parameterPreviewHasTPose = false;
            parameterPreviewPoseWarning = null;
            previewRigPositions.Clear();
            previewRigScales.Clear();

            foreach (KeyValuePair<Renderer, bool> entry in parameterPreviewRendererStates.ToArray())
                if (entry.Key != null) entry.Key.forceRenderingOff = entry.Value;
            parameterPreviewRendererStates.Clear();

            if (parameterPreviewAvatar != null)
                DestroyImmediate(parameterPreviewAvatar);
            parameterPreviewAvatar = null;
            EditorApplication.DirtyHierarchyWindowSorting();
            SceneView.RepaintAll();
        }

        private bool CanStartAnimationClipPreview()
        {
            return avatarDescriptor != null &&
                (!AnimationMode.InAnimationMode() || ownsAnimationPreviewMode);
        }

        private void StartAnimationClipPreview(AnimationClip clip)
        {
            if (clip == null || avatarDescriptor == null || !CanStartAnimationClipPreview()) return;
            StopParameterDrivenPreview();
            if (ownsAnimationPreviewMode && AnimationMode.InAnimationMode())
                AnimationMode.StopAnimationMode();
            ownsAnimationPreviewMode = false;
            if (!AnimationMode.InAnimationMode())
            {
                AnimationMode.StartAnimationMode();
                ownsAnimationPreviewMode = AnimationMode.InAnimationMode();
            }

            if (!ownsAnimationPreviewMode) return;
            previewAnimationClip = clip;
            previewAnimationTime = 0f;
            SamplePreviewAnimationClip();
        }

        private void SamplePreviewAnimationClip()
        {
            if (!ownsAnimationPreviewMode || previewAnimationClip == null || avatarDescriptor == null ||
                !AnimationMode.InAnimationMode()) return;

            AnimationMode.BeginSampling();
            try
            {
                AnimationMode.SampleAnimationClip(avatarDescriptor.gameObject, previewAnimationClip,
                    Mathf.Clamp(previewAnimationTime, 0f, previewAnimationClip.length));
            }
            finally
            {
                AnimationMode.EndSampling();
            }
            SceneView.RepaintAll();
            Repaint();
        }

        private void StopAnimationClipPreview()
        {
            if (ownsAnimationPreviewMode && AnimationMode.InAnimationMode())
                AnimationMode.StopAnimationMode();
            ownsAnimationPreviewMode = false;
            previewAnimationClip = null;
            previewAnimationTime = 0f;
            StopParameterDrivenPreview();
            SceneView.RepaintAll();
        }

        private List<GameObject> GetToggleLinkedObjects(ClothingToggleData toggle)
        {
            List<GameObject> targets = new List<GameObject>();
            if (toggle == null) return targets;
            if (toggle.clothingObject != null && toggle.clothingObject != (avatarDescriptor != null ? avatarDescriptor.gameObject : null) &&
                !EditorUtility.IsPersistent(toggle.clothingObject))
                targets.Add(toggle.clothingObject);
            if (toggle.animatedObjects != null)
            {
                foreach (GameObject target in toggle.animatedObjects)
                    if (target != null && target != (avatarDescriptor != null ? avatarDescriptor.gameObject : null) &&
                        !EditorUtility.IsPersistent(target) && !targets.Contains(target))
                        targets.Add(target);
            }
            return targets;
        }

        private void SetToggleSelectedForRemoval(ClothingToggleData toggle, bool selected)
        {
            if (toggle == null) return;
            toggle.isSelectedForRemoval = selected;
            RefreshSelectedToggleObjectActiveStates();
        }

        private void RefreshSelectedToggleObjectActiveStates()
        {
            HashSet<GameObject> selectedObjects = new HashSet<GameObject>();
            foreach (ClothingToggleData toggle in detectedToggles)
            {
                if (!toggle.isSelectedForRemoval) continue;
                foreach (GameObject target in GetToggleLinkedObjects(toggle))
                    if (target != null && target.scene.IsValid()) selectedObjects.Add(target);
            }

            foreach (ClothingToggleData previewToggle in previewSessionToggles)
            {
                if (!IsTogglePreviewActive(previewToggle) ||
                    (HasPreviewableParameter(previewToggle) && parameterPreviewGraph.IsValid())) continue;
                foreach (GameObject target in GetToggleLinkedObjects(previewToggle))
                {
                    Transform current = target != null ? target.transform : null;
                    while (current != null && current.gameObject.scene.IsValid())
                    {
                        selectedObjects.Add(current.gameObject);
                        if (avatarDescriptor != null && current == avatarDescriptor.transform) break;
                        current = current.parent;
                    }
                }
            }

            foreach (GameObject target in selectedObjects)
            {
                bool originalActive;
                if (!selectedToggleObjectOriginalActiveStates.TryGetValue(target, out originalActive))
                {
                    originalActive = target.activeSelf;
                    selectedToggleObjectOriginalActiveStates[target] = originalActive;
                }

                if (!originalActive && !target.activeSelf)
                    SetSelectedToggleObjectActive(target, true, "Temporarily Show Selected Toggle Object");
            }

            foreach (GameObject target in selectedToggleObjectOriginalActiveStates.Keys.ToArray())
            {
                if (target != null && selectedObjects.Contains(target)) continue;
                bool originalActive = selectedToggleObjectOriginalActiveStates[target];
                if (target != null && !originalActive && target.activeSelf)
                    SetSelectedToggleObjectActive(target, false, "Restore Toggle Object Active State");
                selectedToggleObjectOriginalActiveStates.Remove(target);
            }

            SceneView.RepaintAll();
            Repaint();
        }

        private void RestoreSelectedToggleObjectActiveStates()
        {
            foreach (KeyValuePair<GameObject, bool> entry in selectedToggleObjectOriginalActiveStates.ToArray())
            {
                GameObject target = entry.Key;
                if (target != null && !entry.Value && target.activeSelf)
                    SetSelectedToggleObjectActive(target, false, "Restore Toggle Object Active State");
            }
            selectedToggleObjectOriginalActiveStates.Clear();
            SceneView.RepaintAll();
        }

        private static void SetSelectedToggleObjectActive(GameObject target, bool active, string undoLabel)
        {
            if (target == null || EditorUtility.IsPersistent(target) || !target.scene.IsValid()) return;
            Undo.RecordObject(target, undoLabel);
            target.SetActive(active);
            PrefabUtility.RecordPrefabInstancePropertyModifications(target);
        }

        private void SaveColor(string key, Color color) { EditorPrefs.SetString(key, "#" + ColorUtility.ToHtmlStringRGBA(color)); }
        private Color LoadColor(string key, Color defaultColor)
        {
            if (EditorPrefs.HasKey(key) && ColorUtility.TryParseHtmlString(EditorPrefs.GetString(key), out Color color))
                return color;
            return defaultColor;
        }
        #endregion

        #region Real VRChat Logic
        private void ScanAvatarData()
        {
            StopAnimationClipPreview();
            RestoreSelectedToggleObjectActiveStates();
            previewedToggle = null;
            ClearParameterPreviewState();
            detectedToggles.Clear();
            showMultiDeletePreview = false;
            forceDeleteLinkedObjects = false;
            previewLinkedObjects.Clear();
            previewObjectsToDelete.Clear();
            previewDeleteEligibleObjects.Clear();
            previewObjectsToKeep.Clear();
            previewLinkedObjectCount = 0;
            previewRetainedObjectCount = 0;

            if (avatarDescriptor == null) return;

            AnimatorController fx = settingScanFxControllers ? GetFxController(avatarDescriptor) : null;
            List<VRCExpressionsMenu> menuStack = new List<VRCExpressionsMenu>();

            if (avatarDescriptor.expressionsMenu != null)
            {
                currentRadialMenu = avatarDescriptor.expressionsMenu;
                menuHistory.Clear();
                menuPathHistory.Clear();
                currentRadialMenuPath = "Root";

                ScanMenuRecursive(avatarDescriptor.expressionsMenu, avatarDescriptor.gameObject, fx, "Root", menuStack);
            }
            else
            {
                currentRadialMenu = null;
            }

            if (avatarDescriptor.expressionParameters != null && avatarDescriptor.expressionParameters.parameters != null)
            {
                foreach (var param in avatarDescriptor.expressionParameters.parameters)
                {
                    if (string.IsNullOrEmpty(param.name)) continue;

                    bool exists = detectedToggles.Exists(t => GetToggleParameterNames(t).Contains(param.name, StringComparer.OrdinalIgnoreCase));
                    if (!exists)
                    {
                        bool hasGo, hasBs, hasMat;
                        List<GameObject> animatedObjects;
                        List<AnimationClip> relatedClips;
                        List<string> parameterNames = new List<string> { param.name };
                        GameObject targetObj = ResolveTargetObject(fx, param.name, parameterNames, avatarDescriptor.gameObject,
                            out hasGo, out hasBs, out hasMat, out animatedObjects, out relatedClips);
                        string parameterType = GetParameterTypeName(param.name, fx);

                        if (hasGo || hasBs || hasMat || targetObj != null)
                        {
                            detectedToggles.Add(new ClothingToggleData
                            {
                                toggleName = param.name,
                                controlType = "Unlinked Parameter",
                                clothingObject = targetObj,
                                menuPath = "Expression Parameters (Unlinked)",
                                parameterName = param.name,
                                parameterNames = parameterNames,
                                parameterTypes = new List<string> { parameterType },
                                relatedClips = relatedClips,
                                transitionRules = GetTransitionRulesForParameters(fx, parameterNames),
                                hasOnOff = hasGo,
                                hasBlendShape = hasBs,
                                hasMaterialProperty = hasMat,
                                hasIntState = string.Equals(parameterType, "Int", StringComparison.OrdinalIgnoreCase),
                                hasFloatState = string.Equals(parameterType, "Float", StringComparison.OrdinalIgnoreCase),
                                animatedObjects = animatedObjects,
                                sourceMenu = null,
                                sourceControl = null,
                                isSelectedForRemoval = false,
                                isExpanded = false
                            });
                        }
                    }
                }
            }

            DetectParameterSharing();
            SceneView.RepaintAll();
        }

        private void ScanMenuRecursive(VRCExpressionsMenu menu, GameObject avatarRoot, AnimatorController fx, string currentPath, List<VRCExpressionsMenu> menuStack)
        {
            if (menu == null || menu.controls == null || menuStack.Contains(menu)) return;
            menuStack.Add(menu);

            foreach (var control in menu.controls)
            {
                if (control == null) continue;
                
                if (control.subMenu != null || control.type == VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    if (control.subMenu != null)
                    {
                        string path = $"{currentPath} > {control.name}";
                        ScanMenuRecursive(control.subMenu, avatarRoot, fx, path, menuStack);
                    }
                }

                if (control.type != VRCExpressionsMenu.Control.ControlType.SubMenu)
                {
                    List<string> parameterNames = GetControlParameterNames(control);
                    string paramName = parameterNames.Count > 0 ? parameterNames[0] : "";

                    bool hasGo, hasBs, hasMat;
                    List<GameObject> animatedObjects;
                    List<AnimationClip> relatedClips;
                    GameObject targetObj = ResolveTargetObject(fx, control.name, parameterNames, avatarRoot,
                        out hasGo, out hasBs, out hasMat, out animatedObjects, out relatedClips);
                    List<string> parameterTypes = parameterNames
                        .Select(parameter => GetParameterTypeName(parameter, fx))
                        .ToList();

                    detectedToggles.Add(new ClothingToggleData
                    {
                        toggleName = control.name,
                        controlType = control.type.ToString(),
                        clothingObject = targetObj,
                        menuPath = currentPath,
                        parameterName = paramName,
                        parameterNames = parameterNames,
                        parameterTypes = parameterTypes,
                        relatedClips = relatedClips,
                        transitionRules = GetTransitionRulesForParameters(fx, parameterNames),
                        menuControlValue = control.value,
                        hasOnOff = hasGo || control.type == VRCExpressionsMenu.Control.ControlType.Toggle,
                        hasBlendShape = hasBs,
                        hasMaterialProperty = hasMat,
                        hasIntState = parameterTypes.Any(type => string.Equals(type, "Int", StringComparison.OrdinalIgnoreCase)) ||
                            control.value > 1f || HasIntStateDriver(fx, paramName),
                        hasFloatState = parameterTypes.Any(type => string.Equals(type, "Float", StringComparison.OrdinalIgnoreCase)),
                        animatedObjects = animatedObjects,
                        sourceMenu = menu,
                        sourceControl = control,
                        isSelectedForRemoval = false,
                        isExpanded = false
                    });
                }
            }

            menuStack.RemoveAt(menuStack.Count - 1);
        }

        private GameObject ResolveTargetObject(AnimatorController fx, string controlName, IList<string> paramNames,
            GameObject avatarRoot, out bool hasGameObject, out bool hasBlendShape, out bool hasMaterial,
            out List<GameObject> animatedObjects, out List<AnimationClip> relevantClips)
        {
            hasGameObject = false;
            hasBlendShape = false;
            hasMaterial = false;
            animatedObjects = new List<GameObject>();
            relevantClips = new List<AnimationClip>();

            if (avatarRoot == null) return null;

            string cleanName = CleanString(controlName);
            string cleanParam = paramNames != null && paramNames.Count > 0 ? CleanString(paramNames[0]) : "";

            GameObject directHierarchyMatch = FindBestHierarchyMatch(avatarRoot.transform, cleanName, cleanParam);
            if (paramNames != null)
            {
                foreach (string paramName in paramNames)
                {
                    foreach (AnimationClip clip in GetClipsForParameter(fx, paramName))
                        if (clip != null && !relevantClips.Contains(clip)) relevantClips.Add(clip);
                }
            }
            GameObject bestFxMatch = null;
            int bestScore = 0;
            GameObject bestActiveObjectMatch = null;
            int bestActiveObjectScore = 0;

            foreach (var clip in relevantClips)
            {
                if (clip == null) continue;
                var bindings = AnimationUtility.GetCurveBindings(clip);

                foreach (var binding in bindings)
                {
                    bool isGameObjectActiveBinding = binding.type == typeof(GameObject) && binding.propertyName == "m_IsActive";
                    if (isGameObjectActiveBinding)
                    {
                        hasGameObject = true;
                        Transform activeObject = string.IsNullOrEmpty(binding.path)
                            ? avatarRoot.transform
                            : avatarRoot.transform.Find(binding.path);
                        if (activeObject != null && activeObject != avatarRoot.transform)
                        {
                            GameObject activeGameObject = activeObject.gameObject;
                            if (!animatedObjects.Contains(activeGameObject)) animatedObjects.Add(activeGameObject);
                            int activeScore = ScoreMatch(activeGameObject.name, binding.path, cleanName, cleanParam);
                            if (activeScore > bestActiveObjectScore && activeGameObject != avatarRoot)
                            {
                                bestActiveObjectScore = activeScore;
                                bestActiveObjectMatch = activeGameObject;
                            }
                        }
                    }
                    else if (binding.propertyName.StartsWith("blendShape.")) hasBlendShape = true;
                    else if (binding.propertyName.Contains("material.") || binding.propertyName.StartsWith("_")) hasMaterial = true;

                    if (!string.IsNullOrEmpty(binding.path))
                    {
                        Transform found = avatarRoot.transform.Find(binding.path);
                        if (found != null)
                        {
                            int score = ScoreMatch(found.name, binding.path, cleanName, cleanParam);
                            if (score > bestScore && found.gameObject != avatarRoot)
                            {
                                bestScore = score;
                                bestFxMatch = found.gameObject;
                            }
                        }
                    }
                }
            }

            if (bestActiveObjectMatch != null) return bestActiveObjectMatch;

            if (directHierarchyMatch != null && (bestFxMatch == null || bestScore < 50))
            {
                return directHierarchyMatch;
            }

            return bestFxMatch != null ? bestFxMatch : directHierarchyMatch;
        }

        private List<string> GetControlParameterNames(VRCExpressionsMenu.Control control)
        {
            var names = new List<string>();
            if (control == null) return names;

            if (control.parameter != null && !string.IsNullOrWhiteSpace(control.parameter.name))
                names.Add(control.parameter.name.Trim());

            if (control.subParameters != null)
            {
                foreach (VRCExpressionsMenu.Control.Parameter parameter in control.subParameters)
                {
                    if (parameter == null || string.IsNullOrWhiteSpace(parameter.name)) continue;
                    string name = parameter.name.Trim();
                    if (!names.Contains(name, StringComparer.OrdinalIgnoreCase)) names.Add(name);
                }
            }

            return names;
        }

        private List<string> GetToggleParameterNames(ClothingToggleData toggle)
        {
            if (toggle == null) return new List<string>();
            if (toggle.parameterNames != null && toggle.parameterNames.Count > 0)
                return toggle.parameterNames.Where(name => !string.IsNullOrWhiteSpace(name)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return string.IsNullOrWhiteSpace(toggle.parameterName) ? new List<string>() : new List<string> { toggle.parameterName };
        }

        private string GetParameterTypeName(string parameterName, AnimatorController fx)
        {
            if (string.IsNullOrWhiteSpace(parameterName)) return "Unknown";
            if (avatarDescriptor != null && avatarDescriptor.expressionParameters != null &&
                avatarDescriptor.expressionParameters.parameters != null)
            {
                foreach (VRCExpressionParameters.Parameter parameter in avatarDescriptor.expressionParameters.parameters)
                    if (string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))
                        return parameter.valueType.ToString();
            }

            if (fx != null)
            {
                AnimatorControllerParameter parameter = fx.parameters.FirstOrDefault(candidate =>
                    string.Equals(candidate.name, parameterName, StringComparison.OrdinalIgnoreCase));
                if (parameter != null) return parameter.type.ToString();
            }

            return "Unknown";
        }

        private string GetActiveStateActionSummary(GameObject target, IList<AnimationClip> clips)
        {
            if (target == null || avatarDescriptor == null || clips == null || clips.Count == 0) return string.Empty;

            string path = AnimationUtility.CalculateTransformPath(target.transform, avatarDescriptor.transform);
            var enabledIn = new List<string>();
            var disabledIn = new List<string>();
            foreach (AnimationClip clip in clips)
            {
                if (clip == null) continue;
                var binding = EditorCurveBinding.DiscreteCurve(path, typeof(GameObject), "m_IsActive");
                AnimationCurve curve = AnimationUtility.GetEditorCurve(clip, binding);
                if (curve == null || curve.length == 0) continue;
                float value = curve.Evaluate(clip.length);
                List<string> destination = value >= 0.5f ? enabledIn : disabledIn;
                if (!destination.Contains(clip.name)) destination.Add(clip.name);
            }

            var actions = new List<string>();
            if (enabledIn.Count > 0) actions.Add("FX turns on: " + string.Join(", ", enabledIn.Take(2)));
            if (disabledIn.Count > 0) actions.Add("FX turns off: " + string.Join(", ", disabledIn.Take(2)));
            return string.Join("; ", actions);
        }

        private List<string> GetTransitionRulesForParameters(AnimatorController controller, IList<string> parameterNames)
        {
            var rules = new List<string>();
            if (controller == null || parameterNames == null || parameterNames.Count == 0) return rules;
            var names = new HashSet<string>(parameterNames.Where(name => !string.IsNullOrWhiteSpace(name)), StringComparer.OrdinalIgnoreCase);
            var uniqueRules = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (AnimatorControllerLayer layer in controller.layers)
            {
                if (layer == null || layer.stateMachine == null) continue;
                CollectTransitionRules(layer.stateMachine, layer.name, names, uniqueRules);
            }

            rules.AddRange(uniqueRules.OrderBy(rule => rule, StringComparer.OrdinalIgnoreCase));
            return rules;
        }

        private void CollectTransitionRules(AnimatorStateMachine stateMachine, string layerName,
            HashSet<string> parameterNames, HashSet<string> rules)
        {
            if (stateMachine == null) return;
            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
                AddTransitionRules(transition, layerName, parameterNames, rules);
            foreach (AnimatorTransition transition in stateMachine.entryTransitions)
                AddTransitionRules(transition, layerName, parameterNames, rules);

            foreach (ChildAnimatorState child in stateMachine.states)
            {
                if (child.state == null) continue;
                foreach (AnimatorStateTransition transition in child.state.transitions)
                    AddTransitionRules(transition, layerName, parameterNames, rules);
            }

            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
                CollectTransitionRules(child.stateMachine, layerName, parameterNames, rules);
        }

        private void AddTransitionRules(AnimatorTransitionBase transition, string layerName,
            HashSet<string> parameterNames, HashSet<string> rules)
        {
            if (transition == null) return;
            foreach (AnimatorCondition condition in transition.conditions)
            {
                if (!parameterNames.Contains(condition.parameter)) continue;
                string rule = (string.IsNullOrEmpty(layerName) ? "FX" : layerName) + " · " + condition.parameter +
                    " " + condition.mode + " " + condition.threshold.ToString("0.###");
                rules.Add(rule);
            }
        }

        private bool HasIntStateDriver(AnimatorController controller, string toggleParameter)
        {
            if (controller == null || string.IsNullOrEmpty(toggleParameter)) return false;
            string targetLayerName = "NINSA Toggle - " + toggleParameter;
            foreach (AnimatorControllerLayer layer in controller.layers)
            {
                if (layer == null || !string.Equals(layer.name, targetLayerName, StringComparison.OrdinalIgnoreCase) ||
                    layer.stateMachine == null) continue;
                foreach (ChildAnimatorState child in layer.stateMachine.states)
                {
                    if (child.state == null) continue;
                    foreach (VRCAvatarParameterDriver driver in child.state.behaviours.OfType<VRCAvatarParameterDriver>())
                    {
                        if (driver.parameters == null) continue;
                        foreach (VRC_AvatarParameterDriver.Parameter driven in driver.parameters)
                        {
                            AnimatorControllerParameter target = controller.parameters.FirstOrDefault(parameter =>
                                string.Equals(parameter.name, driven.name, StringComparison.OrdinalIgnoreCase));
                            if (target != null && target.type == AnimatorControllerParameterType.Int) return true;
                        }
                    }
                }
            }
            return false;
        }

        private string CleanString(string input)
        {
            if (string.IsNullOrEmpty(input)) return "";
            string s = input;
            int slash = s.LastIndexOf('/');
            if (slash >= 0) s = s.Substring(slash + 1);
            return s.Replace("Toggle", "").Replace("Root", "").Replace("Acc - ", "").Replace("Top/", "").Replace("Acc/", "").Trim().ToLower();
        }

        private int ScoreMatch(string objName, string path, string cleanName, string cleanParam)
        {
            string lName = objName.ToLower();
            string lPath = path.ToLower();
            int score = 0;

            if (!string.IsNullOrEmpty(cleanName))
            {
                if (lName == cleanName) score += 100;
                else if (lName.Contains(cleanName) || cleanName.Contains(lName)) score += 60;
                else if (lPath.Contains(cleanName)) score += 30;
            }

            if (!string.IsNullOrEmpty(cleanParam))
            {
                if (lName == cleanParam) score += 80;
                else if (lName.Contains(cleanParam) || cleanParam.Contains(lName)) score += 50;
                else if (lPath.Contains(cleanParam)) score += 20;
            }

            return score;
        }

        private GameObject FindBestHierarchyMatch(Transform root, string cleanName, string cleanParam)
        {
            if (string.IsNullOrEmpty(cleanName) && string.IsNullOrEmpty(cleanParam)) return null;

            Transform[] all = root.GetComponentsInChildren<Transform>(true);
            Transform best = null;
            int bestScore = 0;

            foreach (var t in all)
            {
                if (t == root) continue;
                int score = ScoreMatch(t.name, GetRelativePath(root, t), cleanName, cleanParam);
                if (score > bestScore && score >= 50)
                {
                    bestScore = score;
                    best = t;
                }
            }

            return best != null ? best.gameObject : null;
        }

        private string GetRelativePath(Transform root, Transform target)
        {
            List<string> path = new List<string>();
            Transform current = target;
            while (current != null && current != root)
            {
                path.Add(current.name);
                current = current.parent;
            }
            path.Reverse();
            return string.Join("/", path);
        }

        private List<AnimationClip> GetClipsForParameter(AnimatorController fx, string paramName)
        {
            List<AnimationClip> clips = new List<AnimationClip>();
            if (fx == null || string.IsNullOrEmpty(paramName)) return clips;

            foreach (var layer in fx.layers)
            {
                if (layer == null || layer.stateMachine == null) continue;
                bool layerNameMatches = !string.IsNullOrEmpty(layer.name) && layer.name.IndexOf(paramName, StringComparison.OrdinalIgnoreCase) >= 0;
                ScanStateMachineForParam(layer.stateMachine, paramName, layerNameMatches, clips);
            }
            return clips;
        }

        private List<AnimationClip> GetClipsForParameterValue(AnimatorController fx, string parameterName,
            float parameterValue, IDictionary<string, float> previewValues)
        {
            List<AnimationClip> clips = new List<AnimationClip>();
            if (fx == null || string.IsNullOrEmpty(parameterName)) return clips;

            foreach (AnimatorControllerLayer layer in fx.layers)
            {
                if (layer == null || layer.stateMachine == null ||
                    !StateMachineUsesParameter(layer.stateMachine, parameterName)) continue;

                List<AnimatorState> matchingStates = new List<AnimatorState>();
                CollectStatesForParameterValue(layer.stateMachine, fx, parameterName, parameterValue,
                    previewValues, matchingStates);

                if (matchingStates.Count == 0)
                    CollectDefaultStatesForParameter(layer.stateMachine, parameterName, matchingStates);

                foreach (AnimatorState state in matchingStates)
                    if (state != null) ExtractClipsFromMotion(state.motion, clips, new HashSet<Motion>());
            }

            return clips;
        }

        private void CollectStatesForParameterValue(AnimatorStateMachine stateMachine, AnimatorController controller,
            string parameterName, float parameterValue, IDictionary<string, float> previewValues, List<AnimatorState> states)
        {
            if (stateMachine == null) return;

            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
                AddMatchingTransitionState(transition, controller, parameterName, parameterValue, previewValues, states);
            foreach (AnimatorTransition transition in stateMachine.entryTransitions)
                AddMatchingTransitionState(transition, controller, parameterName, parameterValue, previewValues, states);

            foreach (ChildAnimatorState child in stateMachine.states)
            {
                if (child.state == null) continue;
                foreach (AnimatorStateTransition transition in child.state.transitions)
                    AddMatchingTransitionState(transition, controller, parameterName, parameterValue, previewValues, states);
            }

            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
                CollectStatesForParameterValue(child.stateMachine, controller, parameterName, parameterValue,
                    previewValues, states);
        }

        private void AddMatchingTransitionState(AnimatorTransitionBase transition, AnimatorController controller,
            string parameterName, float parameterValue, IDictionary<string, float> previewValues, List<AnimatorState> states)
        {
            if (transition == null || !TransitionUsesParameter(transition, parameterName) ||
                !TransitionConditionsMatch(transition, controller, parameterName, parameterValue, previewValues)) return;

            AnimatorState destination = null;
            if (transition is AnimatorStateTransition stateTransition)
                destination = stateTransition.destinationState;
            else if (transition is AnimatorTransition entryTransition)
                destination = entryTransition.destinationState;

            if (destination != null && !states.Contains(destination)) states.Add(destination);
        }

        private bool TransitionConditionsMatch(AnimatorTransitionBase transition, AnimatorController controller,
            string parameterName, float parameterValue, IDictionary<string, float> previewValues)
        {
            foreach (AnimatorCondition condition in transition.conditions)
            {
                float currentValue = string.Equals(condition.parameter, parameterName, StringComparison.OrdinalIgnoreCase)
                    ? parameterValue
                    : GetSimulatedParameterValue(controller, condition.parameter, previewValues);
                float threshold = condition.threshold;
                bool conditionMet;

                switch (condition.mode)
                {
                    case AnimatorConditionMode.If:
                        conditionMet = !Mathf.Approximately(currentValue, 0f);
                        break;
                    case AnimatorConditionMode.IfNot:
                        conditionMet = Mathf.Approximately(currentValue, 0f);
                        break;
                    case AnimatorConditionMode.Equals:
                        conditionMet = Mathf.RoundToInt(currentValue) == Mathf.RoundToInt(threshold);
                        break;
                    case AnimatorConditionMode.NotEqual:
                        conditionMet = Mathf.RoundToInt(currentValue) != Mathf.RoundToInt(threshold);
                        break;
                    case AnimatorConditionMode.Greater:
                        conditionMet = currentValue > threshold;
                        break;
                    case AnimatorConditionMode.Less:
                        conditionMet = currentValue < threshold;
                        break;
                    default:
                        conditionMet = false;
                        break;
                }

                if (!conditionMet) return false;
            }
            return true;
        }

        private float GetSimulatedParameterValue(AnimatorController controller, string parameterName,
            IDictionary<string, float> previewValues)
        {
            if (previewValues != null && previewValues.TryGetValue(parameterName, out float previewValue))
                return previewValue;
            if (avatarDescriptor != null && avatarDescriptor.expressionParameters != null &&
                avatarDescriptor.expressionParameters.parameters != null)
            {
                VRCExpressionParameters.Parameter expressionParameter = avatarDescriptor.expressionParameters.parameters.FirstOrDefault(candidate =>
                    string.Equals(candidate.name, parameterName, StringComparison.OrdinalIgnoreCase));
                if (expressionParameter != null) return expressionParameter.defaultValue;
            }
            if (controller == null) return 0f;

            AnimatorControllerParameter parameter = controller.parameters.FirstOrDefault(candidate =>
                string.Equals(candidate.name, parameterName, StringComparison.OrdinalIgnoreCase));
            if (parameter == null) return 0f;
            if (parameter.type == AnimatorControllerParameterType.Int) return parameter.defaultInt;
            if (parameter.type == AnimatorControllerParameterType.Bool) return parameter.defaultBool ? 1f : 0f;
            return parameter.defaultFloat;
        }

        private void CollectDefaultStatesForParameter(AnimatorStateMachine stateMachine, string parameterName,
            List<AnimatorState> states)
        {
            if (stateMachine == null) return;
            if (StateMachineUsesParameter(stateMachine, parameterName) && stateMachine.defaultState != null &&
                !states.Contains(stateMachine.defaultState))
                states.Add(stateMachine.defaultState);

            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
                CollectDefaultStatesForParameter(child.stateMachine, parameterName, states);
        }

        private void ScanStateMachineForParam(AnimatorStateMachine sm, string paramName, bool parentLayerMatched, List<AnimationClip> clips)
        {
            if (sm == null) return;

            bool anyStateMatched = sm.anyStateTransitions.Any(transition => TransitionUsesParameter(transition, paramName));
            bool entryMatched = sm.entryTransitions.Any(transition => TransitionUsesParameter(transition, paramName));
            bool stateMachineMatched = parentLayerMatched || anyStateMatched || entryMatched;
            var statesToCollect = new HashSet<AnimatorState>();

            foreach (var childState in sm.states)
            {
                if (childState.state == null) continue;
                if (stateMachineMatched || MotionUsesParameter(childState.state.motion, paramName, new HashSet<Motion>()))
                    statesToCollect.Add(childState.state);

                foreach (AnimatorStateTransition transition in childState.state.transitions)
                {
                    if (!TransitionUsesParameter(transition, paramName)) continue;
                    statesToCollect.Add(childState.state);
                    if (transition.destinationState != null)
                        statesToCollect.Add(transition.destinationState);
                }
            }

            if (anyStateMatched)
            {
                foreach (ChildAnimatorState childState in sm.states)
                    if (childState.state != null) statesToCollect.Add(childState.state);
                foreach (AnimatorStateTransition transition in sm.anyStateTransitions)
                    if (TransitionUsesParameter(transition, paramName) && transition.destinationState != null)
                        statesToCollect.Add(transition.destinationState);
            }

            if (entryMatched)
            {
                foreach (AnimatorTransition transition in sm.entryTransitions)
                    if (TransitionUsesParameter(transition, paramName) && transition.destinationState != null)
                        statesToCollect.Add(transition.destinationState);
            }

            foreach (AnimatorState state in statesToCollect)
            {
                if (state != null)
                    ExtractClipsFromMotion(state.motion, clips, new HashSet<Motion>());
            }

            foreach (var childMachine in sm.stateMachines)
            {
                ScanStateMachineForParam(childMachine.stateMachine, paramName, stateMachineMatched, clips);
            }
        }

        private bool MotionUsesParameter(Motion motion, string paramName, HashSet<Motion> visited)
        {
            if (motion == null || visited.Contains(motion)) return false;
            visited.Add(motion);

            if (motion is BlendTree blendTree)
            {
                if (string.Equals(blendTree.blendParameter, paramName, StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(blendTree.blendParameterY, paramName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                if (blendTree.blendType == BlendTreeType.Direct)
                {
                    foreach (var child in blendTree.children)
                    {
                        if (string.Equals(child.directBlendParameter, paramName, StringComparison.OrdinalIgnoreCase)) return true;
                    }
                }

                foreach (var child in blendTree.children)
                {
                    if (MotionUsesParameter(child.motion, paramName, visited)) return true;
                }
            }

            return false;
        }

        private void ExtractClipsFromMotion(Motion motion, List<AnimationClip> clips, HashSet<Motion> visited)
        {
            if (motion == null || visited.Contains(motion)) return;
            visited.Add(motion);

            if (motion is AnimationClip clip)
            {
                if (!clips.Contains(clip)) clips.Add(clip);
            }
            else if (motion is BlendTree blendTree)
            {
                foreach (var child in blendTree.children)
                {
                    ExtractClipsFromMotion(child.motion, clips, visited);
                }
            }
        }

        private void DetectParameterSharing()
        {
            Dictionary<string, int> paramCounts = new Dictionary<string, int>();
            foreach (var t in detectedToggles)
            {
                foreach (string parameterName in GetToggleParameterNames(t))
                {
                    if (!paramCounts.ContainsKey(parameterName)) paramCounts[parameterName] = 0;
                    paramCounts[parameterName]++;
                }
            }

            foreach (var t in detectedToggles)
            {
                t.sharedParameters.Clear();
                foreach (string parameterName in GetToggleParameterNames(t))
                {
                    if (paramCounts.TryGetValue(parameterName, out int count) && count > 1)
                        t.sharedParameters.Add(parameterName);
                }
            }
        }

        private AnimatorController GetFxController(VRCAvatarDescriptor descriptor)
        {
            if (descriptor == null) return null;
            var layers = descriptor.baseAnimationLayers;
            if (layers == null) return null;
            foreach (var layer in layers)
            {
                if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && !layer.isDefault && layer.animatorController != null)
                {
                    RuntimeAnimatorController runtimeController = layer.animatorController;
                    var visited = new HashSet<RuntimeAnimatorController>();
                    while (runtimeController is AnimatorOverrideController overrideController &&
                           visited.Add(runtimeController))
                    {
                        runtimeController = overrideController.runtimeAnimatorController;
                    }
                    return runtimeController as AnimatorController;
                }
            }
            return null;
        }

        private RuntimeAnimatorController GetFxRuntimeController(VRCAvatarDescriptor descriptor)
        {
            if (descriptor == null || descriptor.baseAnimationLayers == null) return null;
            foreach (VRCAvatarDescriptor.CustomAnimLayer layer in descriptor.baseAnimationLayers)
                if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && !layer.isDefault && layer.animatorController != null)
                    return layer.animatorController;
            return null;
        }

        private bool FxControllerUsesParameter(AnimatorController controller, string parameterName)
        {
            if (controller == null || string.IsNullOrEmpty(parameterName)) return false;
            foreach (AnimatorControllerLayer layer in controller.layers)
            {
                if (layer != null && StateMachineUsesParameter(layer.stateMachine, parameterName))
                    return true;
            }
            return false;
        }

        private bool AvatarAnimatorUsesParameter(VRCAvatarDescriptor descriptor, string parameterName)
        {
            if (descriptor == null || string.IsNullOrEmpty(parameterName)) return false;
            var playableLayers = descriptor.baseAnimationLayers;
            if (playableLayers == null) return false;
            foreach (var playableLayer in playableLayers)
            {
                RuntimeAnimatorController runtimeController = playableLayer.animatorController;
                var visited = new HashSet<RuntimeAnimatorController>();
                while (runtimeController is AnimatorOverrideController overrideController &&
                       visited.Add(runtimeController))
                {
                    runtimeController = overrideController.runtimeAnimatorController;
                }
                AnimatorController controller = runtimeController as AnimatorController;
                if (controller != null && FxControllerUsesParameter(controller, parameterName)) return true;
            }
            return false;
        }

        private void CollectGeneratedDriverParameters(AnimatorController controller, string toggleParameter,
            HashSet<string> parameters)
        {
            if (controller == null || string.IsNullOrEmpty(toggleParameter)) return;
            string targetLayerName = "NINSA Toggle - " + toggleParameter;
            foreach (AnimatorControllerLayer layer in controller.layers)
            {
                if (layer == null || !string.Equals(layer.name, targetLayerName, StringComparison.OrdinalIgnoreCase) ||
                    layer.stateMachine == null) continue;
                foreach (ChildAnimatorState child in layer.stateMachine.states)
                {
                    if (child.state == null) continue;
                    foreach (VRCAvatarParameterDriver driver in child.state.behaviours.OfType<VRCAvatarParameterDriver>())
                    {
                        if (driver.parameters == null) continue;
                        foreach (VRC_AvatarParameterDriver.Parameter parameter in driver.parameters)
                            if (!string.IsNullOrEmpty(parameter.name)) parameters.Add(parameter.name);
                    }
                }
            }
        }

        private bool StateMachineUsesParameter(AnimatorStateMachine stateMachine, string parameterName)
        {
            if (stateMachine == null) return false;
            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
                if (TransitionUsesParameter(transition, parameterName)) return true;
            foreach (AnimatorTransition transition in stateMachine.entryTransitions)
                if (TransitionUsesParameter(transition, parameterName)) return true;
            foreach (ChildAnimatorState child in stateMachine.states)
            {
                if (child.state == null) continue;
                foreach (AnimatorStateTransition transition in child.state.transitions)
                    if (TransitionUsesParameter(transition, parameterName)) return true;
                foreach (VRCAvatarParameterDriver driver in child.state.behaviours.OfType<VRCAvatarParameterDriver>())
                {
                    if (driver.parameters != null && driver.parameters.Any(parameter =>
                        string.Equals(parameter.name, parameterName, StringComparison.OrdinalIgnoreCase))) return true;
                }
                if (MotionUsesParameter(child.state.motion, parameterName, new HashSet<Motion>())) return true;
            }
            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
                if (StateMachineUsesParameter(child.stateMachine, parameterName)) return true;
            return false;
        }

        private bool TransitionUsesParameter(AnimatorTransitionBase transition, string parameterName)
        {
            if (transition == null) return false;
            return transition.conditions.Any(condition =>
                string.Equals(condition.parameter, parameterName, StringComparison.OrdinalIgnoreCase));
        }

        private void RefreshDeletionPreview()
        {
            List<ClothingToggleData> selectedToggles = detectedToggles
                .Where(toggle => toggle.isSelectedForRemoval)
                .ToList();
            previewLinkedObjects = GetLinkedObjects(selectedToggles);
            previewLinkedObjectCount = previewLinkedObjects.Count;
            previewDeleteEligibleObjects = GetObjectsToDelete(selectedToggles, forceDeleteLinkedObjects);
            UpdateDeletionObjectSelection();
        }

        private List<GameObject> GetLinkedObjects(List<ClothingToggleData> toggles)
        {
            HashSet<GameObject> linkedObjects = new HashSet<GameObject>();
            foreach (ClothingToggleData toggle in toggles)
            {
                if (toggle.clothingObject != null && toggle.clothingObject != (avatarDescriptor != null ? avatarDescriptor.gameObject : null))
                    linkedObjects.Add(toggle.clothingObject);
                if (toggle.animatedObjects == null) continue;
                foreach (GameObject target in toggle.animatedObjects)
                    if (target != null && target != (avatarDescriptor != null ? avatarDescriptor.gameObject : null))
                        linkedObjects.Add(target);
            }

            return linkedObjects
                .OrderBy(target => avatarDescriptor != null
                    ? GetRelativePath(avatarDescriptor.transform, target.transform)
                    : target.name, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        private void UpdateDeletionObjectSelection()
        {
            previewObjectsToDelete = BuildObjectsToDelete(
                previewLinkedObjects, previewDeleteEligibleObjects, previewObjectsToKeep);
            previewRetainedObjectCount = previewLinkedObjects.Count(target =>
                !previewObjectsToDelete.Any(root => target == root || target.transform.IsChildOf(root.transform)));
        }

        private static List<GameObject> BuildObjectsToDelete(
            List<GameObject> linkedObjects, HashSet<GameObject> eligibleObjects, HashSet<GameObject> objectsToKeep)
        {
            List<GameObject> selectedForDeletion = linkedObjects
                .Where(target => eligibleObjects.Contains(target) && !objectsToKeep.Contains(target))
                .ToList();

            HashSet<GameObject> keptObjects = new HashSet<GameObject>(linkedObjects
                .Where(target => !eligibleObjects.Contains(target) || objectsToKeep.Contains(target)));

            List<GameObject> deletableRoots = selectedForDeletion
                .Where(target => !keptObjects.Any(kept => kept != target && kept.transform.IsChildOf(target.transform)))
                .ToList();

            return deletableRoots
                .Where(target => !deletableRoots.Any(other => other != target && target.transform.IsChildOf(other.transform)))
                .ToList();
        }

        private HashSet<string> GetParametersToRemove(List<ClothingToggleData> togglesToDelete,
            AnimatorController fxController)
        {
            var selectedToggles = new HashSet<ClothingToggleData>(togglesToDelete);
            var paramsStillUsed = new HashSet<string>(
                detectedToggles.Where(toggle => !selectedToggles.Contains(toggle))
                    .SelectMany(GetToggleParameterNames), StringComparer.OrdinalIgnoreCase);
            var paramsToRemove = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (ClothingToggleData toggle in togglesToDelete)
            {
                foreach (string parameterName in GetToggleParameterNames(toggle))
                {
                    if (paramsStillUsed.Contains(parameterName)) continue;
                    paramsToRemove.Add(parameterName);
                    CollectGeneratedDriverParameters(fxController, parameterName, paramsToRemove);
                }
            }

            return paramsToRemove;
        }

        private HashSet<GameObject> GetObjectsToDelete(List<ClothingToggleData> togglesToDelete, bool forceDelete)
        {
            List<GameObject> candidates = GetLinkedObjects(togglesToDelete);
            HashSet<GameObject> eligibleObjects = new HashSet<GameObject>();
            if (candidates.Count == 0 || avatarDescriptor == null) return eligibleObjects;

            var remainingTargets = new HashSet<GameObject>();
            var selectedToggles = new HashSet<ClothingToggleData>(togglesToDelete);
            foreach (ClothingToggleData toggle in detectedToggles)
            {
                if (selectedToggles.Contains(toggle)) continue;
                if (toggle.clothingObject != null) remainingTargets.Add(toggle.clothingObject);
                if (toggle.animatedObjects == null) continue;
                foreach (GameObject target in toggle.animatedObjects)
                    if (target != null) remainingTargets.Add(target);
            }

            HashSet<GameObject> deletionBlacklist = GetDeletionBlacklistObjects();
            foreach (GameObject candidate in candidates)
            {
                if (candidate == null || candidate == avatarDescriptor.gameObject ||
                    !candidate.transform.IsChildOf(avatarDescriptor.transform) ||
                    IsBlockedByDeletionBlacklist(candidate, deletionBlacklist)) continue;

                bool usedByRemainingToggle = remainingTargets.Any(target =>
                    target != null && (target == candidate ||
                        target.transform.IsChildOf(candidate.transform) ||
                        candidate.transform.IsChildOf(target.transform)));
                if (usedByRemainingToggle && !forceDelete) continue;

                eligibleObjects.Add(candidate);
            }

            return eligibleObjects;
        }

        private bool ShouldRemoveGeneratedFxLayer(string layerName, HashSet<string> paramsToRemove)
        {
            return !string.IsNullOrEmpty(layerName) &&
                layerName.StartsWith("NINSA Toggle - ", StringComparison.Ordinal) &&
                paramsToRemove.Any(parameter => layerName.EndsWith(parameter, StringComparison.OrdinalIgnoreCase));
        }

        private void ExecuteMultiDeletion()
        {
            if (avatarDescriptor == null) return;

            var togglesToDelete = detectedToggles.Where(t => t.isSelectedForRemoval).ToList();
            if (togglesToDelete.Count == 0) return;

            List<GameObject> linkedObjects = GetLinkedObjects(togglesToDelete);
            HashSet<GameObject> eligibleObjects = GetObjectsToDelete(togglesToDelete, forceDeleteLinkedObjects);
            List<GameObject> objectsToDelete = BuildObjectsToDelete(linkedObjects, eligibleObjects, previewObjectsToKeep);
            int retainedObjectCount = linkedObjects.Count(target =>
                !objectsToDelete.Any(root => target == root || target.transform.IsChildOf(root.transform)));
            bool deletionPreviewChanged = linkedObjects.Count != previewLinkedObjectCount ||
                retainedObjectCount != previewRetainedObjectCount ||
                !new HashSet<GameObject>(linkedObjects).SetEquals(previewLinkedObjects) ||
                !eligibleObjects.SetEquals(previewDeleteEligibleObjects) ||
                !new HashSet<GameObject>(objectsToDelete).SetEquals(previewObjectsToDelete);
            if (deletionPreviewChanged)
            {
                RefreshDeletionPreview();
                EditorUtility.DisplayDialog("Review Updated",
                    "The avatar changed after the preview was opened. Review the updated object list, then confirm again.",
                    "OK");
                return;
            }

            if (forceDeleteLinkedObjects && objectsToDelete.Count > 0 &&
                !EditorUtility.DisplayDialog(
                    "Confirm Force Delete",
                    "Force-delete " + objectsToDelete.Count + " linked avatar object(s)? Other remaining toggles may still use these objects and can stop working.",
                    "Force Delete", "Cancel"))
                return;
            
            if (settingCreateBackupBeforeChanges && !CreateBackupNow()) return;

            Undo.SetCurrentGroupName($"Delete {togglesToDelete.Count} Toggles");
            int currentGroup = Undo.GetCurrentGroup();

            AnimatorController fxControllerForRemoval = GetFxController(avatarDescriptor);
            HashSet<string> paramsToRemove = GetParametersToRemove(togglesToDelete, fxControllerForRemoval);

            foreach (var toggle in togglesToDelete)
            {
                if (toggle.sourceMenu != null && toggle.sourceControl != null)
                {
                    Undo.RecordObject(toggle.sourceMenu, "Remove Menu Control");
                    toggle.sourceMenu.controls.Remove(toggle.sourceControl);
                    EditorUtility.SetDirty(toggle.sourceMenu);
                }

            }

            var parametersStillUsedByAnimator = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (paramsToRemove.Count > 0)
            {
                AnimatorController fx = fxControllerForRemoval;
                if (fx != null)
                {
                    if (settingAllowFxModifications || objectsToDelete.Count > 0)
                    {
                        Undo.RecordObject(fx, "Clean FX Controller");
                        for (int i = fx.layers.Length - 1; i >= 0; i--)
                        {
                            string layerName = fx.layers[i].name ?? "";
                            if (ShouldRemoveGeneratedFxLayer(layerName, paramsToRemove))
                            {
                                fx.RemoveLayer(i);
                            }
                        }

                        fx.parameters = fx.parameters.Where(parameter =>
                            !paramsToRemove.Contains(parameter.name) ||
                            !parameter.name.StartsWith("NINSA_", StringComparison.Ordinal) ||
                            FxControllerUsesParameter(fx, parameter.name)).ToArray();
                        EditorUtility.SetDirty(fx);
                    }
                }
                foreach (string parameter in paramsToRemove)
                    if (AvatarAnimatorUsesParameter(avatarDescriptor, parameter)) parametersStillUsedByAnimator.Add(parameter);
            }

            string[] expressionParametersToRemove = paramsToRemove
                .Where(parameter => !parametersStillUsedByAnimator.Contains(parameter)).ToArray();
            if (expressionParametersToRemove.Length > 0 && avatarDescriptor.expressionParameters != null)
            {
                Undo.RecordObject(avatarDescriptor.expressionParameters, "Remove Expression Parameters");
                var parameters = avatarDescriptor.expressionParameters.parameters;
                if (parameters != null)
                {
                    avatarDescriptor.expressionParameters.parameters = parameters
                        .Where(parameter => parameter == null || !expressionParametersToRemove.Contains(parameter.name, StringComparer.OrdinalIgnoreCase))
                        .ToArray();
                    EditorUtility.SetDirty(avatarDescriptor.expressionParameters);
                }
            }

            foreach (GameObject target in objectsToDelete)
                if (target != null) Undo.DestroyObjectImmediate(target);

            Undo.CollapseUndoOperations(currentGroup);

            showMultiDeletePreview = false;
            forceDeleteLinkedObjects = false;
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            ScanAvatarData();

            EditorUtility.DisplayDialog("Removed",
                $"Removed {togglesToDelete.Count} menu control(s) and {objectsToDelete.Count} linked avatar object(s). Parameters still used elsewhere were kept.",
                "OK");
        }

        private void ScanFxControllerData()
        {
            if (fxController == null)
            {
                scannedFxParameters.Clear();
                scannedFxLayers.Clear();
                scannedFxConditions.Clear();
                isFxScanned = false;
                return;
            }

            scannedFxParameters.Clear();
            scannedFxLayers.Clear();
            scannedFxConditions.Clear();
            foreach (AnimatorControllerParameter param in fxController.parameters)
            {
                scannedFxParameters.Add(param.name + "  ·  " + param.type);
            }
            foreach (AnimatorControllerLayer layer in fxController.layers)
            {
                if (layer == null) continue;
                scannedFxLayers.Add(layer.name);
                CollectFxConditions(layer.stateMachine, scannedFxConditions);
            }
            scannedFxParameters.Sort(StringComparer.OrdinalIgnoreCase);
            scannedFxLayers.Sort(StringComparer.OrdinalIgnoreCase);
            scannedFxConditions.Sort(StringComparer.OrdinalIgnoreCase);
            isFxScanned = true;
        }

        private void CollectFxConditions(AnimatorStateMachine stateMachine, List<string> conditions)
        {
            if (stateMachine == null) return;
            foreach (AnimatorStateTransition transition in stateMachine.anyStateTransitions)
                AddFxConditions(transition, conditions);
            foreach (AnimatorTransition transition in stateMachine.entryTransitions)
                AddFxConditions(transition, conditions);
            foreach (ChildAnimatorState child in stateMachine.states)
            {
                if (child.state == null) continue;
                foreach (AnimatorStateTransition transition in child.state.transitions)
                    AddFxConditions(transition, conditions);
            }
            foreach (ChildAnimatorStateMachine child in stateMachine.stateMachines)
                CollectFxConditions(child.stateMachine, conditions);
        }

        private void AddFxConditions(AnimatorTransitionBase transition, List<string> conditions)
        {
            if (transition == null) return;
            foreach (AnimatorCondition condition in transition.conditions)
            {
                string description = condition.parameter + "  ·  " + condition.mode + " " + condition.threshold;
                if (!conditions.Contains(description)) conditions.Add(description);
            }
        }

        private bool CreateBackupNow()
        {
            RestoreSelectedToggleObjectActiveStates();
            bool backupCreated;
            string folder;
            string error;
            try
            {
                backupCreated = AvatarToggleBackup.CreateBackup(avatarDescriptor, avatarName, out folder, out error);
            }
            finally
            {
                RefreshSelectedToggleObjectActiveStates();
            }

            if (!backupCreated)
            {
                EditorUtility.DisplayDialog("Backup Failed", error, "OK");
                return false;
            }
            RefreshBackupList();
            EditorUtility.DisplayDialog("Backup Created", "Avatar assets were copied to:\n" + folder, "OK");
            return true;
        }
        
        private string SanitizeFileName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "UnknownAsset";
            string safeName = name;
            foreach (char c in System.IO.Path.GetInvalidFileNameChars())
            {
                safeName = safeName.Replace(c, '_');
            }
            return safeName;
        }

        private void RestoreBackup(string folderPath)
        {
            if (avatarDescriptor == null)
            {
                EditorUtility.DisplayDialog("Error", "Please assign an Avatar Descriptor in the tool header to restore these assets.", "OK");
                return;
            }
            
            if (!EditorUtility.DisplayDialog("Restore Backup", "Restoring this backup will replace current Expression Menus, Parameters, and FX controllers on this avatar descriptor. Proceed?", "Yes", "Cancel")) return;

            if (!AvatarToggleBackup.RestoreBackup(folderPath, avatarDescriptor, out string error))
            {
                EditorUtility.DisplayDialog("Restore Failed", error, "OK");
                return;
            }
            ScanAvatarData();
            EditorUtility.DisplayDialog("Restore Complete", "Avatar backup assets have been successfully restored and linked.", "OK");
        }

        private void RefreshBackupList()
        {
            availableBackups.Clear();
            string rootFolder = "Assets/AvatarToggleManager_Backups";
            
            if (AssetDatabase.IsValidFolder(rootFolder))
            {
                string[] subFolders = AssetDatabase.GetSubFolders(rootFolder);
                foreach (var dir in subFolders)
                {
                    string folderName = Path.GetFileName(dir);
                    if (avatarDescriptor == null || folderName.StartsWith(SanitizeFileName(avatarName), StringComparison.OrdinalIgnoreCase))
                    {
                        availableBackups.Add(folderName);
                    }
                }
            }
        }

        private void CreateToggleAction(VRCExpressionsMenu targetMenu)
        {
            var settings = new ToggleCreator.ToggleSettings
            {
                toggleName = newToggleName,
                clothingObject = targetClothingObject,
                enableOnOff = enableOnOff,
                enableBlendShape = enableBlendShape,
                targetSkinnedMesh = targetSkinnedMesh,
                blendShapeName = blendShapeName,
                blendShapeOnValue = blendShapeOnValue,
                blendShapeOffValue = blendShapeOffValue,
                enableMaterialProperty = enableMaterialProperty,
                targetRenderer = targetRenderer,
                materialIndex = materialIndex,
                materialPropertyName = materialPropertyName,
                propertyType = materialPropertyType,
                floatOnValue = matFloatOn,
                floatOffValue = matFloatOff,
                colorOnValue = matColorOn,
                colorOffValue = matColorOff,
                enableIntState = enableIntState,
                intParameterName = intParameterName,
                intStateValue = intStateValue
            };

            if (!ToggleCreator.ValidateSettings(settings, avatarDescriptor, targetMenu, out string validationError))
            {
                EditorUtility.DisplayDialog("Check Toggle Setup", validationError, "OK");
                return;
            }

            if (settingCreateBackupBeforeChanges && !CreateBackupNow()) return;

            if (!ToggleCreator.CreateToggle(settings, avatarDescriptor, targetMenu, out string generatedFolder, out string error))
            {
                EditorUtility.DisplayDialog("Could Not Create Toggle", error, "OK");
                return;
            }

            ScanAvatarData();
            RefreshBackupList();
            createMenuPath = "Root";
            EditorUtility.DisplayDialog("Toggle Created", "The toggle and its assets were created here:\n" + generatedFolder, "OK");
        }
        #endregion
    }
}
