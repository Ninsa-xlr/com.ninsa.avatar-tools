using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDKBase;

namespace Ninsa.AvatarToggleManager.Editor
{
    /// <summary>
    /// Creates the Unity assets and VRChat references needed for a clothing toggle.
    /// </summary>
    public static class ToggleCreator
    {
        public class ToggleSettings
        {
            public string toggleName;
            public GameObject clothingObject;
            public bool enableOnOff = true;
            public bool enableBlendShape;
            public SkinnedMeshRenderer targetSkinnedMesh;
            public string blendShapeName;
            public float blendShapeOnValue = 100f;
            public float blendShapeOffValue;
            public bool enableMaterialProperty;
            public Renderer targetRenderer;
            public int materialIndex;
            public string materialPropertyName;
            public AvatarToggleManagerWindow.MaterialPropertyType propertyType;
            public float floatOnValue = 1f;
            public float floatOffValue;
            public Color colorOnValue = Color.white;
            public Color colorOffValue = Color.black;
            public bool enableIntState;
            public string intParameterName;
            public int intStateValue = 1;
        }

        public static bool CreateToggle(
            ToggleSettings settings,
            VRCAvatarDescriptor avatar,
            VRCExpressionsMenu targetMenu,
            out string generatedFolder,
            out string error)
        {
            generatedFolder = null;
            error = null;

            if (!Validate(settings, avatar, targetMenu, out error)) return false;

            try
            {
                string baseFolder = "Assets/NINSA_AvatarToggleManager/Generated";
                EnsureAssetFolder(baseFolder);
                string folderName = SanitizeFileName(avatar.gameObject.name) + "_" +
                                    DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" +
                                    Guid.NewGuid().ToString("N").Substring(0, 6);
                generatedFolder = baseFolder + "/" + folderName;
                if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(baseFolder, folderName)))
                    throw new InvalidOperationException("Could not create the toggle asset folder.");
                EnsureAssetFolder(generatedFolder + "/Animations");
                EnsureAssetFolder(generatedFolder + "/Controllers");
                EnsureAssetFolder(generatedFolder + "/Menus");

                VRCExpressionsMenu sourceRoot = avatar.expressionsMenu;
                if (sourceRoot == null)
                {
                    sourceRoot = ScriptableObject.CreateInstance<VRCExpressionsMenu>();
                    sourceRoot.name = "NINSA Expressions Menu";
                    sourceRoot.controls = new List<VRCExpressionsMenu.Control>();
                }

                Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> menuCopies =
                    CloneMenuGraph(sourceRoot, generatedFolder + "/Menus", "Menu");
                VRCExpressionsMenu rootMenu = menuCopies[sourceRoot];
                if (avatar.expressionsMenu == null) UnityEngine.Object.DestroyImmediate(sourceRoot);
                VRCExpressionsMenu menuToEdit = targetMenu != null && menuCopies.ContainsKey(targetMenu)
                    ? menuCopies[targetMenu]
                    : rootMenu;

                if (menuToEdit.controls == null)
                    menuToEdit.controls = new List<VRCExpressionsMenu.Control>();
                if (menuToEdit.controls.Count >= 8)
                    throw new InvalidOperationException("That expression menu already has 8 controls. Choose a menu with an empty slot.");

                VRCExpressionParameters sourceParameters = avatar.expressionParameters;
                VRCExpressionParameters parameters = sourceParameters != null
                    ? UnityEngine.Object.Instantiate(sourceParameters)
                    : ScriptableObject.CreateInstance<VRCExpressionParameters>();
                parameters.name = "NINSA Expression Parameters";
                if (parameters.parameters == null)
                    parameters.parameters = new VRCExpressionParameters.Parameter[0];
                AssetDatabase.CreateAsset(parameters, generatedFolder + "/NINSA_ExpressionParameters.asset");

                AnimatorController controller = CreateControllerCopy(avatar, generatedFolder + "/Controllers");
                string boolParameterName = MakeUniqueBoolParameterName(settings.toggleName, parameters, controller);
                string intParameterName = settings.enableIntState
                    ? (string.IsNullOrWhiteSpace(settings.intParameterName)
                        ? MakeUniqueIntParameterName(settings.toggleName, parameters, controller)
                        : settings.intParameterName.Trim())
                    : null;

                AddExpressionParameter(parameters, boolParameterName, VRCExpressionParameters.ValueType.Bool);
                AddAnimatorParameter(controller, boolParameterName, AnimatorControllerParameterType.Bool);

                if (settings.enableIntState)
                {
                    if (string.Equals(boolParameterName, intParameterName, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("The integer state parameter must have a different name from the toggle parameter.");
                    AddExpressionParameter(parameters, intParameterName, VRCExpressionParameters.ValueType.Int);
                    AddAnimatorParameter(controller, intParameterName, AnimatorControllerParameterType.Int);
                }

                if (parameters.parameters.Length > 8192)
                    throw new InvalidOperationException("This avatar would exceed VRChat's 8192 expression parameter limit.");
                int parameterCost = parameters.CalcTotalCost();
                if (parameterCost > VRCExpressionParameters.MAX_PARAMETER_COST)
                    throw new InvalidOperationException("This avatar would exceed VRChat's synced expression parameter limit (current total: " +
                        parameterCost + " of " + VRCExpressionParameters.MAX_PARAMETER_COST + " bits).");

                AnimationClip onClip = CreateAnimationClip(settings, avatar.gameObject, generatedFolder + "/Animations", true);
                AnimationClip offClip = CreateAnimationClip(settings, avatar.gameObject, generatedFolder + "/Animations", false);
                string layerName = "NINSA Toggle - " + boolParameterName;
                AddAnimatorLayer(controller, layerName, boolParameterName, onClip, offClip,
                    settings.enableIntState ? intParameterName : null,
                    settings.enableIntState ? settings.intStateValue : 0);

                var menuControl = new VRCExpressionsMenu.Control
                {
                    name = settings.toggleName.Trim(),
                    type = VRCExpressionsMenu.Control.ControlType.Toggle,
                    parameter = new VRCExpressionsMenu.Control.Parameter { name = boolParameterName },
                    value = 1f
                };
                menuToEdit.controls.Add(menuControl);

                AssetDatabase.SaveAssets();

                Undo.RecordObject(avatar, "Create Avatar Toggle");
                avatar.expressionsMenu = rootMenu;
                avatar.expressionParameters = parameters;
                AssignFxController(avatar, controller);
                EditorUtility.SetDirty(avatar);
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                return true;
            }
            catch (Exception exception)
            {
                error = exception.Message;
                AssetDatabase.DeleteAsset(generatedFolder);
                generatedFolder = null;
                AssetDatabase.SaveAssets();
                return false;
            }
        }

        public static bool ValidateSettings(ToggleSettings settings, VRCAvatarDescriptor avatar,
            VRCExpressionsMenu targetMenu, out string error)
        {
            return Validate(settings, avatar, targetMenu, out error);
        }

        private static bool Validate(ToggleSettings settings, VRCAvatarDescriptor avatar,
            VRCExpressionsMenu targetMenu, out string error)
        {
            error = null;
            if (settings == null) { error = "Toggle settings are missing."; return false; }
            if (avatar == null) { error = "Assign an avatar descriptor first."; return false; }
            if (avatar.baseAnimationLayers == null ||
                !avatar.baseAnimationLayers.Any(layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX))
            {
                error = "The avatar descriptor does not have an FX playable layer.";
                return false;
            }
            if (string.IsNullOrWhiteSpace(settings.toggleName)) { error = "Enter a name for the toggle."; return false; }
            if (!settings.enableOnOff && !settings.enableBlendShape && !settings.enableMaterialProperty)
            {
                error = "Choose at least one action for this toggle.";
                return false;
            }
            if (settings.enableOnOff && settings.clothingObject == null)
            {
                error = "Choose the GameObject that should turn on and off.";
                return false;
            }
            if (settings.enableOnOff && !IsInsideAvatar(settings.clothingObject.transform, avatar.transform))
            {
                error = "The GameObject must be on the avatar hierarchy.";
                return false;
            }
            if (settings.enableBlendShape)
            {
                if (settings.targetSkinnedMesh == null || settings.targetSkinnedMesh.sharedMesh == null)
                {
                    error = "Choose a Skinned Mesh with a mesh assigned.";
                    return false;
                }
                if (!IsInsideAvatar(settings.targetSkinnedMesh.transform, avatar.transform))
                {
                    error = "The Skinned Mesh must be on the avatar hierarchy.";
                    return false;
                }
                if (string.IsNullOrWhiteSpace(settings.blendShapeName) ||
                    settings.targetSkinnedMesh.sharedMesh.GetBlendShapeIndex(settings.blendShapeName.Trim()) < 0)
                {
                    error = "The selected mesh does not contain that blend shape.";
                    return false;
                }
            }
            if (settings.enableMaterialProperty)
            {
                if (settings.targetRenderer == null || !IsInsideAvatar(settings.targetRenderer.transform, avatar.transform))
                {
                    error = "Choose a Renderer on the avatar hierarchy.";
                    return false;
                }
                Material[] materials = settings.targetRenderer.sharedMaterials;
                if (settings.materialIndex < 0 || settings.materialIndex >= materials.Length || materials[settings.materialIndex] == null)
                {
                    error = "The selected material index does not contain a material.";
                    return false;
                }
                string property = NormalizeMaterialProperty(settings.materialPropertyName);
                if (string.IsNullOrWhiteSpace(property) || !materials[settings.materialIndex].HasProperty(property))
                {
                    error = "That material does not have the selected shader property.";
                    return false;
                }
            }
            if (settings.enableIntState && (settings.intStateValue < 0 || settings.intStateValue > 255))
            {
                error = "The integer state value must be between 0 and 255.";
                return false;
            }
            if (avatar.expressionsMenu != null && targetMenu != null && !ContainsMenu(avatar.expressionsMenu, targetMenu))
            {
                error = "The selected menu is no longer linked to this avatar. Scan the avatar and try again.";
                return false;
            }
            VRCExpressionsMenu destination = targetMenu != null ? targetMenu : avatar.expressionsMenu;
            if (destination != null && destination.controls != null && destination.controls.Count >= 8)
            {
                error = "That expression menu already has 8 controls. Choose a menu with an empty slot.";
                return false;
            }
            if (settings.enableIntState && string.IsNullOrWhiteSpace(settings.intParameterName))
                settings.intParameterName = MakeUniqueIntParameterName(settings.toggleName, avatar.expressionParameters, GetFxController(avatar));
            return true;
        }

        private static AnimationClip CreateAnimationClip(ToggleSettings settings, GameObject avatarRoot, string folder, bool isOn)
        {
            string suffix = isOn ? "_On.anim" : "_Off.anim";
            string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + SanitizeFileName(settings.toggleName) + suffix);
            var clip = new AnimationClip
            {
                name = SanitizeFileName(settings.toggleName) + (isOn ? " On" : " Off"),
                frameRate = 60f
            };

            if (settings.enableOnOff)
            {
                string objectPath = AnimationUtility.CalculateTransformPath(settings.clothingObject.transform, avatarRoot.transform);
                var binding = EditorCurveBinding.DiscreteCurve(objectPath, typeof(GameObject), "m_IsActive");
                AnimationUtility.SetEditorCurve(clip, binding, ConstantCurve(isOn ? 1f : 0f));
            }
            if (settings.enableBlendShape)
            {
                string meshPath = AnimationUtility.CalculateTransformPath(settings.targetSkinnedMesh.transform, avatarRoot.transform);
                string property = "blendShape." + settings.blendShapeName.Trim();
                var binding = EditorCurveBinding.FloatCurve(meshPath, typeof(SkinnedMeshRenderer), property);
                AnimationUtility.SetEditorCurve(clip, binding,
                    ConstantCurve(isOn ? settings.blendShapeOnValue : settings.blendShapeOffValue));
            }
            if (settings.enableMaterialProperty)
            {
                string rendererPath = AnimationUtility.CalculateTransformPath(settings.targetRenderer.transform, avatarRoot.transform);
                Material material = settings.targetRenderer.sharedMaterials[settings.materialIndex];
                AddMaterialCurves(clip, rendererPath, material, settings, isOn);
            }

            AssetDatabase.CreateAsset(clip, path);
            return clip;
        }

        private static void AddMaterialCurves(AnimationClip clip, string path, Material material, ToggleSettings settings, bool isOn)
        {
            string property = NormalizeMaterialProperty(settings.materialPropertyName);
            string propertyPrefix = (settings.materialIndex > 0 ? "[" + settings.materialIndex + "]." : "") + "material.";
            switch (settings.propertyType)
            {
                case AvatarToggleManagerWindow.MaterialPropertyType.Color:
                    AddColorCurves(clip, path, propertyPrefix + property, isOn ? settings.colorOnValue : settings.colorOffValue);
                    break;
                case AvatarToggleManagerWindow.MaterialPropertyType.Alpha:
                    AddFloatCurve(clip, path, propertyPrefix + property + ".a",
                        isOn ? settings.floatOnValue : settings.floatOffValue);
                    break;
                case AvatarToggleManagerWindow.MaterialPropertyType.Emission:
                    Color emission = material.GetColor(property);
                    float multiplier = isOn ? settings.floatOnValue : settings.floatOffValue;
                    AddColorCurves(clip, path, propertyPrefix + property, new Color(emission.r * multiplier,
                        emission.g * multiplier, emission.b * multiplier, emission.a));
                    break;
                default:
                    AddFloatCurve(clip, path, propertyPrefix + property,
                        isOn ? settings.floatOnValue : settings.floatOffValue);
                    break;
            }
        }

        private static void AddColorCurves(AnimationClip clip, string path, string property, Color color)
        {
            AddFloatCurve(clip, path, property + ".r", color.r);
            AddFloatCurve(clip, path, property + ".g", color.g);
            AddFloatCurve(clip, path, property + ".b", color.b);
            AddFloatCurve(clip, path, property + ".a", color.a);
        }

        private static void AddFloatCurve(AnimationClip clip, string path, string property, float value)
        {
            var binding = EditorCurveBinding.FloatCurve(path, typeof(Renderer), property);
            AnimationUtility.SetEditorCurve(clip, binding, ConstantCurve(value));
        }

        private static AnimationCurve ConstantCurve(float value)
        {
            return new AnimationCurve(new Keyframe(0f, value), new Keyframe(1f, value));
        }

        private static void AddAnimatorLayer(AnimatorController controller, string layerName, string boolParameter,
            AnimationClip onClip, AnimationClip offClip, string intParameter, int intValue)
        {
            controller.AddLayer(layerName);
            AnimatorControllerLayer[] layers = controller.layers;
            int index = layers.Length - 1;
            AnimatorStateMachine stateMachine = layers[index].stateMachine;
            layers[index].defaultWeight = 1f;
            layers[index].blendingMode = AnimatorLayerBlendingMode.Override;
            layers[index].name = layerName;
            controller.layers = layers;

            AnimatorState offState = stateMachine.AddState("Off");
            AnimatorState onState = stateMachine.AddState("On");
            offState.motion = offClip;
            onState.motion = onClip;
            offState.writeDefaultValues = true;
            onState.writeDefaultValues = true;
            stateMachine.defaultState = offState;

            AnimatorStateTransition turnOn = offState.AddTransition(onState);
            turnOn.hasExitTime = false;
            turnOn.duration = 0f;
            turnOn.AddCondition(AnimatorConditionMode.If, 0f, boolParameter);
            AnimatorStateTransition turnOff = onState.AddTransition(offState);
            turnOff.hasExitTime = false;
            turnOff.duration = 0f;
            turnOff.AddCondition(AnimatorConditionMode.IfNot, 0f, boolParameter);

            if (!string.IsNullOrEmpty(intParameter))
            {
                AddIntParameterDriver(offState, intParameter, 0);
                AddIntParameterDriver(onState, intParameter, intValue);
            }
            EditorUtility.SetDirty(controller);
        }

        private static void AddIntParameterDriver(AnimatorState state, string parameterName, int value)
        {
            VRCAvatarParameterDriver driver = state.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
            driver.localOnly = false;
            driver.parameters.Add(new VRC_AvatarParameterDriver.Parameter
            {
                name = parameterName,
                type = VRC_AvatarParameterDriver.ChangeType.Set,
                value = value
            });
        }

        private static void AddExpressionParameter(VRCExpressionParameters parameters, string name,
            VRCExpressionParameters.ValueType valueType)
        {
            VRCExpressionParameters.Parameter existing = parameters.parameters.FirstOrDefault(p =>
                p != null && string.Equals(p.name, name, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                if (existing.valueType != valueType)
                    throw new InvalidOperationException("Expression parameter '" + name + "' already exists with a different type.");
                return;
            }

            var created = new VRCExpressionParameters.Parameter
            {
                name = name,
                valueType = valueType,
                defaultValue = 0f,
                saved = false,
                networkSynced = true
            };
            parameters.parameters = parameters.parameters.Concat(new[] { created }).ToArray();
            EditorUtility.SetDirty(parameters);
        }

        private static void AddAnimatorParameter(AnimatorController controller, string name, AnimatorControllerParameterType type)
        {
            AnimatorControllerParameter existing = controller.parameters.FirstOrDefault(p =>
                string.Equals(p.name, name, StringComparison.OrdinalIgnoreCase));
            if (existing != null)
            {
                if (existing.type != type)
                    throw new InvalidOperationException("FX parameter '" + name + "' already exists with a different type.");
                return;
            }
            controller.AddParameter(name, type);
        }

        private static AnimatorController CreateControllerCopy(VRCAvatarDescriptor avatar, string folder)
        {
            AnimatorController source = GetFxController(avatar);
            if (source == null)
            {
                const string defaultFxPath = "Packages/com.vrchat.avatars/Samples/AV3 Demo Assets/Animation/Controllers/vrc_AvatarV3FaceLayer.controller";
                source = AssetDatabase.LoadAssetAtPath<AnimatorController>(defaultFxPath);
                if (source == null)
                    throw new InvalidOperationException("No custom FX controller is assigned and the VRChat default FX template could not be found. Import the AV3 Demo Assets or assign a custom FX controller first.");
            }

            string path = folder + "/NINSA_FX.controller";
            string sourcePath = AssetDatabase.GetAssetPath(source);
            if (string.IsNullOrEmpty(sourcePath))
                throw new InvalidOperationException("The avatar's FX controller must be saved as an asset before a toggle can be added.");
            path = AssetDatabase.GenerateUniqueAssetPath(path);
            if (!AssetDatabase.CopyAsset(sourcePath, path))
                throw new InvalidOperationException("Could not make a safe copy of the avatar's FX controller.");
            AnimatorController copy = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            if (copy == null) throw new InvalidOperationException("The copied FX controller could not be loaded.");
            return copy;
        }

        private static void AssignFxController(VRCAvatarDescriptor avatar, AnimatorController controller)
        {
            var layers = avatar.baseAnimationLayers;
            int fxIndex = Array.FindIndex(layers, layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX);
            if (fxIndex < 0) throw new InvalidOperationException("The avatar descriptor has no FX playable layer.");
            var fxLayer = layers[fxIndex];
            fxLayer.animatorController = controller;
            fxLayer.isDefault = false;
            layers[fxIndex] = fxLayer;
            avatar.baseAnimationLayers = layers;
        }

        private static Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> CloneMenuGraph(
            VRCExpressionsMenu root, string folder, string filePrefix)
        {
            var sources = new List<VRCExpressionsMenu>();
            CollectMenus(root, sources, new HashSet<VRCExpressionsMenu>());
            var copies = new Dictionary<VRCExpressionsMenu, VRCExpressionsMenu>();
            int index = 0;
            foreach (VRCExpressionsMenu source in sources)
            {
                VRCExpressionsMenu copy = UnityEngine.Object.Instantiate(source);
                copy.name = source.name;
                string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + filePrefix + "_" + index++ + "_" + SanitizeFileName(source.name) + ".asset");
                AssetDatabase.CreateAsset(copy, path);
                copies.Add(source, copy);
            }
            foreach (KeyValuePair<VRCExpressionsMenu, VRCExpressionsMenu> pair in copies)
            {
                if (pair.Value.controls == null) continue;
                foreach (VRCExpressionsMenu.Control control in pair.Value.controls)
                {
                    if (control != null && control.subMenu != null && copies.TryGetValue(control.subMenu, out VRCExpressionsMenu subMenuCopy))
                        control.subMenu = subMenuCopy;
                }
                EditorUtility.SetDirty(pair.Value);
            }
            return copies;
        }

        internal static Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> CloneMenuGraphForBackup(
            VRCExpressionsMenu root, string folder)
        {
            return CloneMenuGraph(root, folder, "Menu");
        }

        private static void CollectMenus(VRCExpressionsMenu menu, List<VRCExpressionsMenu> menus, HashSet<VRCExpressionsMenu> visited)
        {
            if (menu == null || !visited.Add(menu)) return;
            menus.Add(menu);
            if (menu.controls == null) return;
            foreach (VRCExpressionsMenu.Control control in menu.controls)
                if (control != null && control.subMenu != null) CollectMenus(control.subMenu, menus, visited);
        }

        private static bool ContainsMenu(VRCExpressionsMenu root, VRCExpressionsMenu target)
        {
            if (root == null || target == null) return false;
            var menus = new List<VRCExpressionsMenu>();
            CollectMenus(root, menus, new HashSet<VRCExpressionsMenu>());
            return menus.Contains(target);
        }

        private static bool IsInsideAvatar(Transform target, Transform avatarRoot)
        {
            return target != null && avatarRoot != null && (target == avatarRoot || target.IsChildOf(avatarRoot));
        }

        private static string MakeUniqueBoolParameterName(string name, VRCExpressionParameters parameters, AnimatorController controller)
        {
            string baseName = "NINSA_" + SanitizeParameterName(name);
            string candidate = baseName;
            int suffix = 2;
            while (HasExpressionParameter(parameters, candidate) || HasAnimatorParameter(controller, candidate))
                candidate = baseName + "_" + suffix++;
            return candidate;
        }

        private static string MakeUniqueIntParameterName(string name, VRCExpressionParameters parameters, AnimatorController controller)
        {
            string baseName = "NINSA_" + SanitizeParameterName(name) + "_State";
            string candidate = baseName;
            int suffix = 2;
            while (HasExpressionParameter(parameters, candidate) || HasAnimatorParameter(controller, candidate))
                candidate = baseName + "_" + suffix++;
            return candidate;
        }

        private static bool HasExpressionParameter(VRCExpressionParameters parameters, string name)
        {
            return parameters != null && parameters.parameters != null && parameters.parameters.Any(p =>
                p != null && string.Equals(p.name, name, StringComparison.OrdinalIgnoreCase));
        }

        private static bool HasAnimatorParameter(AnimatorController controller, string name)
        {
            return controller != null && controller.parameters.Any(p =>
                string.Equals(p.name, name, StringComparison.OrdinalIgnoreCase));
        }

        private static AnimatorController GetFxController(VRCAvatarDescriptor avatar)
        {
            if (avatar == null) return null;
            foreach (var layer in avatar.baseAnimationLayers)
            {
                if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && !layer.isDefault && layer.animatorController != null)
                    return layer.animatorController as AnimatorController;
            }
            return null;
        }

        private static string NormalizeMaterialProperty(string property)
        {
            if (string.IsNullOrWhiteSpace(property)) return string.Empty;
            property = property.Trim();
            return property.StartsWith("_") ? property : "_" + property;
        }

        private static string SanitizeParameterName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Toggle";
            var chars = value.Trim().Select(c => char.IsLetterOrDigit(c) || c == '_' ? c : '_').ToArray();
            string result = new string(chars).Trim('_');
            return string.IsNullOrEmpty(result) ? "Toggle" : result;
        }

        private static string SanitizeFileName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Toggle";
            foreach (char invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
            return value.Trim();
        }

        private static void EnsureAssetFolder(string path)
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }
    }

    /// <summary>
    /// JSON index for one avatar backup. Paths point only to the cloned assets inside that backup folder.
    /// </summary>
    [Serializable]
    public class AvatarToggleBackupManifest
    {
        public int formatVersion = 2;
        public string avatarName;
        public string expressionsMenuPath;
        public string expressionParametersPath;
        public string fxControllerPath;
        public string avatarPrefabPath;
        public bool fxWasDefault;
    }

    /// <summary>
    /// Copies avatar menu, parameter, and FX assets to timestamped folders and restores their references.
    /// </summary>
    public static class AvatarToggleBackup
    {
        public static bool CreateBackup(VRCAvatarDescriptor avatar, string avatarName, out string folder, out string error)
        {
            folder = null;
            error = null;
            if (avatar == null) { error = "Assign an avatar descriptor before creating a backup."; return false; }

            string rootFolder = "Assets/AvatarToggleManager_Backups";
            string name = SanitizeFileName(avatarName) + "_" + DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss") + "_" +
                          Guid.NewGuid().ToString("N").Substring(0, 4);
            folder = rootFolder + "/" + name;
            GameObject prefabSource = null;

            try
            {
                EnsureAssetFolder(rootFolder);
                if (string.IsNullOrEmpty(AssetDatabase.CreateFolder(rootFolder, name)))
                    throw new InvalidOperationException("Could not create the backup folder.");
                EnsureAssetFolder(folder + "/Menus");

                VRCExpressionsMenu rootMenuCopy = null;
                VRCExpressionParameters parametersCopy = null;
                RuntimeAnimatorController fxCopy = null;

                if (avatar.expressionsMenu != null)
                {
                    Dictionary<VRCExpressionsMenu, VRCExpressionsMenu> menus = ToggleCreator.CloneMenuGraphForBackup(
                        avatar.expressionsMenu, folder + "/Menus");
                    rootMenuCopy = menus[avatar.expressionsMenu];
                    string rootPath = AssetDatabase.GetAssetPath(rootMenuCopy);
                    string namedRootPath = folder + "/" + SanitizeFileName(avatarName) + "_RootMenu.asset";
                    string moveError = AssetDatabase.MoveAsset(rootPath, namedRootPath);
                    if (!string.IsNullOrEmpty(moveError))
                        throw new InvalidOperationException("Could not mark the root menu in the backup: " + moveError);
                }

                if (avatar.expressionParameters != null)
                {
                    VRCExpressionParameters copy = UnityEngine.Object.Instantiate(avatar.expressionParameters);
                    copy.name = avatar.expressionParameters.name + " Backup";
                    string parametersPath = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + SanitizeFileName(copy.name) + ".asset");
                    AssetDatabase.CreateAsset(copy, parametersPath);
                    parametersCopy = AssetDatabase.LoadAssetAtPath<VRCExpressionParameters>(parametersPath);
                    if (parametersCopy == null)
                        throw new InvalidOperationException("The expression parameters copy could not be saved.");
                }

                RuntimeAnimatorController fx = GetFxRuntimeController(avatar);
                if (fx != null)
                {
                    string sourcePath = AssetDatabase.GetAssetPath(fx);
                    if (string.IsNullOrEmpty(sourcePath))
                        throw new InvalidOperationException("The avatar's FX controller must be saved as an asset before it can be backed up.");
                    string extension = Path.GetExtension(sourcePath);
                    string destination = AssetDatabase.GenerateUniqueAssetPath(
                        folder + "/" + SanitizeFileName(fx.name) + "_FX" + extension);
                    if (!AssetDatabase.CopyAsset(sourcePath, destination))
                        throw new InvalidOperationException("Could not copy the avatar's FX controller into the backup.");
                    fxCopy = AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(destination);
                    if (fxCopy == null)
                        throw new InvalidOperationException("The FX controller copy could not be loaded from the backup.");
                }

                string avatarPrefabPath = AssetDatabase.GenerateUniqueAssetPath(
                    folder + "/" + SanitizeFileName(avatarName) + "_Avatar.prefab");
                var avatarLayers = avatar.baseAnimationLayers;
                int avatarFxIndex = avatarLayers == null ? -1 : Array.FindIndex(avatarLayers,
                    layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX);
                bool fxWasDefault = avatarFxIndex < 0 || avatarLayers[avatarFxIndex].isDefault;

                prefabSource = UnityEngine.Object.Instantiate(avatar.gameObject);
                prefabSource.name = avatar.gameObject.name;
                VRCAvatarDescriptor prefabAvatar = prefabSource.GetComponent<VRCAvatarDescriptor>();
                if (prefabAvatar == null)
                    throw new InvalidOperationException("The avatar prefab copy has no VRChat Avatar Descriptor.");

                prefabAvatar.expressionsMenu = rootMenuCopy;
                prefabAvatar.expressionParameters = parametersCopy;
                var prefabLayers = prefabAvatar.baseAnimationLayers;
                int prefabFxIndex = prefabLayers == null ? -1 : Array.FindIndex(prefabLayers,
                    layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX);
                if (prefabFxIndex >= 0)
                {
                    var fxLayer = prefabLayers[prefabFxIndex];
                    fxLayer.animatorController = fxCopy;
                    fxLayer.isDefault = fxWasDefault;
                    prefabLayers[prefabFxIndex] = fxLayer;
                    prefabAvatar.baseAnimationLayers = prefabLayers;
                }
                EditorUtility.SetDirty(prefabAvatar);
                PrefabUtility.RecordPrefabInstancePropertyModifications(prefabAvatar);

                bool prefabSaved;
                GameObject avatarPrefab = PrefabUtility.SaveAsPrefabAsset(prefabSource, avatarPrefabPath, out prefabSaved);
                if (!prefabSaved || avatarPrefab == null || AssetDatabase.LoadAssetAtPath<GameObject>(avatarPrefabPath) == null)
                    throw new InvalidOperationException("The avatar prefab copy could not be saved into the backup.");
                UnityEngine.Object.DestroyImmediate(prefabSource);
                prefabSource = null;

                var manifest = new AvatarToggleBackupManifest();
                manifest.avatarName = avatarName;
                manifest.expressionsMenuPath = rootMenuCopy != null ? AssetDatabase.GetAssetPath(rootMenuCopy) : "";
                manifest.expressionParametersPath = parametersCopy != null ? AssetDatabase.GetAssetPath(parametersCopy) : "";
                manifest.fxControllerPath = fxCopy != null ? AssetDatabase.GetAssetPath(fxCopy) : "";
                manifest.avatarPrefabPath = AssetDatabase.GetAssetPath(avatarPrefab);
                manifest.fxWasDefault = fxWasDefault;
                string manifestAssetPath = folder + "/Backup.json";
                File.WriteAllText(GetManifestFilePath(folder), JsonUtility.ToJson(manifest, true));
                AssetDatabase.ImportAsset(manifestAssetPath, ImportAssetOptions.ForceUpdate);

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();
                if (!File.Exists(GetManifestFilePath(folder)))
                    throw new InvalidOperationException("The backup index could not be saved.");
                return true;
            }
            catch (Exception exception)
            {
                error = exception.Message;
                if (prefabSource != null) UnityEngine.Object.DestroyImmediate(prefabSource);
                if (!string.IsNullOrEmpty(folder)) AssetDatabase.DeleteAsset(folder);
                folder = null;
                return false;
            }
        }

        public static bool RestoreBackup(string folder, VRCAvatarDescriptor avatar, out string error)
        {
            error = null;
            if (avatar == null) { error = "Assign an avatar descriptor before restoring a backup."; return false; }
            if (string.IsNullOrWhiteSpace(folder) || !AssetDatabase.IsValidFolder(folder))
            {
                error = "That backup folder could not be found.";
                return false;
            }

            string[] guids = AssetDatabase.FindAssets("", new[] { folder });
            string manifestFilePath = GetManifestFilePath(folder);
            AvatarToggleBackupManifest manifest = null;
            if (File.Exists(manifestFilePath))
            {
                try
                {
                    manifest = JsonUtility.FromJson<AvatarToggleBackupManifest>(File.ReadAllText(manifestFilePath));
                }
                catch (Exception exception)
                {
                    error = "The backup index could not be read: " + exception.Message;
                    return false;
                }
                if (manifest == null || (manifest.formatVersion != 1 && manifest.formatVersion != 2))
                {
                    error = "The backup index is empty or uses an unsupported format.";
                    return false;
                }
            }

            if (manifest != null)
            {
                VRCExpressionsMenu manifestMenu = string.IsNullOrEmpty(manifest.expressionsMenuPath)
                    ? null : AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(manifest.expressionsMenuPath);
                VRCExpressionParameters manifestParameters = string.IsNullOrEmpty(manifest.expressionParametersPath)
                    ? null : AssetDatabase.LoadAssetAtPath<VRCExpressionParameters>(manifest.expressionParametersPath);
                RuntimeAnimatorController manifestFx = string.IsNullOrEmpty(manifest.fxControllerPath)
                    ? null : AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(manifest.fxControllerPath);
                if ((!string.IsNullOrEmpty(manifest.expressionsMenuPath) && manifestMenu == null) ||
                    (!string.IsNullOrEmpty(manifest.expressionParametersPath) && manifestParameters == null) ||
                    (!string.IsNullOrEmpty(manifest.fxControllerPath) && manifestFx == null))
                {
                    error = "One or more assets referenced by this backup are missing or could not be loaded.";
                    return false;
                }

                Undo.RecordObject(avatar, "Restore Avatar Toggle Backup");
                avatar.expressionsMenu = manifestMenu;
                avatar.expressionParameters = manifestParameters;

                var manifestLayers = avatar.baseAnimationLayers;
                int manifestFxIndex = manifestLayers == null ? -1 : Array.FindIndex(manifestLayers,
                    layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX);
                if (manifestFxIndex >= 0)
                {
                    var fxLayer = manifestLayers[manifestFxIndex];
                    fxLayer.animatorController = manifestFx;
                    fxLayer.isDefault = manifest.fxWasDefault;
                    manifestLayers[manifestFxIndex] = fxLayer;
                    avatar.baseAnimationLayers = manifestLayers;
                }
                EditorUtility.SetDirty(avatar);
                PrefabUtility.RecordPrefabInstancePropertyModifications(avatar);
                AssetDatabase.SaveAssets();
                return true;
            }

            VRCExpressionsMenu rootMenu = null;
            VRCExpressionParameters parameters = null;
            AnimatorController fx = null;
            foreach (string guid in guids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                Type type = AssetDatabase.GetMainAssetTypeAtPath(path);
                if (type == typeof(VRCExpressionsMenu) && (path.EndsWith("_RootMenu.asset", StringComparison.OrdinalIgnoreCase) || rootMenu == null))
                    rootMenu = AssetDatabase.LoadAssetAtPath<VRCExpressionsMenu>(path);
                else if (type == typeof(VRCExpressionParameters))
                    parameters = AssetDatabase.LoadAssetAtPath<VRCExpressionParameters>(path);
                else if (type == typeof(AnimatorController))
                    fx = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            }

            if (rootMenu == null && parameters == null && fx == null)
            {
                error = "This backup does not contain any avatar assets.";
                return false;
            }

            Undo.RecordObject(avatar, "Restore Avatar Toggle Backup");
            if (rootMenu != null) avatar.expressionsMenu = rootMenu;
            if (parameters != null) avatar.expressionParameters = parameters;
            if (fx != null)
            {
                var layers = avatar.baseAnimationLayers;
                int fxIndex = layers == null ? -1 : Array.FindIndex(layers,
                    layer => layer.type == VRCAvatarDescriptor.AnimLayerType.FX);
                if (fxIndex >= 0)
                {
                    var layer = layers[fxIndex];
                    layer.animatorController = fx;
                    layer.isDefault = false;
                    layers[fxIndex] = layer;
                    avatar.baseAnimationLayers = layers;
                }
            }
            EditorUtility.SetDirty(avatar);
            PrefabUtility.RecordPrefabInstancePropertyModifications(avatar);
            AssetDatabase.SaveAssets();
            return true;
        }

        public static GameObject LoadAvatarPrefab(string folder)
        {
            if (string.IsNullOrWhiteSpace(folder) || !AssetDatabase.IsValidFolder(folder)) return null;
            string manifestPath = GetManifestFilePath(folder);
            if (!File.Exists(manifestPath)) return null;

            try
            {
                AvatarToggleBackupManifest manifest = JsonUtility.FromJson<AvatarToggleBackupManifest>(File.ReadAllText(manifestPath));
                if (manifest == null || manifest.formatVersion < 2 || string.IsNullOrEmpty(manifest.avatarPrefabPath)) return null;
                return AssetDatabase.LoadAssetAtPath<GameObject>(manifest.avatarPrefabPath);
            }
            catch
            {
                return null;
            }
        }

        private static RuntimeAnimatorController GetFxRuntimeController(VRCAvatarDescriptor avatar)
        {
            if (avatar == null) return null;
            var layers = avatar.baseAnimationLayers;
            if (layers == null) return null;
            foreach (var layer in layers)
                if (layer.type == VRCAvatarDescriptor.AnimLayerType.FX && !layer.isDefault)
                    return layer.animatorController;
            return null;
        }

        private static void EnsureAssetFolder(string path)
        {
            string[] parts = path.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next)) AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }

        private static string GetManifestFilePath(string folder)
        {
            const string assetsPrefix = "Assets/";
            if (string.IsNullOrEmpty(folder) || !folder.StartsWith(assetsPrefix, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("The backup folder must be inside the Unity project's Assets folder.");
            string relativeFolder = folder.Substring(assetsPrefix.Length).Replace('/', Path.DirectorySeparatorChar);
            return Path.Combine(Application.dataPath, relativeFolder, "Backup.json");
        }

        private static string SanitizeFileName(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "Avatar";
            foreach (char invalid in Path.GetInvalidFileNameChars()) value = value.Replace(invalid, '_');
            return value.Trim();
        }
    }
}
