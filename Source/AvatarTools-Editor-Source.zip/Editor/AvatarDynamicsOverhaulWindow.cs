using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Dynamics.Contact.Components;
using VRC.SDK3.Dynamics.PhysBone.Components;

namespace Ninsa.AvatarDynamicsOverhaul
{
    /// <summary>
    /// NINSA editor suite for browsing, editing, converting, generating, and auditing
    /// VRChat PhysBones, PhysBone colliders, and Contact components.
    /// </summary>
    public sealed class AvatarDynamicsOverhaulWindow : EditorWindow
    {
        private enum Page
        {
            Overview,
            PhysBones,
            Colliders,
            Contacts,
            Batch,
            Legacy,
            Generate,
            Presets,
            Audit,
            Settings
        }

        private enum ColliderEditTool
        {
            Off,
            PropertyEdit
        }

        private enum ColliderEditProperty
        {
            Radius,
            Height,
            Position,
            Rotation
        }

        private enum BatchScope { AvatarRoot, Selection, EntireScene }
        private enum BatchComponentFilter { PhysBones, Colliders, ContactSenders, ContactReceivers, Contacts }
        private enum ContactPreset { Headpat, NoseBoop, Handshake, EyeContact }
        private enum ContactPresetPart { Sender, Receiver, Both }
        private enum PerformancePlatform { PC, Mobile }

        private Page currentPage;
        private GameObject avatarRoot;
        private string searchText = "";
        private Vector2 componentListScroll;
        private Vector2 inspectorScroll;
        private Vector2 duplicateScroll;
        private bool highlightSelectedObject = true;
        private Color highlightColor = new Color(0.1f, 0.9f, 1f, 1f);
        private bool showColliderSceneGizmos = true;
        private bool enableColliderSceneEditing = true;
        private Color colliderGizmoColor = new Color(1f, 0.38f, 0.08f, 1f);
        private bool showPhysBoneSceneGizmos = true;
        private Color physBoneGizmoColor = new Color(0.25f, 1f, 0.32f, 1f);
        private ColliderEditTool colliderEditTool = ColliderEditTool.PropertyEdit;
        private ColliderEditProperty colliderEditProperty = ColliderEditProperty.Radius;

        private BatchScope batchScope = BatchScope.AvatarRoot;
        private BatchComponentFilter batchComponentFilter = BatchComponentFilter.PhysBones;
        private string batchSearchText = string.Empty;
        private bool useBatchMultipliers;
        private bool batchApplyPull = true;
        private bool batchApplySpring = true;
        private bool batchApplyDamping;
        private bool batchApplyFriction;
        private bool batchApplyImmobile;
        private bool batchApplyGravity;
        private bool batchApplyRadius;
        private bool batchApplyHeight;
        private float batchPull = 0.2f;
        private float batchSpring = 0.2f;
        private float batchDamping;
        private float batchFriction;
        private float batchImmobile;
        private float batchGravity;
        private float batchRadius = 0.02f;
        private float batchHeight = 0.1f;
        private Component templateComponent;
        private bool copyPull = true;
        private bool copySpring = true;
        private bool copyDamping;
        private bool copyFriction;
        private bool copyImmobile;
        private bool copyGravity;
        private bool copyRadius;
        private bool copyHeight;
        private bool copyPosition;
        private bool copyRotation;

        private bool removeLegacyAfterConversion;
        private bool includeLegacyInactive = true;
        private Vector2 legacyScroll;
        private string legacySearch = string.Empty;
        private readonly List<Component> legacyCandidates = new List<Component>();
        private readonly List<VRCPhysBoneCollider> generatedColliders = new List<VRCPhysBoneCollider>();

        private Animator generatorAnimator;
        private VRCPhysBone generatorTargetPhysBone;
        private GameObject generatorNewPhysBoneObject;
        private bool generateHead = true;
        private bool generateChest = true;
        private bool generateHands = true;
        private bool generateArms;
        private bool generateLegs;
        private bool generateFeet;
        private bool generatorUseCapsules = true;
        private bool generatorAutoAssign = true;
        private bool generatorCreatePhysBone;
        private float generatorRadiusScale = 0.12f;

        private ContactPreset contactPreset;
        private ContactPresetPart contactPresetPart = ContactPresetPart.Both;
        private bool contactAllowSelf = true;
        private bool contactAllowOthers = true;
        private bool includeBuiltInContactTags = true;
        private bool registerExpressionParameter = true;
        private float contactRadiusScale = 0.12f;
        private string contactParameterPrefix = "NINSA";
        private PerformancePlatform performancePlatform = PerformancePlatform.PC;

        private readonly List<VRCPhysBone> physBones = new List<VRCPhysBone>();
        private readonly List<VRCPhysBoneCollider> physBoneColliders = new List<VRCPhysBoneCollider>();
        private readonly List<VRCContactSender> contactSenders = new List<VRCContactSender>();
        private readonly List<VRCContactReceiver> contactReceivers = new List<VRCContactReceiver>();

        private Component selectedComponent;
        private global::UnityEditor.Editor selectedComponentEditor;
        private VRCPhysBoneCollider sceneEditCollider;
        private VRCPhysBone sceneEditPhysBone;
        private static bool showColliderContactInspectorTools = true;
        private static bool expandColliderContactInspectorTools = true;

        private const string ColliderInspectorToggleMenu = "CONTEXT/VRCPhysBoneCollider/NINSA/Toggle Editor";
        private const string SenderInspectorToggleMenu = "CONTEXT/VRCContactSender/NINSA/Toggle Editor";
        private const string ReceiverInspectorToggleMenu = "CONTEXT/VRCContactReceiver/NINSA/Toggle Editor";

        [MenuItem("NINSA/Avatar Dynamics Overhaul")]
        [MenuItem("Window/NINSA/Avatar Dynamics Overhaul")]
        public static void OpenWindow()
        {
            AvatarDynamicsOverhaulWindow window = GetWindow<AvatarDynamicsOverhaulWindow>("Avatar Dynamics");
            window.minSize = new Vector2(900f, 580f);
            window.Show();
        }

        public static void OpenForAvatar(GameObject root)
        {
            AvatarDynamicsOverhaulWindow window = GetWindow<AvatarDynamicsOverhaulWindow>("Avatar Dynamics");
            window.minSize = new Vector2(900f, 580f);
            if (root != null)
            {
                window.SetAvatarRoot(root);
                window.ScanAvatar();
                window.currentPage = Page.PhysBones;
            }
            else if (window.avatarRoot == null)
            {
                window.TryUseCurrentSelection();
                window.ScanAvatar();
            }
            window.Show();
        }

        [InitializeOnLoadMethod]
        private static void RegisterComponentInspectorTools()
        {
            global::UnityEditor.Editor.finishedDefaultHeaderGUI -= DrawComponentInspectorTools;
            global::UnityEditor.Editor.finishedDefaultHeaderGUI += DrawComponentInspectorTools;
        }

        [MenuItem(ColliderInspectorToggleMenu, false, 899)]
        [MenuItem(SenderInspectorToggleMenu, false, 899)]
        [MenuItem(ReceiverInspectorToggleMenu, false, 899)]
        private static void ToggleColliderContactInspectorTools()
        {
            showColliderContactInspectorTools = !showColliderContactInspectorTools;
            EditorApplication.delayCall += global::UnityEditorInternal.InternalEditorUtility.RepaintAllViews;
        }

        private static void DrawComponentInspectorTools(global::UnityEditor.Editor inspector)
        {
            if (!showColliderContactInspectorTools || inspector == null) return;
            Component component = inspector.target as Component;
            if (component == null || !(component is VRCPhysBoneCollider || component is VRCContactSender || component is VRCContactReceiver)) return;

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            expandColliderContactInspectorTools = EditorGUILayout.Foldout(
                expandColliderContactInspectorTools, "NINSA Dynamics Tools", true);
            GUILayout.FlexibleSpace();
            GUILayout.Label("Collider / Contact", EditorStyles.miniLabel);
            EditorGUILayout.EndHorizontal();

            if (expandColliderContactInspectorTools)
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Copy Settings", EditorStyles.miniButtonLeft))
                    global::UnityEditorInternal.ComponentUtility.CopyComponent(component);
                if (GUILayout.Button("Paste Values", EditorStyles.miniButtonRight))
                {
                    Undo.RecordObject(component, "Paste Dynamics Component Values");
                    if (global::UnityEditorInternal.ComponentUtility.PasteComponentValues(component))
                    {
                        PrefabUtility.RecordPrefabInstancePropertyModifications(component);
                        EditorUtility.SetDirty(component);
                    }
                }
                EditorGUILayout.EndHorizontal();

                EditorGUILayout.BeginHorizontal();
                if (component is VRCPhysBoneCollider collider)
                {
                    if (GUILayout.Button("Move To Child")) MoveColliderToChild(collider, true);
                    if (GUILayout.Button("To Sender")) ConvertComponent(collider, typeof(VRCContactSender), true);
                    if (GUILayout.Button("To Receiver")) ConvertComponent(collider, typeof(VRCContactReceiver), true);
                }
                else if (component is VRCContactSender sender)
                {
                    if (GUILayout.Button("To Receiver")) ConvertComponent(sender, typeof(VRCContactReceiver), true);
                    if (GUILayout.Button("To Collider")) ConvertComponent(sender, typeof(VRCPhysBoneCollider), true);
                }
                else if (component is VRCContactReceiver receiver)
                {
                    if (GUILayout.Button("To Sender")) ConvertComponent(receiver, typeof(VRCContactSender), true);
                    if (GUILayout.Button("To Collider")) ConvertComponent(receiver, typeof(VRCPhysBoneCollider), true);
                }

                if (GUILayout.Button("Select", GUILayout.Width(64f)))
                {
                    Selection.activeGameObject = component.gameObject;
                    EditorGUIUtility.PingObject(component.gameObject);
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();
        }

        private void OnEnable()
        {
            titleContent = new GUIContent("Avatar Dynamics");
            SceneView.duringSceneGui += OnSceneGUI;
            LoadSceneEditorSettings();
            if (avatarRoot == null) TryUseCurrentSelection();
            UpdateSceneEditColliderFromSelection();
            ScanAvatar();
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
            SaveSceneEditorSettings();
            ReleaseSelectedEditor();
        }

        private void OnSelectionChange()
        {
            UpdateSceneEditColliderFromSelection();
            Repaint();
            SceneView.RepaintAll();
        }

        private void OnGUI()
        {
            DrawTitleBar();
            DrawAvatarBar();
            DrawNavigation();

            bool pageNeedsAvatarRoot = currentPage == Page.Overview || currentPage == Page.PhysBones ||
                                       currentPage == Page.Colliders || currentPage == Page.Contacts;
            if (avatarRoot == null && pageNeedsAvatarRoot)
            {
                EditorGUILayout.HelpBox("Choose an avatar root or select an object inside an avatar, then click Use Selection.", MessageType.Info);
                DrawCreateForSelection();
                return;
            }

            switch (currentPage)
            {
                case Page.Overview:
                    DrawOverview();
                    break;
                case Page.PhysBones:
                case Page.Colliders:
                case Page.Contacts:
                    DrawComponentBrowser();
                    break;
                case Page.Batch:
                    DrawBatchTools();
                    break;
                case Page.Legacy:
                    DrawLegacyConversion();
                    break;
                case Page.Generate:
                    DrawColliderGenerator();
                    break;
                case Page.Presets:
                    DrawContactPresets();
                    break;
                case Page.Audit:
                    DrawPerformanceAudit();
                    break;
                case Page.Settings:
                    DrawSettings();
                    break;
            }
        }

        private void DrawTitleBar()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("AVATAR DYNAMICS", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            GUILayout.Label("NINSA", EditorStyles.miniBoldLabel);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.LabelField("Inspector editing, Scene handles, batch tools, generators, and audit", EditorStyles.miniLabel);
            EditorGUILayout.EndVertical();
        }

        private void DrawAvatarBar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            EditorGUILayout.LabelField("Avatar", GUILayout.Width(48f));
            GameObject nextRoot = (GameObject)EditorGUILayout.ObjectField(avatarRoot, typeof(GameObject), true);
            if (nextRoot != avatarRoot)
            {
                SetAvatarRoot(nextRoot);
                ScanAvatar();
            }

            if (GUILayout.Button("Use Selection", EditorStyles.toolbarButton, GUILayout.Width(96f)))
            {
                TryUseCurrentSelection();
                ScanAvatar();
            }

            if (GUILayout.Button("Refresh", EditorStyles.toolbarButton, GUILayout.Width(64f)))
                ScanAvatar();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawNavigation()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            DrawNavigationButton(Page.Overview, "Overview");
            DrawNavigationButton(Page.PhysBones, "PhysBones");
            DrawNavigationButton(Page.Colliders, "Colliders");
            DrawNavigationButton(Page.Contacts, "Contacts");
            DrawNavigationButton(Page.Batch, "Batch Edit");
            DrawNavigationButton(Page.Legacy, "Legacy");
            DrawNavigationButton(Page.Generate, "Generate");
            DrawNavigationButton(Page.Presets, "Presets");
            DrawNavigationButton(Page.Audit, "Audit");
            DrawNavigationButton(Page.Settings, "Settings");
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawNavigationButton(Page page, string label)
        {
            if (GUILayout.Toggle(currentPage == page, label, EditorStyles.toolbarButton))
            {
                if (currentPage != page)
                {
                    currentPage = page;
                    searchText = "";
                    if (page == Page.PhysBones || page == Page.Colliders || page == Page.Contacts)
                        EnsureSelectionForPage();
                }
            }
        }

        private void DrawBatchTools()
        {
            EditorGUILayout.LabelField("BATCH EDIT & PROPERTY COPY", EditorStyles.largeLabel);
            EditorGUILayout.HelpBox("Choose an avatar, the current Hierarchy selection, or the whole open scene. Values are applied through SerializedObject and can be undone.", MessageType.Info);
            EditorGUILayout.BeginHorizontal();
            batchScope = (BatchScope)EditorGUILayout.EnumPopup("Target Scope", batchScope);
            batchComponentFilter = (BatchComponentFilter)EditorGUILayout.EnumPopup("Components", batchComponentFilter);
            EditorGUILayout.EndHorizontal();
            batchSearchText = EditorGUILayout.TextField("Search Name / Path", batchSearchText);

            List<Component> targets = GetBatchTargets();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Matching components", targets.Count.ToString(), EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Select Matches", GUILayout.Width(120f)))
                Selection.objects = targets.Where(component => component != null).Select(component => (UnityEngine.Object)component.gameObject).Distinct().ToArray();
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            useBatchMultipliers = EditorGUILayout.ToggleLeft("Multiply current values instead of setting them", useBatchMultipliers);
            DrawBatchFloat("Pull", ref batchApplyPull, ref batchPull, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Spring", ref batchApplySpring, ref batchSpring, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Damping", ref batchApplyDamping, ref batchDamping, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Friction", ref batchApplyFriction, ref batchFriction, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Immobile", ref batchApplyImmobile, ref batchImmobile, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Gravity", ref batchApplyGravity, ref batchGravity, batchComponentFilter == BatchComponentFilter.PhysBones);
            DrawBatchFloat("Radius", ref batchApplyRadius, ref batchRadius, true);
            DrawBatchFloat("Height", ref batchApplyHeight, ref batchHeight,
                batchComponentFilter != BatchComponentFilter.PhysBones);
            EditorGUILayout.HelpBox(useBatchMultipliers ? "Multipliers below are factors (for example, 1.25 = increase by 25%)." : "Unchecked properties are left unchanged. Unsupported or missing properties are skipped.", MessageType.None);
            EditorGUI.BeginDisabledGroup(targets.Count == 0 || !HasBatchOperation());
            if (GUILayout.Button("Apply to Matching Components", GUILayout.Height(30f))) ApplyBatchEdits(targets);
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("Selective Copy from Template", EditorStyles.boldLabel);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            templateComponent = (Component)EditorGUILayout.ObjectField("Template Component", templateComponent, typeof(Component), true);
            EditorGUILayout.BeginHorizontal();
            copyPull = EditorGUILayout.ToggleLeft("Pull", copyPull, GUILayout.Width(65f));
            copySpring = EditorGUILayout.ToggleLeft("Spring", copySpring, GUILayout.Width(75f));
            copyDamping = EditorGUILayout.ToggleLeft("Damping", copyDamping, GUILayout.Width(86f));
            copyFriction = EditorGUILayout.ToggleLeft("Friction", copyFriction, GUILayout.Width(82f));
            copyImmobile = EditorGUILayout.ToggleLeft("Immobile", copyImmobile, GUILayout.Width(94f));
            copyGravity = EditorGUILayout.ToggleLeft("Gravity", copyGravity, GUILayout.Width(80f));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            copyRadius = EditorGUILayout.ToggleLeft("Radius", copyRadius, GUILayout.Width(78f));
            copyHeight = EditorGUILayout.ToggleLeft("Height", copyHeight, GUILayout.Width(78f));
            copyPosition = EditorGUILayout.ToggleLeft("Position", copyPosition, GUILayout.Width(95f));
            copyRotation = EditorGUILayout.ToggleLeft("Rotation", copyRotation, GUILayout.Width(95f));
            GUILayout.FlexibleSpace();
            EditorGUI.BeginDisabledGroup(templateComponent == null || targets.Count == 0 || !HasCopySelection());
            if (GUILayout.Button("Copy Checked Values to Matches", GUILayout.Width(220f))) CopyTemplateProperties(targets);
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.EndVertical();
        }

        private void DrawBatchFloat(string label, ref bool enabled, ref float value, bool relevant)
        {
            if (!relevant) return;
            EditorGUILayout.BeginHorizontal();
            enabled = EditorGUILayout.ToggleLeft(label, enabled, GUILayout.Width(112f));
            using (new EditorGUI.DisabledScope(!enabled))
                value = EditorGUILayout.FloatField(useBatchMultipliers ? "Factor" : "Value", value);
            EditorGUILayout.EndHorizontal();
        }

        private bool HasBatchOperation()
        {
            return (batchComponentFilter == BatchComponentFilter.PhysBones &&
                    (batchApplyPull || batchApplySpring || batchApplyDamping || batchApplyFriction || batchApplyImmobile || batchApplyGravity || batchApplyRadius)) ||
                   (batchComponentFilter != BatchComponentFilter.PhysBones && (batchApplyRadius || batchApplyHeight));
        }

        private bool HasCopySelection()
        {
            return copyPull || copySpring || copyDamping || copyFriction || copyImmobile || copyGravity || copyRadius || copyHeight || copyPosition || copyRotation;
        }

        private List<Component> GetBatchTargets()
        {
            IEnumerable<Component> found;
            if (batchScope == BatchScope.AvatarRoot)
            {
                if (avatarRoot == null) return new List<Component>();
                found = GetComponentsForFilter(avatarRoot);
            }
            else if (batchScope == BatchScope.Selection)
            {
                GameObject[] selected = Selection.gameObjects ?? Array.Empty<GameObject>();
                found = selected.Where(gameObject => gameObject != null)
                    .SelectMany(gameObject => GetComponentsForFilter(gameObject));
            }
            else
            {
                found = GetAllComponentsForFilter().Where(component => component != null &&
                    !EditorUtility.IsPersistent(component) && component.gameObject.scene.IsValid());
            }

            return found.Where(component => component != null && !EditorUtility.IsPersistent(component) &&
                    component.gameObject.scene.IsValid() && MatchesBatchSearch(component))
                .Distinct().OrderBy(component => GetPath(component.transform), StringComparer.OrdinalIgnoreCase).ToList();
        }

        private IEnumerable<Component> GetComponentsForFilter(GameObject root)
        {
            if (root == null) return Enumerable.Empty<Component>();
            switch (batchComponentFilter)
            {
                case BatchComponentFilter.PhysBones:
                    return root.GetComponentsInChildren<VRCPhysBone>(true).Cast<Component>();
                case BatchComponentFilter.Colliders:
                    return root.GetComponentsInChildren<VRCPhysBoneCollider>(true).Cast<Component>();
                case BatchComponentFilter.ContactSenders:
                    return root.GetComponentsInChildren<VRCContactSender>(true).Cast<Component>();
                case BatchComponentFilter.ContactReceivers:
                    return root.GetComponentsInChildren<VRCContactReceiver>(true).Cast<Component>();
                default:
                    return root.GetComponentsInChildren<VRCContactSender>(true).Cast<Component>()
                        .Concat(root.GetComponentsInChildren<VRCContactReceiver>(true).Cast<Component>());
            }
        }

        private IEnumerable<Component> GetAllComponentsForFilter()
        {
            switch (batchComponentFilter)
            {
                case BatchComponentFilter.PhysBones:
                    return Resources.FindObjectsOfTypeAll<VRCPhysBone>().Cast<Component>();
                case BatchComponentFilter.Colliders:
                    return Resources.FindObjectsOfTypeAll<VRCPhysBoneCollider>().Cast<Component>();
                case BatchComponentFilter.ContactSenders:
                    return Resources.FindObjectsOfTypeAll<VRCContactSender>().Cast<Component>();
                case BatchComponentFilter.ContactReceivers:
                    return Resources.FindObjectsOfTypeAll<VRCContactReceiver>().Cast<Component>();
                default:
                    return Resources.FindObjectsOfTypeAll<VRCContactSender>().Cast<Component>()
                        .Concat(Resources.FindObjectsOfTypeAll<VRCContactReceiver>().Cast<Component>());
            }
        }

        private bool MatchesBatchSearch(Component component)
        {
            return string.IsNullOrWhiteSpace(batchSearchText) ||
                   component.gameObject.name.IndexOf(batchSearchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                   GetPath(component.transform).IndexOf(batchSearchText, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void ApplyBatchEdits(List<Component> targets)
        {
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Batch Edit Avatar Dynamics");
            int changedCount = 0;
            foreach (Component target in targets)
            {
                if (target == null) continue;
                SerializedObject serialized = new SerializedObject(target);
                serialized.Update();
                bool changed = false;
                Undo.RecordObject(target, "Batch Edit Avatar Dynamics");

                if (batchComponentFilter == BatchComponentFilter.PhysBones)
                {
                    changed |= ApplyBatchFloat(serialized, "pull", batchApplyPull, batchPull);
                    changed |= ApplyBatchFloat(serialized, "spring", batchApplySpring, batchSpring);
                    changed |= ApplyBatchFloat(serialized, "damping", batchApplyDamping, batchDamping);
                    changed |= ApplyBatchFloat(serialized, "friction", batchApplyFriction, batchFriction);
                    changed |= ApplyBatchFloat(serialized, "immobile", batchApplyImmobile, batchImmobile);
                    changed |= ApplyBatchFloat(serialized, "gravity", batchApplyGravity, batchGravity);
                    changed |= ApplyBatchFloat(serialized, "radius", batchApplyRadius, batchRadius);
                }
                else
                {
                    changed |= ApplyBatchFloat(serialized, "radius", batchApplyRadius, batchRadius);
                    changed |= ApplyBatchFloat(serialized, "height", batchApplyHeight, batchHeight);
                }

                if (changed)
                {
                    serialized.ApplyModifiedProperties();
                    PrefabUtility.RecordPrefabInstancePropertyModifications(target);
                    EditorUtility.SetDirty(target);
                    changedCount++;
                }
            }
            Undo.CollapseUndoOperations(undoGroup);
            EditorUtility.DisplayDialog("Batch Edit Complete", "Updated " + changedCount + " component(s). Missing or unsupported fields were skipped.", "OK");
        }

        private bool ApplyBatchFloat(SerializedObject serialized, string propertyName, bool enabled, float value)
        {
            if (!enabled) return false;
            SerializedProperty property = FindColliderProperty(serialized, propertyName);
            if (property == null || property.propertyType != SerializedPropertyType.Float) return false;
            property.floatValue = useBatchMultipliers ? property.floatValue * value : value;
            return true;
        }

        private void CopyTemplateProperties(List<Component> targets)
        {
            if (templateComponent == null) return;
            bool changedAny = false;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Copy Avatar Dynamics Values");
            foreach (Component target in targets)
            {
                if (target == null || target == templateComponent || target.GetType() != templateComponent.GetType()) continue;
                SerializedObject source = new SerializedObject(templateComponent);
                SerializedObject destination = new SerializedObject(target);
                source.Update();
                destination.Update();
                bool changed = false;
                Undo.RecordObject(target, "Copy Avatar Dynamics Values");
                if (copyPull) changed |= CopySerializedProperty(source, destination, "pull");
                if (copySpring) changed |= CopySerializedProperty(source, destination, "spring");
                if (copyDamping) changed |= CopySerializedProperty(source, destination, "damping");
                if (copyFriction) changed |= CopySerializedProperty(source, destination, "friction");
                if (copyImmobile) changed |= CopySerializedProperty(source, destination, "immobile");
                if (copyGravity) changed |= CopySerializedProperty(source, destination, "gravity");
                if (copyRadius) changed |= CopySerializedProperty(source, destination, "radius");
                if (copyHeight) changed |= CopySerializedProperty(source, destination, "height");
                if (copyPosition) changed |= CopySerializedProperty(source, destination, "position");
                if (copyRotation) changed |= CopySerializedProperty(source, destination, "rotation");
                if (!changed) continue;
                destination.ApplyModifiedProperties();
                PrefabUtility.RecordPrefabInstancePropertyModifications(target);
                EditorUtility.SetDirty(target);
                changedAny = true;
            }
            Undo.CollapseUndoOperations(undoGroup);
            EditorUtility.DisplayDialog("Selective Copy", changedAny ? "Checked values were copied to matching component types." : "No matching components or compatible checked values were found.", "OK");
        }

        private static bool CopySerializedProperty(SerializedObject source, SerializedObject destination, string path)
        {
            SerializedProperty sourceProperty = FindColliderProperty(source, path);
            SerializedProperty destinationProperty = FindColliderProperty(destination, path);
            if (sourceProperty == null || destinationProperty == null || sourceProperty.propertyType != destinationProperty.propertyType)
                return false;

            return CopyPropertyValue(sourceProperty, destinationProperty);
        }

        private static bool CopyPropertyValue(SerializedProperty sourceProperty, SerializedProperty destinationProperty)
        {
            if (sourceProperty == null || destinationProperty == null || sourceProperty.propertyType != destinationProperty.propertyType)
                return false;

            switch (sourceProperty.propertyType)
            {
                case SerializedPropertyType.Float: destinationProperty.floatValue = sourceProperty.floatValue; break;
                case SerializedPropertyType.Integer: destinationProperty.intValue = sourceProperty.intValue; break;
                case SerializedPropertyType.Boolean: destinationProperty.boolValue = sourceProperty.boolValue; break;
                case SerializedPropertyType.String: destinationProperty.stringValue = sourceProperty.stringValue; break;
                case SerializedPropertyType.Enum: destinationProperty.enumValueIndex = sourceProperty.enumValueIndex; break;
                case SerializedPropertyType.ObjectReference: destinationProperty.objectReferenceValue = sourceProperty.objectReferenceValue; break;
                case SerializedPropertyType.Vector2: destinationProperty.vector2Value = sourceProperty.vector2Value; break;
                case SerializedPropertyType.Vector3: destinationProperty.vector3Value = sourceProperty.vector3Value; break;
                case SerializedPropertyType.Vector4: destinationProperty.vector4Value = sourceProperty.vector4Value; break;
                case SerializedPropertyType.Color: destinationProperty.colorValue = sourceProperty.colorValue; break;
                case SerializedPropertyType.AnimationCurve: destinationProperty.animationCurveValue = sourceProperty.animationCurveValue; break;
                default: return false;
            }
            return true;
        }

        private void DrawLegacyConversion()
        {
            EditorGUILayout.LabelField("LEGACY DYNAMIC BONE CONVERSION", EditorStyles.largeLabel);
            EditorGUILayout.HelpBox("Finds legacy DynamicBone and DynamicBoneCollider components by type name, so this editor does not need a compile-time reference to the legacy asset. Value mapping is best-effort; review each new component before upload.", MessageType.Warning);
            EditorGUI.BeginChangeCheck();
            batchScope = (BatchScope)EditorGUILayout.EnumPopup("Scan Scope", batchScope);
            includeLegacyInactive = EditorGUILayout.Toggle("Include Inactive Objects", includeLegacyInactive);
            if (EditorGUI.EndChangeCheck()) ScanLegacyComponents();
            legacySearch = EditorGUILayout.TextField("Search Name / Path", legacySearch);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Scan for Legacy Components", GUILayout.Height(27f))) ScanLegacyComponents();
            removeLegacyAfterConversion = EditorGUILayout.ToggleLeft("Remove only after successful conversion", removeLegacyAfterConversion, GUILayout.Width(250f));
            EditorGUILayout.EndHorizontal();

            List<Component> visible = legacyCandidates.Where(component => component != null &&
                (string.IsNullOrWhiteSpace(legacySearch) || component.gameObject.name.IndexOf(legacySearch, StringComparison.OrdinalIgnoreCase) >= 0 ||
                 GetPath(component.transform).IndexOf(legacySearch, StringComparison.OrdinalIgnoreCase) >= 0)).ToList();
            EditorGUILayout.LabelField(visible.Count + " matching legacy component(s)", EditorStyles.boldLabel);
            legacyScroll = EditorGUILayout.BeginScrollView(legacyScroll, EditorStyles.helpBox, GUILayout.MinHeight(100f), GUILayout.MaxHeight(250f));
            foreach (Component component in visible.Take(100))
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField(component.GetType().Name, GUILayout.Width(150f));
                EditorGUILayout.LabelField(GetPath(component.transform), EditorStyles.miniLabel);
                if (GUILayout.Button("Select", GUILayout.Width(54f)))
                {
                    Selection.activeGameObject = component.gameObject;
                    EditorGUIUtility.PingObject(component.gameObject);
                }
                EditorGUILayout.EndHorizontal();
            }
            if (visible.Count > 100) EditorGUILayout.LabelField("and " + (visible.Count - 100) + " more…", EditorStyles.miniLabel);
            EditorGUILayout.EndScrollView();

            EditorGUI.BeginDisabledGroup(visible.Count == 0);
            if (GUILayout.Button("Convert Matching Components", GUILayout.Height(34f))) ConvertLegacyComponents(visible);
            EditorGUI.EndDisabledGroup();
        }

        private void ScanLegacyComponents()
        {
            legacyCandidates.Clear();
            IEnumerable<Component> source;
            if (batchScope == BatchScope.AvatarRoot)
            {
                source = avatarRoot != null && !EditorUtility.IsPersistent(avatarRoot) && avatarRoot.scene.IsValid()
                    ? avatarRoot.GetComponentsInChildren<Component>(includeLegacyInactive)
                    : Enumerable.Empty<Component>();
            }
            else if (batchScope == BatchScope.Selection)
            {
                source = (Selection.gameObjects ?? Array.Empty<GameObject>()).Where(gameObject => gameObject != null)
                    .SelectMany(gameObject => gameObject.GetComponentsInChildren<Component>(includeLegacyInactive));
            }
            else
            {
                source = Resources.FindObjectsOfTypeAll<Component>().Where(component => component != null &&
                    !EditorUtility.IsPersistent(component) && component.gameObject.scene.IsValid() &&
                    (includeLegacyInactive || component.gameObject.activeInHierarchy));
            }

            legacyCandidates.AddRange(source.Where(component => IsSupportedLegacyComponent(component) &&
                    !EditorUtility.IsPersistent(component) && component.gameObject.scene.IsValid())
                .Distinct()
                .OrderBy(component => GetPath(component.transform), StringComparer.OrdinalIgnoreCase));
        }

        private static bool IsSupportedLegacyComponent(Component component)
        {
            if (component == null) return false;
            string typeName = component.GetType().Name;
            return typeName == "DynamicBone" || typeName == "DynamicBoneCollider";
        }

        private void ConvertLegacyComponents(List<Component> sourceComponents)
        {
            int converted = 0;
            int skipped = 0;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Convert Legacy Dynamic Bones");
            foreach (Component legacy in sourceComponents.ToArray())
            {
                if (legacy == null) continue;
                bool isCollider = legacy.GetType().Name == "DynamicBoneCollider";
                Component replacement = isCollider
                    ? (Component)legacy.gameObject.GetComponent<VRCPhysBoneCollider>()
                    : legacy.gameObject.GetComponent<VRCPhysBone>();
                if (replacement != null)
                {
                    skipped++;
                    continue;
                }

                replacement = isCollider
                    ? (Component)Undo.AddComponent<VRCPhysBoneCollider>(legacy.gameObject)
                    : Undo.AddComponent<VRCPhysBone>(legacy.gameObject);
                if (replacement == null)
                {
                    skipped++;
                    continue;
                }

                Undo.RecordObject(replacement, "Convert Legacy Dynamic Bone");
                int mappedProperties = isCollider
                    ? MapLegacyCollider(legacy, (VRCPhysBoneCollider)replacement)
                    : MapLegacyPhysBone(legacy, (VRCPhysBone)replacement);
                if (mappedProperties == 0)
                {
                    Undo.DestroyObjectImmediate(replacement);
                    skipped++;
                    continue;
                }

                PrefabUtility.RecordPrefabInstancePropertyModifications(replacement);
                EditorUtility.SetDirty(replacement);
                if (removeLegacyAfterConversion) Undo.DestroyObjectImmediate(legacy);
                converted++;
            }
            Undo.CollapseUndoOperations(undoGroup);
            ScanLegacyComponents();
            ScanAvatar();
            EditorUtility.DisplayDialog("Legacy Conversion", "Converted " + converted + " component(s). Skipped " + skipped + " (already converted or no supported values found)." +
                (removeLegacyAfterConversion ? " Legacy components were removed only for successful conversions." : " Legacy components were kept."), "OK");
        }

        private static int MapLegacyPhysBone(Component source, VRCPhysBone target)
        {
            SerializedObject sourceObject = new SerializedObject(source);
            SerializedObject targetObject = new SerializedObject(target);
            sourceObject.Update();
            targetObject.Update();
            int mapped = 0;
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Root", "m_RootTransform", "root", "rootTransform" }, "rootTransform");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Elasticity", "elasticity" }, "pull");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_ElasticityDistrib", "elasticityDistrib" }, "pullCurve");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Stiffness", "stiffness" }, "spring");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_StiffnessDistrib", "stiffnessDistrib" }, "springCurve");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Damping", "damping" }, "damping");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Inert", "inert" }, "immobile");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Radius", "radius" }, "radius");
            targetObject.ApplyModifiedProperties();
            return mapped;
        }

        private static int MapLegacyCollider(Component source, VRCPhysBoneCollider target)
        {
            SerializedObject sourceObject = new SerializedObject(source);
            SerializedObject targetObject = new SerializedObject(target);
            sourceObject.Update();
            targetObject.Update();
            int mapped = 0;
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Radius", "radius" }, "radius");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Height", "height" }, "height");
            mapped += CopyFirstCompatibleProperty(sourceObject, targetObject, new[] { "m_Center", "center", "m_Position" }, "position");
            SerializedProperty legacyHeight = FindColliderProperty(sourceObject, "m_Height");
            if (legacyHeight == null) legacyHeight = FindColliderProperty(sourceObject, "height");
            if (legacyHeight != null && legacyHeight.propertyType == SerializedPropertyType.Float)
                SetSerializedEnumContains(targetObject, new[] { "shape", "shapeType" }, legacyHeight.floatValue > 0.0001f ? "Capsule" : "Sphere");
            SerializedProperty legacyBound = FindColliderProperty(sourceObject, "m_Bound");
            SerializedProperty insideBounds = FindColliderProperty(targetObject, "insideBounds");
            if (IsEnumProperty(legacyBound) && insideBounds != null &&
                insideBounds.propertyType == SerializedPropertyType.Boolean && legacyBound.enumValueIndex >= 0 &&
                legacyBound.enumValueIndex < legacyBound.enumDisplayNames.Length)
            {
                string boundName = legacyBound.enumDisplayNames[legacyBound.enumValueIndex];
                if (boundName.IndexOf("inside", StringComparison.OrdinalIgnoreCase) >= 0)
                    insideBounds.boolValue = true;
                else if (boundName.IndexOf("outside", StringComparison.OrdinalIgnoreCase) >= 0)
                    insideBounds.boolValue = false;
            }
            SerializedProperty legacyDirection = FindColliderProperty(sourceObject, "m_Direction");
            if (IsEnumProperty(legacyDirection) && legacyDirection.enumValueIndex >= 0 &&
                legacyDirection.enumValueIndex < legacyDirection.enumDisplayNames.Length)
            {
                string directionName = legacyDirection.enumDisplayNames[legacyDirection.enumValueIndex];
                Vector3 axis = directionName.IndexOf("X", StringComparison.OrdinalIgnoreCase) >= 0 ? Vector3.right :
                    directionName.IndexOf("Z", StringComparison.OrdinalIgnoreCase) >= 0 ? Vector3.forward : Vector3.up;
                SetSerializedVector3(targetObject, "rotation", Quaternion.FromToRotation(Vector3.up, axis).eulerAngles);
            }
            targetObject.ApplyModifiedProperties();
            return mapped;
        }

        private static int CopyFirstCompatibleProperty(SerializedObject source, SerializedObject destination,
            string[] sourcePaths, string destinationPath)
        {
            SerializedProperty destinationProperty = FindColliderProperty(destination, destinationPath);
            if (destinationProperty == null) return 0;
            foreach (string sourcePath in sourcePaths)
            {
                SerializedProperty sourceProperty = FindColliderProperty(source, sourcePath);
                if (sourceProperty == null || sourceProperty.propertyType != destinationProperty.propertyType) continue;
                return CopyPropertyValue(sourceProperty, destinationProperty) ? 1 : 0;
            }
            return 0;
        }

        private void DrawColliderGenerator()
        {
            EditorGUILayout.LabelField("HUMANOID COLLIDER GENERATOR", EditorStyles.largeLabel);
            EditorGUILayout.HelpBox("Creates undoable child objects aligned to humanoid bones. A collider already attached directly to a selected start bone is left alone. Generated colliders are assigned only to the explicit target PhysBone you choose below.", MessageType.Info);
            if (avatarRoot != null && (generatorAnimator == null ||
                !(generatorAnimator.transform == avatarRoot.transform || generatorAnimator.transform.IsChildOf(avatarRoot.transform))))
            {
                generatorAnimator = avatarRoot.GetComponentInChildren<Animator>(true);
                generatorTargetPhysBone = null;
            }
            generatorAnimator = (Animator)EditorGUILayout.ObjectField("Humanoid Animator", generatorAnimator, typeof(Animator), true);
            if (generatorAnimator != null && !generatorAnimator.isHuman)
                EditorGUILayout.HelpBox("This Animator is not configured as Humanoid, so humanoid bone generation is unavailable.", MessageType.Warning);

            EditorGUILayout.LabelField("Bones", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            generateHead = EditorGUILayout.ToggleLeft("Head", generateHead, GUILayout.Width(75f));
            generateChest = EditorGUILayout.ToggleLeft("Chest", generateChest, GUILayout.Width(85f));
            generateHands = EditorGUILayout.ToggleLeft("Hands", generateHands, GUILayout.Width(85f));
            generateArms = EditorGUILayout.ToggleLeft("Arms", generateArms, GUILayout.Width(75f));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            generateLegs = EditorGUILayout.ToggleLeft("Legs", generateLegs, GUILayout.Width(75f));
            generateFeet = EditorGUILayout.ToggleLeft("Feet", generateFeet, GUILayout.Width(75f));
            generatorUseCapsules = EditorGUILayout.ToggleLeft("Capsules for limbs", generatorUseCapsules, GUILayout.Width(150f));
            EditorGUILayout.EndHorizontal();
            generatorRadiusScale = EditorGUILayout.Slider("Radius / bone length", generatorRadiusScale, 0.03f, 0.35f);

            EditorGUILayout.Space(6f);
            EditorGUILayout.LabelField("PhysBone Assignment", EditorStyles.boldLabel);
            generatorTargetPhysBone = (VRCPhysBone)EditorGUILayout.ObjectField("Target PhysBone", generatorTargetPhysBone, typeof(VRCPhysBone), true);
            generatorAutoAssign = EditorGUILayout.ToggleLeft("Assign generated colliders to target PhysBone", generatorAutoAssign);
            generatorCreatePhysBone = EditorGUILayout.ToggleLeft("Create a PhysBone if no target is set", generatorCreatePhysBone);
            if (generatorCreatePhysBone && generatorAutoAssign)
                generatorNewPhysBoneObject = (GameObject)EditorGUILayout.ObjectField("New PhysBone Object", generatorNewPhysBoneObject, typeof(GameObject), true);

            Transform generationRoot = avatarRoot != null ? avatarRoot.transform :
                generatorAnimator != null ? generatorAnimator.transform.root : null;
            bool validNewPhysBoneObject = generatorNewPhysBoneObject != null && !EditorUtility.IsPersistent(generatorNewPhysBoneObject) &&
                generatorNewPhysBoneObject.scene.IsValid() && generationRoot != null &&
                (generatorNewPhysBoneObject.transform == generationRoot || generatorNewPhysBoneObject.transform.IsChildOf(generationRoot));
            bool validExistingPhysBone = generatorTargetPhysBone != null && !EditorUtility.IsPersistent(generatorTargetPhysBone) &&
                generatorTargetPhysBone.gameObject.scene.IsValid() && generationRoot != null &&
                (generatorTargetPhysBone.transform == generationRoot || generatorTargetPhysBone.transform.IsChildOf(generationRoot));
            if (generatorCreatePhysBone && generatorAutoAssign && generatorNewPhysBoneObject != null && !validNewPhysBoneObject)
                EditorGUILayout.HelpBox("The new PhysBone object must be a scene object inside the selected avatar hierarchy.", MessageType.Warning);
            if (generatorAutoAssign && generatorTargetPhysBone != null && !validExistingPhysBone)
                EditorGUILayout.HelpBox("The selected target PhysBone must be inside the selected avatar hierarchy.", MessageType.Warning);
            bool canGenerate = generatorAnimator != null && generatorAnimator.isHuman &&
                !EditorUtility.IsPersistent(generatorAnimator) && generatorAnimator.gameObject.scene.IsValid() &&
                (generateHead || generateChest || generateHands || generateArms || generateLegs || generateFeet) &&
                (!generatorAutoAssign || validExistingPhysBone || (generatorCreatePhysBone && validNewPhysBoneObject));
            EditorGUI.BeginDisabledGroup(!canGenerate);
            if (GUILayout.Button("Generate Selected Humanoid Colliders", GUILayout.Height(34f))) GenerateHumanoidColliders();
            EditorGUI.EndDisabledGroup();
        }

        private sealed class ColliderBoneSpec
        {
            public HumanBodyBones start;
            public HumanBodyBones end;
            public string label;
            public bool sphere;
        }

        private List<ColliderBoneSpec> GetColliderBoneSpecs()
        {
            List<ColliderBoneSpec> specs = new List<ColliderBoneSpec>();
            if (generateHead) specs.Add(new ColliderBoneSpec { start = HumanBodyBones.Head, end = HumanBodyBones.Neck, label = "Head", sphere = true });
            if (generateChest) specs.Add(new ColliderBoneSpec { start = HumanBodyBones.Chest, end = HumanBodyBones.Neck, label = "Chest", sphere = false });
            if (generateHands)
            {
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftHand, end = HumanBodyBones.LeftMiddleProximal, label = "Left Hand", sphere = true });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightHand, end = HumanBodyBones.RightMiddleProximal, label = "Right Hand", sphere = true });
            }
            if (generateArms)
            {
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftUpperArm, end = HumanBodyBones.LeftLowerArm, label = "Left Upper Arm" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftLowerArm, end = HumanBodyBones.LeftHand, label = "Left Forearm" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightUpperArm, end = HumanBodyBones.RightLowerArm, label = "Right Upper Arm" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightLowerArm, end = HumanBodyBones.RightHand, label = "Right Forearm" });
            }
            if (generateLegs)
            {
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftUpperLeg, end = HumanBodyBones.LeftLowerLeg, label = "Left Thigh" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftLowerLeg, end = HumanBodyBones.LeftFoot, label = "Left Shin" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightUpperLeg, end = HumanBodyBones.RightLowerLeg, label = "Right Thigh" });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightLowerLeg, end = HumanBodyBones.RightFoot, label = "Right Shin" });
            }
            if (generateFeet)
            {
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.LeftFoot, end = HumanBodyBones.LeftToes, label = "Left Foot", sphere = true });
                specs.Add(new ColliderBoneSpec { start = HumanBodyBones.RightFoot, end = HumanBodyBones.RightToes, label = "Right Foot", sphere = true });
            }
            return specs;
        }

        private void GenerateHumanoidColliders()
        {
            if (generatorAnimator == null || !generatorAnimator.isHuman || EditorUtility.IsPersistent(generatorAnimator) ||
                !generatorAnimator.gameObject.scene.IsValid()) return;
            VRCPhysBone assignTarget = generatorTargetPhysBone;
            Transform assignmentRoot = avatarRoot != null ? avatarRoot.transform : generatorAnimator.transform.root;
            if (assignTarget != null && (EditorUtility.IsPersistent(assignTarget) || !assignTarget.gameObject.scene.IsValid() ||
                !(assignTarget.transform == assignmentRoot || assignTarget.transform.IsChildOf(assignmentRoot))))
                assignTarget = null;
            generatedColliders.Clear();
            int skipped = 0;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Generate Humanoid PhysBone Colliders");
            foreach (ColliderBoneSpec spec in GetColliderBoneSpecs())
            {
                Transform start = generatorAnimator.GetBoneTransform(spec.start);
                Transform end = generatorAnimator.GetBoneTransform(spec.end);
                if (spec.start == HumanBodyBones.Chest && start == null)
                    start = generatorAnimator.GetBoneTransform(HumanBodyBones.UpperChest);
                if (start == null)
                {
                    skipped++;
                    continue;
                }
                if (start.GetComponent<VRCPhysBoneCollider>() != null)
                {
                    skipped++;
                    continue;
                }

                if (spec.start == HumanBodyBones.Chest && end == null)
                {
                    start = generatorAnimator.GetBoneTransform(HumanBodyBones.UpperChest) ?? start;
                    end = generatorAnimator.GetBoneTransform(HumanBodyBones.Neck);
                }
                Vector3 localEnd = end != null ? start.InverseTransformPoint(end.position) : Vector3.zero;
                float length = localEnd.magnitude;
                float radius = Mathf.Clamp(length * generatorRadiusScale, 0.005f, 0.25f);
                bool sphere = spec.sphere || !generatorUseCapsules;
                if (sphere && length <= 0.0001f) radius = Mathf.Max(radius, 0.04f);

                GameObject colliderObject = new GameObject("PhysBone Collider - " + spec.label);
                Undo.RegisterCreatedObjectUndo(colliderObject, "Create PhysBone Collider");
                colliderObject.transform.SetParent(start, false);
                VRCPhysBoneCollider collider = Undo.AddComponent<VRCPhysBoneCollider>(colliderObject);
                if (collider == null)
                {
                    Undo.DestroyObjectImmediate(colliderObject);
                    skipped++;
                    continue;
                }

                Vector3 center = spec.sphere ? Vector3.zero : localEnd * 0.5f;
                Vector3 direction = localEnd.sqrMagnitude > 0.0001f ? localEnd.normalized : Vector3.up;
                Quaternion localRotation = Quaternion.FromToRotation(Vector3.up, direction);
                SerializedObject serialized = new SerializedObject(collider);
                serialized.Update();
                SetSerializedVector3(serialized, "position", center);
                SetSerializedVector3(serialized, "rotation", localRotation.eulerAngles);
                SetSerializedFloat(serialized, "radius", radius);
                SetSerializedFloat(serialized, "height", Mathf.Max(radius * 2f, length + radius * 2f));
                SetSerializedEnumContains(serialized, new[] { "shape", "shapeType" }, sphere ? "Sphere" : "Capsule");
                serialized.ApplyModifiedProperties();
                PrefabUtility.RecordPrefabInstancePropertyModifications(collider);
                EditorUtility.SetDirty(collider);
                generatedColliders.Add(collider);
            }

            if (generatorAutoAssign && assignTarget == null && generatorCreatePhysBone && generatorNewPhysBoneObject != null && generatedColliders.Count > 0)
            {
                GameObject owner = generatorNewPhysBoneObject;
                if (!EditorUtility.IsPersistent(owner) && owner.scene.IsValid() &&
                    (owner.transform == assignmentRoot || owner.transform.IsChildOf(assignmentRoot)))
                {
                    assignTarget = owner.GetComponent<VRCPhysBone>();
                    if (assignTarget == null) assignTarget = Undo.AddComponent<VRCPhysBone>(owner);
                }
                generatorTargetPhysBone = assignTarget;
            }
            int assigned = assignTarget != null && generatorAutoAssign ? AssignCollidersToPhysBone(assignTarget, generatedColliders) : 0;
            Undo.CollapseUndoOperations(undoGroup);
            ScanAvatar();
            string assignmentResult = !generatorAutoAssign
                ? " Colliders were left unassigned."
                : assignTarget != null
                    ? " Assigned " + assigned + " collider(s) to " + assignTarget.gameObject.name + "."
                    : " No valid target PhysBone was available, so the colliders are unassigned.";
            EditorUtility.DisplayDialog("Collider Generation", "Created " + generatedColliders.Count + " collider(s); skipped " + skipped + " unavailable or already-covered bone(s)." +
                assignmentResult, "OK");
        }

        private static int AssignCollidersToPhysBone(VRCPhysBone physBone, IEnumerable<VRCPhysBoneCollider> colliders)
        {
            if (physBone == null) return 0;
            SerializedObject serialized = new SerializedObject(physBone);
            serialized.Update();
            SerializedProperty array = FindSerializedPropertyByNames(serialized, "colliders");
            if (array == null || !array.isArray) return 0;
            Undo.RecordObject(physBone, "Assign PhysBone Colliders");
            int assigned = 0;
            foreach (VRCPhysBoneCollider collider in colliders)
            {
                if (collider == null) continue;
                bool alreadyAssigned = false;
                for (int i = 0; i < array.arraySize; i++)
                    if (array.GetArrayElementAtIndex(i).objectReferenceValue == collider) { alreadyAssigned = true; break; }
                if (alreadyAssigned) continue;
                int index = array.arraySize++;
                array.GetArrayElementAtIndex(index).objectReferenceValue = collider;
                assigned++;
            }
            serialized.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(physBone);
            EditorUtility.SetDirty(physBone);
            return assigned;
        }

        private static void SetSerializedVector3(SerializedObject serialized, string path, Vector3 value)
        {
            SerializedProperty property = FindColliderProperty(serialized, path);
            if (property != null && property.propertyType == SerializedPropertyType.Vector3) property.vector3Value = value;
        }

        private static void SetSerializedFloat(SerializedObject serialized, string path, float value)
        {
            SerializedProperty property = FindColliderProperty(serialized, path);
            if (property != null && property.propertyType == SerializedPropertyType.Float) property.floatValue = value;
        }

        private static bool SetSerializedEnumContains(SerializedObject serialized, string[] propertyNames, string valueName)
        {
            SerializedProperty property = FindSerializedPropertyByNames(serialized, propertyNames);
            if (!IsEnumProperty(property)) return false;
            string[] names = property.enumDisplayNames;
            for (int i = 0; i < names.Length; i++)
            {
                if (string.Equals(names[i], valueName, StringComparison.OrdinalIgnoreCase) ||
                    names[i].IndexOf(valueName, StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    property.enumValueIndex = i;
                    return true;
                }
            }
            return false;
        }

        private static SerializedProperty FindSerializedPropertyByNames(SerializedObject serialized, params string[] names)
        {
            foreach (string name in names)
            {
                SerializedProperty property = FindColliderProperty(serialized, name);
                if (property != null) return property;
            }
            SerializedProperty iterator = serialized.GetIterator();
            bool enterChildren = true;
            while (iterator.NextVisible(enterChildren))
            {
                enterChildren = false;
                if (names.Any(name => string.Equals(iterator.name, name, StringComparison.OrdinalIgnoreCase)))
                    return iterator.Copy();
            }
            return null;
        }

        private void DrawContactPresets()
        {
            EditorGUILayout.LabelField("CONTACT PRESET GENERATOR", EditorStyles.largeLabel);
            EditorGUILayout.HelpBox("Creates sender/receiver components on humanoid bones, applies matching custom tags, and adds the receiver parameter to the avatar's Expression Parameters asset when one is assigned.", MessageType.Info);
            if (generatorAnimator == null && avatarRoot != null) generatorAnimator = avatarRoot.GetComponentInChildren<Animator>(true);
            generatorAnimator = (Animator)EditorGUILayout.ObjectField("Humanoid Animator", generatorAnimator, typeof(Animator), true);
            contactPreset = (ContactPreset)EditorGUILayout.EnumPopup("Preset", contactPreset);
            contactPresetPart = (ContactPresetPart)EditorGUILayout.EnumPopup("Create", contactPresetPart);
            contactParameterPrefix = EditorGUILayout.TextField("Parameter Prefix", contactParameterPrefix);
            contactRadiusScale = EditorGUILayout.Slider("Radius / bone length", contactRadiusScale, 0.03f, 0.3f);
            EditorGUILayout.BeginHorizontal();
            contactAllowSelf = EditorGUILayout.ToggleLeft("Allow Self", contactAllowSelf, GUILayout.Width(110f));
            contactAllowOthers = EditorGUILayout.ToggleLeft("Allow Others", contactAllowOthers, GUILayout.Width(130f));
            EditorGUILayout.EndHorizontal();
            includeBuiltInContactTags = EditorGUILayout.ToggleLeft("Include compatible built-in body tags", includeBuiltInContactTags);
            registerExpressionParameter = EditorGUILayout.ToggleLeft("Add receiver parameter to Expression Parameters", registerExpressionParameter);
            EditorGUILayout.HelpBox("Custom pairing tag: " + GetContactTag() + (includeBuiltInContactTags ? ". A VRChat body-part tag is also added for compatibility with other avatars." : "."), MessageType.None);
            EditorGUILayout.HelpBox("VRChat can drive a receiver's Animator parameter without adding it to the synced Expression Parameters asset. Registering it here is optional and uses that asset's parameter budget.", MessageType.None);
            bool canCreate = generatorAnimator != null && generatorAnimator.isHuman &&
                !EditorUtility.IsPersistent(generatorAnimator) && generatorAnimator.gameObject.scene.IsValid();
            EditorGUI.BeginDisabledGroup(!canCreate);
            if (GUILayout.Button("Create Contact Preset", GUILayout.Height(34f))) GenerateContactPreset();
            EditorGUI.EndDisabledGroup();
        }

        private void GenerateContactPreset()
        {
            if (generatorAnimator == null || !generatorAnimator.isHuman || EditorUtility.IsPersistent(generatorAnimator) ||
                !generatorAnimator.gameObject.scene.IsValid()) return;
            HumanBodyBones senderBone = GetContactSenderBone(contactPreset);
            HumanBodyBones receiverBone = GetContactReceiverBone(contactPreset);
            Transform senderTransform = generatorAnimator.GetBoneTransform(senderBone);
            Transform receiverTransform = generatorAnimator.GetBoneTransform(receiverBone);
            if (senderTransform == null || receiverTransform == null)
            {
                EditorUtility.DisplayDialog("Contact Preset", "The selected Humanoid Animator is missing a required hand or head bone.", "OK");
                return;
            }

            string tag = GetContactTag();
            string[] senderTags = GetContactTags(true);
            string[] receiverTags = GetContactTags(false);
            string parameterName = GetContactParameterName();
            int created = 0;
            bool parameterRegistered = false;
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Create Avatar Contact Preset");
            if (contactPresetPart == ContactPresetPart.Sender || contactPresetPart == ContactPresetPart.Both)
            {
                VRCContactSender sender = Undo.AddComponent<VRCContactSender>(senderTransform.gameObject);
                if (sender != null)
                {
                    ConfigureContact(sender, senderTags, parameterName, GetContactRadius(senderTransform), contactAllowSelf, contactAllowOthers);
                    created++;
                }
            }
            if (contactPresetPart == ContactPresetPart.Receiver || contactPresetPart == ContactPresetPart.Both)
            {
                VRCContactReceiver receiver = Undo.AddComponent<VRCContactReceiver>(receiverTransform.gameObject);
                if (receiver != null)
                {
                    ConfigureContact(receiver, receiverTags, parameterName, GetContactRadius(receiverTransform), contactAllowSelf, contactAllowOthers);
                    created++;
                    parameterRegistered = !registerExpressionParameter || RegisterContactParameter(parameterName);
                }
            }
            Undo.CollapseUndoOperations(undoGroup);
            ScanAvatar();
            string registrationMessage = contactPresetPart == ContactPresetPart.Sender
                ? " No Expression Parameter was needed for sender-only mode."
                : !registerExpressionParameter
                    ? " The receiver parameter was not added to the synced Expression Parameters list."
                    : parameterRegistered ? " The receiver parameter is registered." : " Assign an Expression Parameters asset and add the receiver parameter manually.";
            EditorUtility.DisplayDialog("Contact Preset", "Created " + created + " contact component(s) using tag " + tag + "." + registrationMessage, "OK");
        }

        private static HumanBodyBones GetContactSenderBone(ContactPreset preset)
        {
            switch (preset)
            {
                case ContactPreset.Handshake: return HumanBodyBones.RightHand;
                case ContactPreset.EyeContact: return HumanBodyBones.Head;
                default: return HumanBodyBones.LeftHand;
            }
        }

        private static HumanBodyBones GetContactReceiverBone(ContactPreset preset)
        {
            switch (preset)
            {
                case ContactPreset.Handshake: return HumanBodyBones.LeftHand;
                default: return HumanBodyBones.Head;
            }
        }

        private string GetContactTag()
        {
            return SanitizeContactToken(contactParameterPrefix) + "." + contactPreset.ToString();
        }

        private string GetContactParameterName()
        {
            return SanitizeContactToken(contactParameterPrefix) + "_" + contactPreset.ToString();
        }

        private string[] GetContactTags(bool sender)
        {
            string custom = GetContactTag();
            if (!includeBuiltInContactTags) return new[] { custom };
            string builtIn;
            if (sender)
            {
                switch (contactPreset)
                {
                    case ContactPreset.EyeContact: builtIn = "Head"; break;
                    case ContactPreset.Handshake: builtIn = "HandR"; break;
                    default: builtIn = "HandL"; break;
                }
            }
            else
            {
                switch (contactPreset)
                {
                    case ContactPreset.EyeContact: builtIn = "Head"; break;
                    case ContactPreset.NoseBoop: builtIn = "Finger"; break;
                    default: builtIn = "Hand"; break;
                }
            }
            return new[] { builtIn, custom };
        }

        private static string SanitizeContactToken(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return "NINSA";
            string token = new string(value.Trim().Select(character => char.IsLetterOrDigit(character) || character == '_' ? character : '_').ToArray());
            return token.Length > 20 ? token.Substring(0, 20) : token;
        }

        private float GetContactRadius(Transform bone)
        {
            if (bone == null) return 0.03f;
            float length = bone.parent != null ? Vector3.Distance(bone.position, bone.parent.position) : 0.1f;
            for (int i = 0; i < bone.childCount; i++)
                length = Mathf.Max(length, Vector3.Distance(bone.position, bone.GetChild(i).position));
            return Mathf.Clamp(length * contactRadiusScale, 0.005f, 0.2f);
        }

        private void ConfigureContact(Component contact, string[] contactTags, string parameter, float radius, bool allowSelf, bool allowOthers)
        {
            Undo.RecordObject(contact, "Configure Contact Preset");
            SerializedObject serialized = new SerializedObject(contact);
            serialized.Update();
            SetSerializedFloat(serialized, "radius", radius);
            SetSerializedFloat(serialized, "height", radius * 2f);
            SetSerializedVector3(serialized, "position", Vector3.zero);
            SetSerializedVector3(serialized, "rotation", Vector3.zero);
            SetSerializedEnumContains(serialized, new[] { "shapeType", "shape" }, "Sphere");
            SetSerializedBool(serialized, "allowSelf", allowSelf);
            SetSerializedBool(serialized, "allowOthers", allowOthers);
            SetSerializedString(serialized, "parameter", parameter);
            SerializedProperty tags = FindSerializedPropertyByNames(serialized, "collisionTags", "tags");
            if (tags != null && tags.isArray)
            {
                tags.arraySize = contactTags.Length;
                for (int i = 0; i < contactTags.Length; i++)
                {
                    SerializedProperty tagProperty = tags.GetArrayElementAtIndex(i);
                    if (tagProperty.propertyType == SerializedPropertyType.String) tagProperty.stringValue = contactTags[i];
                }
            }
            serialized.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(contact);
            EditorUtility.SetDirty(contact);
        }

        private bool RegisterContactParameter(string parameterName)
        {
            VRCAvatarDescriptor descriptor = avatarRoot != null
                ? avatarRoot.GetComponent<VRCAvatarDescriptor>() ?? avatarRoot.GetComponentInChildren<VRCAvatarDescriptor>(true)
                : generatorAnimator != null ? generatorAnimator.GetComponentInParent<VRCAvatarDescriptor>() : null;
            ScriptableObject asset = descriptor != null ? descriptor.expressionParameters : null;
            if (asset == null) return false;

            SerializedObject serialized = new SerializedObject(asset);
            serialized.Update();
            SerializedProperty parameters = FindSerializedPropertyByNames(serialized, "parameters");
            if (parameters == null || !parameters.isArray) return false;
            for (int i = 0; i < parameters.arraySize; i++)
            {
                SerializedProperty existingName = parameters.GetArrayElementAtIndex(i).FindPropertyRelative("name");
                if (existingName != null && string.Equals(existingName.stringValue, parameterName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            Undo.RecordObject(asset, "Add Contact Expression Parameter");
            int index = parameters.arraySize++;
            SerializedProperty entry = parameters.GetArrayElementAtIndex(index);
            SerializedProperty name = entry.FindPropertyRelative("name");
            SerializedProperty valueType = entry.FindPropertyRelative("valueType");
            SerializedProperty defaultValue = entry.FindPropertyRelative("defaultValue");
            SerializedProperty saved = entry.FindPropertyRelative("saved");
            SerializedProperty networkSynced = entry.FindPropertyRelative("networkSynced");
            if (name != null) name.stringValue = parameterName;
            if (IsEnumProperty(valueType))
            {
                string[] enumNames = valueType.enumDisplayNames;
                for (int i = 0; i < enumNames.Length; i++)
                    if (string.Equals(enumNames[i], "Bool", StringComparison.OrdinalIgnoreCase)) { valueType.enumValueIndex = i; break; }
            }
            if (defaultValue != null && defaultValue.propertyType == SerializedPropertyType.Float) defaultValue.floatValue = 0f;
            if (saved != null && saved.propertyType == SerializedPropertyType.Boolean) saved.boolValue = false;
            if (networkSynced != null && networkSynced.propertyType == SerializedPropertyType.Boolean) networkSynced.boolValue = true;
            serialized.ApplyModifiedProperties();
            EditorUtility.SetDirty(asset);
            PrefabUtility.RecordPrefabInstancePropertyModifications(asset);
            return name != null;
        }

        private static void SetSerializedBool(SerializedObject serialized, string path, bool value)
        {
            SerializedProperty property = FindColliderProperty(serialized, path);
            if (property != null && property.propertyType == SerializedPropertyType.Boolean) property.boolValue = value;
        }

        private static void SetSerializedString(SerializedObject serialized, string path, string value)
        {
            SerializedProperty property = FindColliderProperty(serialized, path);
            if (property != null && property.propertyType == SerializedPropertyType.String) property.stringValue = value;
        }

        private void DrawPerformanceAudit()
        {
            EditorGUILayout.LabelField("DYNAMICS PERFORMANCE AUDIT", EditorStyles.largeLabel);
            EditorGUILayout.HelpBox("Counts include disabled components under the selected avatar root. The rank shown here estimates the listed PhysBone, collider, and contact metrics; the official VRChat rank also includes meshes, materials, bones, constraints, particles, and other systems.", MessageType.Info);
            if (avatarRoot == null)
            {
                EditorGUILayout.HelpBox("Choose an avatar root in the bar at the top to run the audit.", MessageType.Warning);
                return;
            }

            performancePlatform = (PerformancePlatform)EditorGUILayout.EnumPopup("Target Platform", performancePlatform);
            List<VRCPhysBone> avatarPhysBones = avatarRoot.GetComponentsInChildren<VRCPhysBone>(true).ToList();
            List<VRCPhysBoneCollider> avatarColliders = avatarRoot.GetComponentsInChildren<VRCPhysBoneCollider>(true).ToList();
            int affectedTransforms = 0;
            int collisionChecks = 0;
            foreach (VRCPhysBone physBone in avatarPhysBones)
            {
                Transform root = GetPhysBoneRoot(physBone);
                int transformCount = root != null ? root.GetComponentsInChildren<Transform>(true).Length : 0;
                affectedTransforms += transformCount;
                SerializedObject serialized = new SerializedObject(physBone);
                serialized.Update();
                SerializedProperty colliders = FindSerializedPropertyByNames(serialized, "colliders");
                int assignedColliderCount = 0;
                if (colliders != null && colliders.isArray)
                    for (int i = 0; i < colliders.arraySize; i++)
                        if (colliders.GetArrayElementAtIndex(i).objectReferenceValue != null) assignedColliderCount++;
                collisionChecks += transformCount * assignedColliderCount;
            }

            int contactCount = avatarRoot.GetComponentsInChildren<VRCContactSender>(true).Count(sender => !IsLocalOnlyContact(sender)) +
                               avatarRoot.GetComponentsInChildren<VRCContactReceiver>(true).Count(receiver => !IsLocalOnlyContact(receiver));
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            DrawAuditMetric("PhysBone Components", avatarPhysBones.Count, GetMetricLimits("components"));
            DrawAuditMetric("Affected Transforms (estimated)", affectedTransforms, GetMetricLimits("transforms"));
            DrawAuditMetric("PhysBone Colliders", avatarColliders.Count, GetMetricLimits("colliders"));
            DrawAuditMetric("Collision Checks (estimated)", collisionChecks, GetMetricLimits("checks"));
            DrawAuditMetric("Contact Components", contactCount, GetMetricLimits("contacts"));
            EditorGUILayout.Space(5f);
            EditorGUILayout.LabelField("Estimated dynamics rank: " + GetEstimatedDynamicsRank(avatarPhysBones.Count, affectedTransforms, avatarColliders.Count, collisionChecks, contactCount), EditorStyles.boldLabel);
            EditorGUILayout.EndVertical();
            EditorGUILayout.HelpBox("Affected transforms and collision checks are estimates based on hierarchy descendants and explicitly assigned colliders. The VRChat SDK build panel is the authoritative result.", MessageType.None);

            List<List<VRCPhysBoneCollider>> duplicates = GetDuplicateColliderGroups(avatarColliders);
            EditorGUILayout.Space(8f);
            EditorGUILayout.LabelField("Collider Deduplication", EditorStyles.boldLabel);
            EditorGUILayout.HelpBox("Finds colliders on the same transform with matching shape, radius, height, position, and rotation. Before removing duplicates, references in PhysBones are remapped to the kept collider.", MessageType.None);
            if (duplicates.Count == 0)
            {
                EditorGUILayout.LabelField("No exact duplicate colliders found.", EditorStyles.miniLabel);
            }
            else
            {
                int duplicateCount = duplicates.Sum(group => group.Count - 1);
                EditorGUILayout.LabelField(duplicates.Count + " duplicate group(s), " + duplicateCount + " removable component(s)", EditorStyles.boldLabel);
                duplicateScroll = EditorGUILayout.BeginScrollView(duplicateScroll, EditorStyles.helpBox, GUILayout.MaxHeight(150f));
                foreach (List<VRCPhysBoneCollider> group in duplicates)
                {
                    VRCPhysBoneCollider keep = group[0];
                    EditorGUILayout.LabelField(GetPath(keep.transform) + " — keep one, remove " + (group.Count - 1), EditorStyles.miniLabel);
                }
                EditorGUILayout.EndScrollView();
                if (GUILayout.Button("Merge Exact Duplicates", GUILayout.Height(28f))) RemoveDuplicateColliders(duplicates);
            }
            if (GUILayout.Button("Refresh Audit")) Repaint();
        }

        private static List<List<VRCPhysBoneCollider>> GetDuplicateColliderGroups(IEnumerable<VRCPhysBoneCollider> colliders)
        {
            return colliders.Where(collider => collider != null)
                .GroupBy(GetColliderDeduplicationKey)
                .Where(group => group.Count() > 1)
                .Select(group => group.OrderBy(collider => collider.GetInstanceID()).ToList())
                .ToList();
        }

        private static string GetColliderDeduplicationKey(VRCPhysBoneCollider collider)
        {
            SerializedObject serialized = new SerializedObject(collider);
            serialized.Update();
            SerializedProperty radius = FindColliderProperty(serialized, "radius");
            SerializedProperty height = FindColliderProperty(serialized, "height");
            SerializedProperty position = FindColliderProperty(serialized, "position");
            SerializedProperty rotation = FindColliderProperty(serialized, "rotation");
            SerializedProperty shape = FindSerializedPropertyByNames(serialized, "shape", "shapeType");
            string radiusValue = radius != null && radius.propertyType == SerializedPropertyType.Float ? radius.floatValue.ToString("R", CultureInfo.InvariantCulture) : "?";
            string heightValue = height != null && height.propertyType == SerializedPropertyType.Float ? height.floatValue.ToString("R", CultureInfo.InvariantCulture) : "?";
            string positionValue = position != null && position.propertyType == SerializedPropertyType.Vector3 ? FormatVector(position.vector3Value) : "?";
            string rotationValue = rotation != null && rotation.propertyType == SerializedPropertyType.Vector3 ? FormatVector(rotation.vector3Value) : "?";
            string shapeValue = IsEnumProperty(shape) ? shape.enumValueIndex.ToString(CultureInfo.InvariantCulture) : "?";
            return collider.transform.GetInstanceID() + "|" + collider.enabled + "|" + shapeValue + "|" + radiusValue + "|" + heightValue + "|" + positionValue + "|" + rotationValue;
        }

        private static string FormatVector(Vector3 value)
        {
            return value.x.ToString("R", CultureInfo.InvariantCulture) + "," +
                   value.y.ToString("R", CultureInfo.InvariantCulture) + "," +
                   value.z.ToString("R", CultureInfo.InvariantCulture);
        }

        private void RemoveDuplicateColliders(List<List<VRCPhysBoneCollider>> duplicateGroups)
        {
            int duplicateCount = duplicateGroups.Sum(group => group.Count - 1);
            if (!EditorUtility.DisplayDialog("Merge Duplicate Colliders",
                    "Remove " + duplicateCount + " exact duplicate collider component(s) and redirect PhysBone references to the kept collider? This can be undone.",
                    "Merge", "Cancel")) return;

            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Merge Duplicate PhysBone Colliders");
            List<VRCPhysBone> allPhysBones = Resources.FindObjectsOfTypeAll<VRCPhysBone>()
                .Where(physBone => physBone != null && physBone.gameObject.scene.IsValid() && !EditorUtility.IsPersistent(physBone)).ToList();
            foreach (List<VRCPhysBoneCollider> group in duplicateGroups)
            {
                VRCPhysBoneCollider keep = group[0];
                foreach (VRCPhysBoneCollider duplicate in group.Skip(1))
                {
                    if (duplicate == null || keep == null) continue;
                    foreach (VRCPhysBone physBone in allPhysBones)
                        ReplaceColliderReference(physBone, duplicate, keep);
                    Undo.DestroyObjectImmediate(duplicate);
                }
            }
            Undo.CollapseUndoOperations(undoGroup);
            ScanAvatar();
        }

        private static void ReplaceColliderReference(VRCPhysBone physBone, VRCPhysBoneCollider from, VRCPhysBoneCollider to)
        {
            SerializedObject serialized = new SerializedObject(physBone);
            serialized.Update();
            SerializedProperty array = FindSerializedPropertyByNames(serialized, "colliders");
            if (array == null || !array.isArray) return;
            bool hasKeep = false;
            for (int i = 0; i < array.arraySize; i++)
                if (array.GetArrayElementAtIndex(i).objectReferenceValue == to) { hasKeep = true; break; }

            bool changed = false;
            for (int i = array.arraySize - 1; i >= 0; i--)
            {
                SerializedProperty element = array.GetArrayElementAtIndex(i);
                if (element.objectReferenceValue != from) continue;
                Undo.RecordObject(physBone, "Remap PhysBone Collider");
                if (hasKeep)
                {
                    array.DeleteArrayElementAtIndex(i);
                    if (i < array.arraySize && array.GetArrayElementAtIndex(i).objectReferenceValue == null)
                        array.DeleteArrayElementAtIndex(i);
                }
                else
                {
                    element.objectReferenceValue = to;
                    hasKeep = true;
                }
                changed = true;
            }
            if (!changed) return;
            serialized.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(physBone);
            EditorUtility.SetDirty(physBone);
        }

        private int[] GetMetricLimits(string metric)
        {
            if (performancePlatform == PerformancePlatform.PC)
            {
                switch (metric)
                {
                    case "components": return new[] { 4, 8, 16, 32 };
                    case "transforms": return new[] { 16, 64, 128, 256 };
                    case "colliders": return new[] { 4, 8, 16, 32 };
                    case "checks": return new[] { 32, 128, 256, 512 };
                    default: return new[] { 8, 16, 24, 32 };
                }
            }
            switch (metric)
            {
                case "components": return new[] { 0, 4, 6, 8 };
                case "transforms": return new[] { 0, 16, 32, 64 };
                case "colliders": return new[] { 0, 4, 8, 16 };
                case "checks": return new[] { 0, 16, 32, 64 };
                default: return new[] { 2, 4, 8, 16 };
            }
        }

        private static void DrawAuditMetric(string label, int count, int[] limits)
        {
            int rank = 0;
            while (rank < limits.Length && count > limits[rank]) rank++;
            string estimate = rank >= limits.Length ? "Very Poor+" : new[] { "Excellent", "Good", "Medium", "Poor" }[rank];
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(label, GUILayout.Width(245f));
            EditorGUILayout.LabelField(count.ToString(), EditorStyles.boldLabel, GUILayout.Width(45f));
            EditorGUILayout.LabelField(estimate, EditorStyles.miniLabel, GUILayout.Width(100f));
            EditorGUILayout.LabelField("Limits: " + string.Join(" / ", limits), EditorStyles.miniLabel);
            EditorGUILayout.EndHorizontal();
        }

        private string GetEstimatedDynamicsRank(params int[] counts)
        {
            string[] metrics = { "components", "transforms", "colliders", "checks", "contacts" };
            int worstRank = 0;
            for (int i = 0; i < metrics.Length; i++)
            {
                int[] limits = GetMetricLimits(metrics[i]);
                int rank = 0;
                while (rank < limits.Length && counts[i] > limits[rank]) rank++;
                worstRank = Mathf.Max(worstRank, rank);
            }
            return worstRank >= 4 ? "Very Poor or above" : new[] { "Excellent", "Good", "Medium", "Poor" }[worstRank];
        }

        private static Transform GetPhysBoneRoot(VRCPhysBone physBone)
        {
            if (physBone == null) return null;
            SerializedObject serialized = new SerializedObject(physBone);
            serialized.Update();
            SerializedProperty root = FindSerializedPropertyByNames(serialized, "rootTransform", "root");
            Transform configuredRoot = root != null && root.propertyType == SerializedPropertyType.ObjectReference
                ? root.objectReferenceValue as Transform
                : null;
            return configuredRoot != null ? configuredRoot : physBone.transform;
        }

        private static bool IsLocalOnlyContact(Component contact)
        {
            if (contact == null) return false;
            SerializedObject serialized = new SerializedObject(contact);
            serialized.Update();
            SerializedProperty localOnly = FindSerializedPropertyByNames(serialized, "localOnly");
            return localOnly != null && localOnly.propertyType == SerializedPropertyType.Boolean && localOnly.boolValue;
        }

        private void DrawSettings()
        {
            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField("Scene View", EditorStyles.largeLabel);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUI.BeginChangeCheck();
            highlightSelectedObject = EditorGUILayout.ToggleLeft("Glow the selected dynamics object", highlightSelectedObject);
            using (new EditorGUI.DisabledScope(!highlightSelectedObject))
                highlightColor = EditorGUILayout.ColorField("Glow Color", highlightColor);
            if (EditorGUI.EndChangeCheck()) SceneView.RepaintAll();
            EditorGUILayout.HelpBox("The selected PhysBone, collider, or contact object is outlined in the Scene view. Objects with renderers also outline their visible bounds.", MessageType.None);
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(12f);
            EditorGUILayout.LabelField("PhysBone Collider Scene Editor", EditorStyles.largeLabel);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUI.BeginChangeCheck();
            showColliderSceneGizmos = EditorGUILayout.ToggleLeft("Draw collider shape in Scene view", showColliderSceneGizmos);
            enableColliderSceneEditing = EditorGUILayout.ToggleLeft("Enable Scene view property handles", enableColliderSceneEditing);
            showPhysBoneSceneGizmos = EditorGUILayout.ToggleLeft("Draw selected PhysBone chain gizmos", showPhysBoneSceneGizmos);
            using (new EditorGUI.DisabledScope(!showColliderSceneGizmos))
                colliderGizmoColor = EditorGUILayout.ColorField("Collider Gizmo Color", colliderGizmoColor);
            using (new EditorGUI.DisabledScope(!showPhysBoneSceneGizmos))
                physBoneGizmoColor = EditorGUILayout.ColorField("PhysBone Gizmo Color", physBoneGizmoColor);
            if (EditorGUI.EndChangeCheck())
            {
                SaveSceneEditorSettings();
                SceneView.RepaintAll();
            }
            EditorGUILayout.HelpBox(
                "Select a PhysBone Collider in the Hierarchy or Colliders list. The Scene view editor lets you adjust Radius, Height, Position, and Rotation with handles, while the VRChat inspector remains available for every other setting.",
                MessageType.None);
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(12f);
            EditorGUILayout.LabelField("Force Delete", EditorStyles.largeLabel);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.HelpBox("Force-delete the currently selected scene GameObjects. Their child objects are removed with them. The action is confirmed and can be undone.", MessageType.Warning);

            List<GameObject> targets = GetTopLevelSelectedObjects();
            int selectedCount = Selection.gameObjects == null ? 0 : Selection.gameObjects.Length;
            EditorGUILayout.LabelField("Selected scene objects", targets.Count + " of " + selectedCount);
            if (targets.Count > 0)
            {
                foreach (GameObject target in targets.Take(5))
                    EditorGUILayout.LabelField("• " + GetPath(target.transform), EditorStyles.miniLabel);
                if (targets.Count > 5)
                    EditorGUILayout.LabelField("and " + (targets.Count - 5) + " more…", EditorStyles.miniLabel);
            }

            EditorGUI.BeginDisabledGroup(targets.Count == 0);
            if (GUILayout.Button("Force Delete Selected Objects", GUILayout.Height(32f)))
                ForceDeleteSelectedObjects();
            EditorGUI.EndDisabledGroup();
            EditorGUILayout.EndVertical();
        }

        private void DrawOverview()
        {
            EditorGUILayout.Space(10f);
            EditorGUILayout.LabelField(avatarRoot.name, EditorStyles.largeLabel);
            EditorGUILayout.LabelField(GetPath(avatarRoot.transform), EditorStyles.miniLabel);
            EditorGUILayout.Space(8f);

            EditorGUILayout.BeginHorizontal();
            DrawMetric("PhysBones", physBones.Count);
            DrawMetric("Colliders", physBoneColliders.Count);
            DrawMetric("Contact Senders", contactSenders.Count);
            DrawMetric("Contact Receivers", contactReceivers.Count);
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space(8f);
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Quick Add", EditorStyles.boldLabel);
            EditorGUILayout.LabelField("Adds the selected VRChat component to the currently selected GameObject.", EditorStyles.wordWrappedMiniLabel);
            DrawCreateForSelection();
            EditorGUILayout.EndVertical();

            EditorGUILayout.Space(8f);
            EditorGUILayout.HelpBox(
                "Open a component tab to use VRChat's inspector and ADO Scene handles. Batch Edit supports scene, selection, and avatar scopes; Legacy safely maps known DynamicBone values; Generate and Presets create humanoid collider/contact setups; Audit estimates dynamics performance and can merge exact collider duplicates.",
                MessageType.Info);
        }

        private void DrawMetric(string label, int value)
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox, GUILayout.ExpandWidth(true));
            EditorGUILayout.LabelField(label, EditorStyles.miniLabel);
            EditorGUILayout.LabelField(value.ToString(), EditorStyles.largeLabel);
            EditorGUILayout.EndVertical();
        }

        private void DrawCreateForSelection()
        {
            GameObject target = Selection.activeGameObject;
            if (target == null)
            {
                EditorGUILayout.HelpBox("Select a GameObject to add dynamics components.", MessageType.None);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Add PhysBone")) AddComponentToSelection(typeof(VRCPhysBone));
            if (GUILayout.Button("Add Collider")) AddComponentToSelection(typeof(VRCPhysBoneCollider));
            if (GUILayout.Button("Add Contact Sender")) AddComponentToSelection(typeof(VRCContactSender));
            if (GUILayout.Button("Add Contact Receiver")) AddComponentToSelection(typeof(VRCContactReceiver));
            EditorGUILayout.EndHorizontal();
        }

        private void DrawComponentBrowser()
        {
            List<Component> components = GetCurrentPageComponents();
            EnsureSelectionForPage(components);

            EditorGUILayout.BeginHorizontal();
            DrawComponentList(components);
            DrawSelectedComponentPanel();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawComponentList(List<Component> components)
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(310f), GUILayout.ExpandHeight(true));
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(currentPage.ToString(), EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            EditorGUILayout.LabelField(components.Count.ToString(), EditorStyles.miniLabel, GUILayout.Width(28f));
            EditorGUILayout.EndHorizontal();

            searchText = EditorGUILayout.TextField("Search", searchText);
            componentListScroll = EditorGUILayout.BeginScrollView(componentListScroll, EditorStyles.helpBox);

            List<Component> visible = components.Where(MatchesSearch).ToList();
            if (visible.Count == 0)
            {
                EditorGUILayout.HelpBox("No matching components found.", MessageType.None);
            }

            foreach (Component component in visible)
                DrawComponentRow(component);

            EditorGUILayout.EndScrollView();
            DrawAddButtonsForCurrentPage();
            EditorGUILayout.EndVertical();
        }

        private void DrawComponentRow(Component component)
        {
            if (component == null) return;

            bool isSelected = component == selectedComponent;
            Color oldColor = GUI.backgroundColor;
            if (isSelected) GUI.backgroundColor = new Color(0.36f, 0.62f, 0.82f, 0.45f);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button(component.gameObject.name, EditorStyles.boldLabel, GUILayout.ExpandWidth(true)))
                SelectComponent(component);

            if (component is Behaviour behaviour)
            {
                EditorGUI.BeginChangeCheck();
                bool enabled = EditorGUILayout.Toggle(behaviour.enabled, GUILayout.Width(18f));
                if (EditorGUI.EndChangeCheck())
                {
                    Undo.RecordObject(behaviour, "Toggle Dynamics Component");
                    behaviour.enabled = enabled;
                    EditorUtility.SetDirty(behaviour);
                    PrefabUtility.RecordPrefabInstancePropertyModifications(behaviour);
                }
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.LabelField(GetPath(component.transform), EditorStyles.miniLabel);
            EditorGUILayout.LabelField(GetFriendlyTypeName(component), EditorStyles.miniLabel);
            EditorGUILayout.EndVertical();
            GUI.backgroundColor = oldColor;
        }

        private void DrawSelectedComponentPanel()
        {
            EditorGUILayout.BeginVertical(GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));
            inspectorScroll = EditorGUILayout.BeginScrollView(inspectorScroll);

            if (selectedComponent == null)
            {
                EditorGUILayout.HelpBox("Select a component from the list to edit it.", MessageType.Info);
            }
            else
            {
                DrawSelectedComponentActions();
                EditorGUILayout.Space(6f);

                if (selectedComponentEditor == null)
                    SelectComponent(selectedComponent);

                if (selectedComponentEditor != null)
                {
                    selectedComponentEditor.serializedObject.Update();
                    selectedComponentEditor.OnInspectorGUI();
                    selectedComponentEditor.serializedObject.ApplyModifiedProperties();
                }
                else
                {
                    EditorGUILayout.HelpBox("Unity could not create the component inspector.", MessageType.Warning);
                }
            }

            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }

        private void DrawSelectedComponentActions()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(GetFriendlyTypeName(selectedComponent), EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Select", GUILayout.Width(64f)))
            {
                Selection.activeGameObject = selectedComponent.gameObject;
                EditorGUIUtility.PingObject(selectedComponent.gameObject);
            }
            if (GUILayout.Button("Copy", GUILayout.Width(56f)))
                global::UnityEditorInternal.ComponentUtility.CopyComponent(selectedComponent);
            if (GUILayout.Button("Paste Values", GUILayout.Width(92f)))
            {
                Undo.RecordObject(selectedComponent, "Paste Dynamics Component Values");
                if (global::UnityEditorInternal.ComponentUtility.PasteComponentValues(selectedComponent))
                {
                    PrefabUtility.RecordPrefabInstancePropertyModifications(selectedComponent);
                    EditorUtility.SetDirty(selectedComponent);
                }
            }
            EditorGUILayout.EndHorizontal();

            DrawConversionButtons();
            EditorGUILayout.EndVertical();
        }

        private void DrawConversionButtons()
        {
            EditorGUILayout.BeginHorizontal();
            if (selectedComponent is VRCPhysBoneCollider)
            {
                if (GUILayout.Button("Move To Child")) MoveColliderToChild((VRCPhysBoneCollider)selectedComponent, true);
                if (GUILayout.Button("Convert To Sender")) ConvertComponent(selectedComponent, typeof(VRCContactSender), true);
                if (GUILayout.Button("Convert To Receiver")) ConvertComponent(selectedComponent, typeof(VRCContactReceiver), true);
            }
            else if (selectedComponent is VRCContactSender)
            {
                if (GUILayout.Button("Convert To Receiver")) ConvertComponent(selectedComponent, typeof(VRCContactReceiver), true);
                if (GUILayout.Button("Convert To Collider")) ConvertComponent(selectedComponent, typeof(VRCPhysBoneCollider), true);
            }
            else if (selectedComponent is VRCContactReceiver)
            {
                if (GUILayout.Button("Convert To Sender")) ConvertComponent(selectedComponent, typeof(VRCContactSender), true);
                if (GUILayout.Button("Convert To Collider")) ConvertComponent(selectedComponent, typeof(VRCPhysBoneCollider), true);
            }

            if (GUILayout.Button("Remove", GUILayout.Width(72f)))
            {
                if (EditorUtility.DisplayDialog("Remove Component", "Remove this dynamics component? This can be undone.", "Remove", "Cancel"))
                {
                    Component oldComponent = selectedComponent;
                    SelectComponent(null);
                    Undo.DestroyObjectImmediate(oldComponent);
                    ScanAvatar();
                }
            }
            EditorGUILayout.EndHorizontal();
        }

        private void DrawAddButtonsForCurrentPage()
        {
            GameObject target = Selection.activeGameObject;
            if (target == null) return;

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.LabelField("Add to selected object", EditorStyles.miniBoldLabel);
            switch (currentPage)
            {
                case Page.PhysBones:
                    if (GUILayout.Button("Add PhysBone")) AddComponentToSelection(typeof(VRCPhysBone));
                    break;
                case Page.Colliders:
                    if (GUILayout.Button("Add Collider")) AddComponentToSelection(typeof(VRCPhysBoneCollider));
                    break;
                case Page.Contacts:
                    EditorGUILayout.BeginHorizontal();
                    if (GUILayout.Button("Sender")) AddComponentToSelection(typeof(VRCContactSender));
                    if (GUILayout.Button("Receiver")) AddComponentToSelection(typeof(VRCContactReceiver));
                    EditorGUILayout.EndHorizontal();
                    break;
            }
            EditorGUILayout.EndVertical();
        }

        private List<Component> GetCurrentPageComponents()
        {
            switch (currentPage)
            {
                case Page.PhysBones:
                    return physBones.Cast<Component>().ToList();
                case Page.Colliders:
                    return physBoneColliders.Cast<Component>().ToList();
                case Page.Contacts:
                    return contactSenders.Cast<Component>().Concat(contactReceivers.Cast<Component>())
                        .OrderBy(component => GetPath(component.transform), StringComparer.OrdinalIgnoreCase)
                        .ToList();
                default:
                    return new List<Component>();
            }
        }

        private bool MatchesSearch(Component component)
        {
            if (component == null) return false;
            if (string.IsNullOrWhiteSpace(searchText)) return true;

            return component.gameObject.name.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                   GetPath(component.transform).IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 ||
                   GetFriendlyTypeName(component).IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void EnsureSelectionForPage(List<Component> components = null)
        {
            if (components == null) components = GetCurrentPageComponents();
            if (selectedComponent != null && components.Contains(selectedComponent)) return;
            SelectComponent(components.FirstOrDefault());
        }

        private void SelectComponent(Component component)
        {
            sceneEditCollider = component as VRCPhysBoneCollider;
            sceneEditPhysBone = component as VRCPhysBone;
            if (selectedComponent == component && selectedComponentEditor != null)
            {
                SceneView.RepaintAll();
                return;
            }
            ReleaseSelectedEditor();
            selectedComponent = component;
            if (selectedComponent != null)
                selectedComponentEditor = global::UnityEditor.Editor.CreateEditor(selectedComponent);
            SceneView.RepaintAll();
        }

        private void ReleaseSelectedEditor()
        {
            if (selectedComponentEditor != null)
                DestroyImmediate(selectedComponentEditor);
            selectedComponentEditor = null;
        }

        private void ScanAvatar()
        {
            physBones.Clear();
            physBoneColliders.Clear();
            contactSenders.Clear();
            contactReceivers.Clear();

            if (avatarRoot != null)
            {
                physBones.AddRange(avatarRoot.GetComponentsInChildren<VRCPhysBone>(true));
                physBoneColliders.AddRange(avatarRoot.GetComponentsInChildren<VRCPhysBoneCollider>(true));
                contactSenders.AddRange(avatarRoot.GetComponentsInChildren<VRCContactSender>(true));
                contactReceivers.AddRange(avatarRoot.GetComponentsInChildren<VRCContactReceiver>(true));

                physBones.Sort((left, right) => string.Compare(GetPath(left.transform), GetPath(right.transform), StringComparison.OrdinalIgnoreCase));
                physBoneColliders.Sort((left, right) => string.Compare(GetPath(left.transform), GetPath(right.transform), StringComparison.OrdinalIgnoreCase));
                contactSenders.Sort((left, right) => string.Compare(GetPath(left.transform), GetPath(right.transform), StringComparison.OrdinalIgnoreCase));
                contactReceivers.Sort((left, right) => string.Compare(GetPath(left.transform), GetPath(right.transform), StringComparison.OrdinalIgnoreCase));
            }

            if (selectedComponent != null && !AllComponents().Contains(selectedComponent))
                SelectComponent(null);
            if (sceneEditCollider == null) UpdateSceneEditColliderFromSelection();
            Repaint();
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (sceneView == null) return;

            if (sceneEditCollider != null)
            {
                DrawColliderSceneEditor(sceneView, sceneEditCollider);
            }
            if (showPhysBoneSceneGizmos && sceneEditPhysBone != null)
                DrawPhysBoneSceneGizmos(sceneEditPhysBone);

            if (!highlightSelectedObject || selectedComponent == null) return;
            Renderer[] renderers = selectedComponent.GetComponents<Renderer>();
            if (renderers.Length == 0)
            {
                Vector3 position = selectedComponent.transform.position;
                float size = HandleUtility.GetHandleSize(position) * 0.12f;
                DrawGlowMarker(position, size);
            }
            else
            {
                foreach (Renderer renderer in renderers)
                {
                    if (renderer == null) continue;
                    Bounds bounds = renderer.bounds;
                    DrawGlowWireCube(bounds.center, bounds.size);
                }
            }
        }

        private void DrawColliderSceneEditor(SceneView sceneView, VRCPhysBoneCollider collider)
        {
            if (collider == null || !collider.gameObject.scene.IsValid()) return;

            SerializedObject serializedCollider = new SerializedObject(collider);
            serializedCollider.Update();
            SerializedProperty positionProperty = FindColliderProperty(serializedCollider, "position");
            SerializedProperty rotationProperty = FindColliderProperty(serializedCollider, "rotation");
            SerializedProperty radiusProperty = FindColliderProperty(serializedCollider, "radius");
            SerializedProperty heightProperty = FindColliderProperty(serializedCollider, "height");
            SerializedProperty shapeProperty = FindSerializedPropertyByNames(serializedCollider, "shapeType", "shape");
            SerializedProperty rootProperty = FindSerializedPropertyByNames(serializedCollider, "rootTransform", "root");
            Transform referenceTransform = rootProperty != null && rootProperty.propertyType == SerializedPropertyType.ObjectReference
                ? rootProperty.objectReferenceValue as Transform : null;
            if (referenceTransform == null) referenceTransform = collider.transform;

            Vector3 localPosition = positionProperty != null && positionProperty.propertyType == SerializedPropertyType.Vector3
                ? positionProperty.vector3Value : Vector3.zero;
            Vector3 localEuler = rotationProperty != null && rotationProperty.propertyType == SerializedPropertyType.Vector3
                ? rotationProperty.vector3Value : Vector3.zero;
            Quaternion localRotation = Quaternion.Euler(localEuler);
            Quaternion worldRotation = referenceTransform.rotation * localRotation;
            Vector3 worldCenter = referenceTransform.TransformPoint(localPosition);
            float localRadius = radiusProperty != null && radiusProperty.propertyType == SerializedPropertyType.Float
                ? Mathf.Max(0f, radiusProperty.floatValue) : 0f;
            float localHeight = heightProperty != null && heightProperty.propertyType == SerializedPropertyType.Float
                ? Mathf.Max(0f, heightProperty.floatValue) : 0f;
            float radiusScale = GetColliderRadiusScale(referenceTransform);
            float axisScale = Mathf.Max(0.0001f, referenceTransform.TransformVector(localRotation * Vector3.up).magnitude);
            float worldRadius = localRadius * radiusScale;
            float worldHeight = localHeight * axisScale;
            string shapeName = GetColliderShapeName(shapeProperty);

            if (showColliderSceneGizmos)
                DrawColliderShape(worldCenter, worldRotation, worldRadius, worldHeight, shapeName);

            if (colliderEditTool == ColliderEditTool.PropertyEdit && enableColliderSceneEditing)
            {
                switch (colliderEditProperty)
                {
                    case ColliderEditProperty.Radius:
                        EditColliderRadius(collider, serializedCollider, radiusProperty, worldRotation, worldCenter, radiusScale, worldRadius, shapeName);
                        break;
                    case ColliderEditProperty.Height:
                        EditColliderHeight(collider, serializedCollider, heightProperty, worldCenter, worldRotation, worldRadius, worldHeight, axisScale, shapeName);
                        break;
                    case ColliderEditProperty.Position:
                        EditColliderPosition(collider, serializedCollider, positionProperty, referenceTransform, worldCenter, worldRotation);
                        break;
                    case ColliderEditProperty.Rotation:
                        EditColliderRotation(collider, serializedCollider, rotationProperty, referenceTransform, worldCenter, worldRotation);
                        break;
                }
            }

            serializedCollider.ApplyModifiedProperties();
            DrawColliderSceneControls(sceneView, shapeName);
        }

        private void DrawPhysBoneSceneGizmos(VRCPhysBone physBone)
        {
            if (physBone == null) return;
            Transform root = GetPhysBoneRoot(physBone);
            if (root == null) return;
            SerializedObject serialized = new SerializedObject(physBone);
            serialized.Update();
            SerializedProperty radiusProperty = FindColliderProperty(serialized, "radius");
            float localRadius = radiusProperty != null && radiusProperty.propertyType == SerializedPropertyType.Float
                ? Mathf.Max(0f, radiusProperty.floatValue) : 0.02f;
            Color oldColor = Handles.color;
            Handles.color = physBoneGizmoColor;
            Transform[] bones = root.GetComponentsInChildren<Transform>(true);
            foreach (Transform bone in bones)
            {
                if (bone == null) continue;
                if (bone != root && bone.parent != null)
                    Handles.DrawLine(bone.parent.position, bone.position);
                float radius = localRadius * GetColliderRadiusScale(bone);
                float diameter = Mathf.Max(0.003f, radius * 2f);
                Handles.color = new Color(physBoneGizmoColor.r, physBoneGizmoColor.g, physBoneGizmoColor.b, 0.11f);
                Handles.SphereHandleCap(GUIUtility.GetControlID(FocusType.Passive), bone.position, Quaternion.identity, diameter, EventType.Repaint);
                Handles.color = physBoneGizmoColor;
                Handles.DrawWireDisc(bone.position, Vector3.up, radius);
                Handles.DrawWireDisc(bone.position, Vector3.right, radius);
                Handles.DrawWireDisc(bone.position, Vector3.forward, radius);
            }
            Handles.color = oldColor;
        }

        private void DrawColliderShape(Vector3 center, Quaternion rotation, float radius, float height, string shapeName)
        {
            Color oldColor = Handles.color;
            Handles.color = new Color(colliderGizmoColor.r, colliderGizmoColor.g, colliderGizmoColor.b, 0.12f);
            if (shapeName.IndexOf("sphere", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Handles.SphereHandleCap(GUIUtility.GetControlID(FocusType.Passive), center, rotation,
                    Mathf.Max(0.001f, radius * 2f), EventType.Repaint);
            }
            else if (shapeName.IndexOf("plane", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Vector3 right = rotation * Vector3.right;
                Vector3 forward = rotation * Vector3.forward;
                float extent = Mathf.Max(radius, HandleUtility.GetHandleSize(center) * 0.35f);
                Handles.DrawSolidRectangleWithOutline(new[]
                {
                    center - right * extent - forward * extent,
                    center - right * extent + forward * extent,
                    center + right * extent + forward * extent,
                    center + right * extent - forward * extent
                }, new Color(colliderGizmoColor.r, colliderGizmoColor.g, colliderGizmoColor.b, 0.06f), colliderGizmoColor);
            }
            else
            {
                Vector3 axis = rotation * Vector3.up;
                float halfCylinder = Mathf.Max(0f, height * 0.5f - radius);
                Vector3 top = center + axis * halfCylinder;
                Vector3 bottom = center - axis * halfCylinder;
                Handles.SphereHandleCap(GUIUtility.GetControlID(FocusType.Passive), top, rotation,
                    Mathf.Max(0.001f, radius * 2f), EventType.Repaint);
                Handles.SphereHandleCap(GUIUtility.GetControlID(FocusType.Passive), bottom, rotation,
                    Mathf.Max(0.001f, radius * 2f), EventType.Repaint);
                Vector3 right = rotation * Vector3.right * radius;
                Vector3 forward = rotation * Vector3.forward * radius;
                Handles.DrawLine(top + right, bottom + right);
                Handles.DrawLine(top - right, bottom - right);
                Handles.DrawLine(top + forward, bottom + forward);
                Handles.DrawLine(top - forward, bottom - forward);
            }

            Handles.color = colliderGizmoColor;
            Handles.DrawWireDisc(center, rotation * Vector3.up, radius);
            Handles.DrawWireDisc(center, rotation * Vector3.right, radius);
            Handles.DrawWireDisc(center, rotation * Vector3.forward, radius);
            if (shapeName.IndexOf("capsule", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                Vector3 axis = rotation * Vector3.up;
                float halfCylinder = Mathf.Max(0f, height * 0.5f - radius);
                Handles.DrawWireDisc(center + axis * halfCylinder, axis, radius);
                Handles.DrawWireDisc(center - axis * halfCylinder, axis, radius);
            }
            Handles.color = oldColor;
        }

        private void EditColliderRadius(VRCPhysBoneCollider collider, SerializedObject serializedCollider,
            SerializedProperty radiusProperty, Quaternion worldRotation, Vector3 center, float radiusScale,
            float worldRadius, string shapeName)
        {
            if (radiusProperty == null || shapeName.IndexOf("plane", StringComparison.OrdinalIgnoreCase) >= 0) return;
            EditorGUI.BeginChangeCheck();
            float nextWorldRadius = Handles.RadiusHandle(worldRotation, center, worldRadius);
            if (!EditorGUI.EndChangeCheck()) return;

            Undo.RecordObject(collider, "Edit PhysBone Collider Radius");
            radiusProperty.floatValue = Mathf.Max(0f, nextWorldRadius / Mathf.Max(0.0001f, radiusScale));
            serializedCollider.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(collider);
            EditorUtility.SetDirty(collider);
        }

        private void EditColliderHeight(VRCPhysBoneCollider collider, SerializedObject serializedCollider,
            SerializedProperty heightProperty, Vector3 center, Quaternion worldRotation, float worldRadius,
            float worldHeight, float axisScale, string shapeName)
        {
            if (heightProperty == null || shapeName.IndexOf("capsule", StringComparison.OrdinalIgnoreCase) < 0) return;
            Vector3 axis = worldRotation * Vector3.up;
            float halfHeight = Mathf.Max(worldRadius, worldHeight * 0.5f);
            Vector3 handlePosition = center + axis * halfHeight;
            float handleSize = HandleUtility.GetHandleSize(handlePosition) * 0.08f;
            EditorGUI.BeginChangeCheck();
            Vector3 nextHandlePosition = Handles.Slider(handlePosition, axis, handleSize, Handles.ConeHandleCap, 0f);
            if (!EditorGUI.EndChangeCheck()) return;

            Undo.RecordObject(collider, "Edit PhysBone Collider Height");
            float nextWorldHeight = Mathf.Max(worldRadius * 2f, Vector3.Dot(nextHandlePosition - center, axis) * 2f);
            heightProperty.floatValue = nextWorldHeight / Mathf.Max(0.0001f, axisScale);
            serializedCollider.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(collider);
            EditorUtility.SetDirty(collider);
        }

        private void EditColliderPosition(VRCPhysBoneCollider collider, SerializedObject serializedCollider,
            SerializedProperty positionProperty, Transform referenceTransform, Vector3 center, Quaternion worldRotation)
        {
            if (positionProperty == null || positionProperty.propertyType != SerializedPropertyType.Vector3) return;
            EditorGUI.BeginChangeCheck();
            Vector3 nextPosition = Handles.PositionHandle(center, worldRotation);
            if (!EditorGUI.EndChangeCheck()) return;

            Undo.RecordObject(collider, "Edit PhysBone Collider Position");
            positionProperty.vector3Value = referenceTransform.InverseTransformPoint(nextPosition);
            serializedCollider.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(collider);
            EditorUtility.SetDirty(collider);
        }

        private void EditColliderRotation(VRCPhysBoneCollider collider, SerializedObject serializedCollider,
            SerializedProperty rotationProperty, Transform referenceTransform, Vector3 center, Quaternion worldRotation)
        {
            if (rotationProperty == null || rotationProperty.propertyType != SerializedPropertyType.Vector3) return;
            EditorGUI.BeginChangeCheck();
            Quaternion nextWorldRotation = Handles.RotationHandle(worldRotation, center);
            if (!EditorGUI.EndChangeCheck()) return;

            Undo.RecordObject(collider, "Edit PhysBone Collider Rotation");
            rotationProperty.vector3Value = (Quaternion.Inverse(referenceTransform.rotation) * nextWorldRotation).eulerAngles;
            serializedCollider.ApplyModifiedProperties();
            PrefabUtility.RecordPrefabInstancePropertyModifications(collider);
            EditorUtility.SetDirty(collider);
        }

        private void DrawColliderSceneControls(SceneView sceneView, string shapeName)
        {
            Handles.BeginGUI();
            float viewHeight = sceneView.position.height;
            Rect toolRect = new Rect(8f, viewHeight - 34f, 208f, 26f);
            GUI.Box(toolRect, GUIContent.none, EditorStyles.helpBox);
            GUI.Label(new Rect(toolRect.x + 8f, toolRect.y + 4f, 62f, 18f), "ADO Tool", EditorStyles.miniBoldLabel);
            int nextTool = EditorGUI.Popup(new Rect(toolRect.x + 70f, toolRect.y + 3f, 130f, 20f),
                (int)colliderEditTool, new[] { "Off", "Property Edit" });
            if (nextTool != (int)colliderEditTool)
            {
                colliderEditTool = (ColliderEditTool)nextTool;
                SaveSceneEditorSettings();
                sceneView.Repaint();
            }

            if (colliderEditTool == ColliderEditTool.PropertyEdit && enableColliderSceneEditing)
            {
                Rect panel = new Rect(Mathf.Max(220f, sceneView.position.width - 292f), viewHeight - 80f, 284f, 72f);
                GUI.Box(panel, GUIContent.none, EditorStyles.helpBox);
                GUI.Label(new Rect(panel.x + 8f, panel.y + 5f, 58f, 18f), "Editing", EditorStyles.miniBoldLabel);
                int nextProperty = EditorGUI.Popup(new Rect(panel.x + 64f, panel.y + 4f, 170f, 20f),
                    (int)colliderEditProperty, new[] { "Radius", "Height", "Position", "Rotation" });
                if (nextProperty != (int)colliderEditProperty)
                {
                    colliderEditProperty = (ColliderEditProperty)nextProperty;
                    sceneView.Repaint();
                }
                if (GUI.Button(new Rect(panel.x + 240f, panel.y + 4f, 36f, 20f), "⚙"))
                {
                    currentPage = Page.Settings;
                    Repaint();
                }
                string instruction = colliderEditProperty == ColliderEditProperty.Height &&
                                     shapeName.IndexOf("capsule", StringComparison.OrdinalIgnoreCase) < 0
                    ? "Height handles are available for Capsule colliders."
                    : "Drag the Scene handle. Use the Inspector for exact values.";
                GUI.Label(new Rect(panel.x + 8f, panel.y + 31f, panel.width - 16f, 32f), instruction, EditorStyles.miniLabel);
            }
            Handles.EndGUI();
        }

        private void UpdateSceneEditColliderFromSelection()
        {
            GameObject activeObject = Selection.activeGameObject;
            sceneEditCollider = activeObject != null ? activeObject.GetComponent<VRCPhysBoneCollider>() : null;
            sceneEditPhysBone = activeObject != null ? activeObject.GetComponent<VRCPhysBone>() : null;
        }

        private static SerializedProperty FindColliderProperty(SerializedObject serializedObject, string propertyName)
        {
            SerializedProperty property = serializedObject.FindProperty(propertyName);
            if (property != null) return property;
            if (string.IsNullOrEmpty(propertyName)) return null;
            string prefixedName = "m_" + char.ToUpperInvariant(propertyName[0]) + propertyName.Substring(1);
            return serializedObject.FindProperty(prefixedName);
        }

        private static string GetColliderShapeName(SerializedProperty shapeProperty)
        {
            if (!IsEnumProperty(shapeProperty) || shapeProperty.enumDisplayNames == null ||
                shapeProperty.enumValueIndex < 0 || shapeProperty.enumValueIndex >= shapeProperty.enumDisplayNames.Length)
                return "Capsule";
            return shapeProperty.enumDisplayNames[shapeProperty.enumValueIndex];
        }

        private static bool IsEnumProperty(SerializedProperty property)
        {
            return property != null && property.propertyType == SerializedPropertyType.Enum;
        }

        private static float GetColliderRadiusScale(Transform target)
        {
            Vector3 scale = target.lossyScale;
            return Mathf.Max(0.0001f, Mathf.Max(Mathf.Abs(scale.x), Mathf.Max(Mathf.Abs(scale.y), Mathf.Abs(scale.z))));
        }

        private void LoadSceneEditorSettings()
        {
            showColliderSceneGizmos = EditorPrefs.GetBool("Ninsa_ADO_ShowColliderGizmos", true);
            enableColliderSceneEditing = EditorPrefs.GetBool("Ninsa_ADO_EnableColliderSceneEditing", true);
            showPhysBoneSceneGizmos = EditorPrefs.GetBool("Ninsa_ADO_ShowPhysBoneGizmos", true);
            colliderEditTool = (ColliderEditTool)Mathf.Clamp(EditorPrefs.GetInt("Ninsa_ADO_ColliderEditTool", (int)ColliderEditTool.PropertyEdit), 0, 1);
            colliderEditProperty = (ColliderEditProperty)Mathf.Clamp(EditorPrefs.GetInt("Ninsa_ADO_ColliderEditProperty", (int)ColliderEditProperty.Radius), 0, 3);
            string color = EditorPrefs.GetString("Ninsa_ADO_ColliderGizmoColor", "#FF610FFF");
            if (ColorUtility.TryParseHtmlString(color, out Color loadedColor)) colliderGizmoColor = loadedColor;
            string physBoneColor = EditorPrefs.GetString("Ninsa_ADO_PhysBoneGizmoColor", "#40FF52FF");
            if (ColorUtility.TryParseHtmlString(physBoneColor, out Color loadedPhysBoneColor)) physBoneGizmoColor = loadedPhysBoneColor;
        }

        private void SaveSceneEditorSettings()
        {
            EditorPrefs.SetBool("Ninsa_ADO_ShowColliderGizmos", showColliderSceneGizmos);
            EditorPrefs.SetBool("Ninsa_ADO_EnableColliderSceneEditing", enableColliderSceneEditing);
            EditorPrefs.SetBool("Ninsa_ADO_ShowPhysBoneGizmos", showPhysBoneSceneGizmos);
            EditorPrefs.SetInt("Ninsa_ADO_ColliderEditTool", (int)colliderEditTool);
            EditorPrefs.SetInt("Ninsa_ADO_ColliderEditProperty", (int)colliderEditProperty);
            EditorPrefs.SetString("Ninsa_ADO_ColliderGizmoColor", "#" + ColorUtility.ToHtmlStringRGBA(colliderGizmoColor));
            EditorPrefs.SetString("Ninsa_ADO_PhysBoneGizmoColor", "#" + ColorUtility.ToHtmlStringRGBA(physBoneGizmoColor));
        }

        private void DrawGlowMarker(Vector3 center, float radius)
        {
            Color previousColor = Handles.color;
            Handles.color = new Color(highlightColor.r, highlightColor.g, highlightColor.b, 0.18f);
            DrawGlowRingSet(center, radius * 1.3f);
            Handles.color = new Color(highlightColor.r, highlightColor.g, highlightColor.b, 0.42f);
            DrawGlowRingSet(center, radius * 1.1f);
            Handles.color = highlightColor;
            DrawGlowRingSet(center, radius * 0.9f);
            Handles.color = previousColor;
        }

        private void DrawGlowWireCube(Vector3 center, Vector3 size)
        {
            Color previousColor = Handles.color;
            float padding = Mathf.Max(0.008f, HandleUtility.GetHandleSize(center) * 0.008f);
            Handles.color = new Color(highlightColor.r, highlightColor.g, highlightColor.b, 0.18f);
            Handles.DrawWireCube(center, size + Vector3.one * padding * 5f);
            Handles.color = new Color(highlightColor.r, highlightColor.g, highlightColor.b, 0.42f);
            Handles.DrawWireCube(center, size + Vector3.one * padding * 2.5f);
            Handles.color = highlightColor;
            Handles.DrawWireCube(center, size + Vector3.one * padding * 0.5f);
            Handles.color = previousColor;
        }

        private static void DrawGlowRingSet(Vector3 center, float radius)
        {
            Handles.DrawWireDisc(center, Vector3.up, radius);
            Handles.DrawWireDisc(center, Vector3.right, radius);
            Handles.DrawWireDisc(center, Vector3.forward, radius);
        }

        private List<GameObject> GetTopLevelSelectedObjects()
        {
            GameObject[] selected = Selection.gameObjects ?? new GameObject[0];
            HashSet<GameObject> selectionSet = new HashSet<GameObject>(selected.Where(item => item != null));
            List<GameObject> topLevel = new List<GameObject>();

            foreach (GameObject item in selectionSet)
            {
                if (EditorUtility.IsPersistent(item)) continue;
                bool hasSelectedAncestor = false;
                Transform parent = item.transform.parent;
                while (parent != null)
                {
                    if (selectionSet.Contains(parent.gameObject))
                    {
                        hasSelectedAncestor = true;
                        break;
                    }
                    parent = parent.parent;
                }

                if (!hasSelectedAncestor) topLevel.Add(item);
            }

            topLevel.Sort((left, right) => string.Compare(GetPath(left.transform), GetPath(right.transform), StringComparison.OrdinalIgnoreCase));
            return topLevel;
        }

        private void ForceDeleteSelectedObjects()
        {
            List<GameObject> targets = GetTopLevelSelectedObjects();
            if (targets.Count == 0) return;

            string names = string.Join("\n", targets.Take(5).Select(item => "• " + GetPath(item.transform)).ToArray());
            if (targets.Count > 5) names += "\n• and " + (targets.Count - 5) + " more";
            if (!EditorUtility.DisplayDialog(
                    "Force Delete Selected Objects",
                    "Delete " + targets.Count + " selected scene object(s) and their children?\n\n" + names + "\n\nThis action can be undone.",
                    "Delete", "Cancel"))
                return;

            bool deletesInspectedObject = selectedComponent != null && targets.Any(item =>
                selectedComponent.transform == item.transform || selectedComponent.transform.IsChildOf(item.transform));

            if (deletesInspectedObject) SelectComponent(null);
            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Force Delete Selected Objects");
            foreach (GameObject target in targets)
                if (target != null) Undo.DestroyObjectImmediate(target);
            Undo.CollapseUndoOperations(undoGroup);

            Selection.objects = new UnityEngine.Object[0];
            ScanAvatar();
            SceneView.RepaintAll();
        }

        private IEnumerable<Component> AllComponents()
        {
            return physBones.Cast<Component>()
                .Concat(physBoneColliders.Cast<Component>())
                .Concat(contactSenders.Cast<Component>())
                .Concat(contactReceivers.Cast<Component>());
        }

        private void TryUseCurrentSelection()
        {
            GameObject selectedObject = Selection.activeGameObject;
            if (selectedObject == null) return;

            VRCAvatarDescriptor descriptor = selectedObject.GetComponentInParent<VRCAvatarDescriptor>();
            SetAvatarRoot(descriptor != null ? descriptor.gameObject : selectedObject.transform.root.gameObject);
        }

        private void SetAvatarRoot(GameObject root)
        {
            if (avatarRoot == root) return;
            avatarRoot = root;
            generatorAnimator = avatarRoot != null ? avatarRoot.GetComponentInChildren<Animator>(true) : null;
            generatorTargetPhysBone = null;
            generatorNewPhysBoneObject = null;
            generatedColliders.Clear();
            legacyCandidates.Clear();
        }

        private void AddComponentToSelection(Type componentType)
        {
            GameObject target = Selection.activeGameObject;
            if (target == null)
            {
                EditorUtility.DisplayDialog("Select an object", "Select a GameObject first.", "OK");
                return;
            }

            if (target.GetComponent(componentType) != null)
            {
                EditorUtility.DisplayDialog("Component already exists", target.name + " already has a " + componentType.Name + " component.", "OK");
                return;
            }

            Component added = Undo.AddComponent(target, componentType);
            if (added == null)
            {
                EditorUtility.DisplayDialog("Could not add component", "Unity could not add " + componentType.Name + " to this object.", "OK");
                return;
            }

            if (avatarRoot == null || (target.transform != avatarRoot.transform && !target.transform.IsChildOf(avatarRoot.transform)))
                SetAvatarRoot(target.transform.root.gameObject);

            PrefabUtility.RecordPrefabInstancePropertyModifications(added);
            ScanAvatar();
            SelectComponent(added);
            currentPage = GetPageForComponent(added);
        }

        private static Page GetPageForComponent(Component component)
        {
            if (component is VRCPhysBone) return Page.PhysBones;
            if (component is VRCPhysBoneCollider) return Page.Colliders;
            if (component is VRCContactSender || component is VRCContactReceiver) return Page.Contacts;
            return Page.Overview;
        }

        private static string GetFriendlyTypeName(Component component)
        {
            if (component is VRCPhysBone) return "PhysBone";
            if (component is VRCPhysBoneCollider) return "PhysBone Collider";
            if (component is VRCContactSender) return "Contact Sender";
            if (component is VRCContactReceiver) return "Contact Receiver";
            return component != null ? component.GetType().Name : "Dynamics Component";
        }

        private string GetPath(Transform target)
        {
            if (target == null) return "";

            List<string> segments = new List<string>();
            Transform current = target;
            while (current != null)
            {
                segments.Add(current.name);
                if (avatarRoot != null && current == avatarRoot.transform) break;
                current = current.parent;
            }
            segments.Reverse();
            return string.Join("/", segments.ToArray());
        }

        private static Component ConvertComponent(Component source, Type targetType, bool confirm)
        {
            if (source == null || targetType == null || !typeof(Component).IsAssignableFrom(targetType)) return null;
            if (source.GetType() == targetType) return source;
            if (EditorUtility.IsPersistent(source))
            {
                EditorUtility.DisplayDialog("Scene Object Required", "Convert dynamics components on an avatar in the scene or Prefab Mode.", "OK");
                return null;
            }

            if (source.gameObject.GetComponent(targetType) != null)
            {
                EditorUtility.DisplayDialog(
                    "Conversion Not Applied",
                    source.gameObject.name + " already has a " + targetType.Name + " component. The original component was left in place.",
                    "OK");
                return null;
            }

            string sourceName = GetFriendlyTypeName(source);
            string targetName = targetType == typeof(VRCPhysBoneCollider) ? "PhysBone Collider" : targetType.Name;
            if (confirm && !EditorUtility.DisplayDialog(
                    "Convert Dynamics Component",
                    "Convert " + sourceName + " to " + targetName + " on " + source.gameObject.name + "? Matching settings will be copied; fields the target type does not support will be lost. This can be undone.",
                    "Convert", "Cancel"))
                return null;

            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Convert " + sourceName);

            Component replacement = Undo.AddComponent(source.gameObject, targetType);
            if (replacement == null)
            {
                EditorUtility.DisplayDialog("Conversion Failed", "Unity could not add " + targetName + ". The original component was left in place.", "OK");
                return null;
            }

            CopyMatchingSerializedProperties(source, replacement);
            PrefabUtility.RecordPrefabInstancePropertyModifications(replacement);
            EditorUtility.SetDirty(replacement);
            Undo.DestroyObjectImmediate(source);
            Undo.CollapseUndoOperations(undoGroup);

            Selection.activeGameObject = replacement.gameObject;
            EditorGUIUtility.PingObject(replacement.gameObject);
            NotifyOpenWindows(replacement);
            return replacement;
        }

        private static VRCPhysBoneCollider MoveColliderToChild(VRCPhysBoneCollider source, bool confirm)
        {
            if (source == null) return null;
            if (EditorUtility.IsPersistent(source))
            {
                EditorUtility.DisplayDialog("Scene Object Required", "Move colliders on an avatar in the scene or Prefab Mode.", "OK");
                return null;
            }
            if (confirm && !EditorUtility.DisplayDialog(
                    "Move Collider To Child",
                    "Create a child object for this collider and remove it from the current object? The new child keeps the current local transform and collider settings. This can be undone.",
                    "Move", "Cancel"))
                return null;

            Undo.IncrementCurrentGroup();
            int undoGroup = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName("Move PhysBone Collider To Child");

            GameObject child = new GameObject(source.gameObject.name + " Collider");
            Undo.RegisterCreatedObjectUndo(child, "Create Collider Child");
            child.transform.SetParent(source.transform, false);

            VRCPhysBoneCollider replacement = Undo.AddComponent<VRCPhysBoneCollider>(child);
            if (replacement == null)
            {
                Undo.DestroyObjectImmediate(child);
                return null;
            }

            CopyMatchingSerializedProperties(source, replacement);
            PrefabUtility.RecordPrefabInstancePropertyModifications(child.transform);
            PrefabUtility.RecordPrefabInstancePropertyModifications(replacement);
            Undo.DestroyObjectImmediate(source);
            Undo.CollapseUndoOperations(undoGroup);

            Selection.activeGameObject = child;
            EditorGUIUtility.PingObject(child);
            NotifyOpenWindows(replacement);
            return replacement;
        }

        private static void NotifyOpenWindows(Component selected)
        {
            AvatarDynamicsOverhaulWindow[] windows = Resources.FindObjectsOfTypeAll<AvatarDynamicsOverhaulWindow>();
            foreach (AvatarDynamicsOverhaulWindow window in windows)
            {
                if (window == null) continue;
                window.ScanAvatar();
                window.SelectComponent(selected);
                window.currentPage = GetPageForComponent(selected);
            }
        }

        private static void CopyMatchingSerializedProperties(Component source, Component destination)
        {
            SerializedObject sourceObject = new SerializedObject(source);
            SerializedObject destinationObject = new SerializedObject(destination);
            sourceObject.Update();
            destinationObject.Update();

            SerializedProperty iterator = sourceObject.GetIterator();
            bool enterChildren = true;
            while (iterator.Next(enterChildren))
            {
                enterChildren = false;
                if (iterator.propertyPath == "m_Script") continue;

                SerializedProperty destinationProperty = destinationObject.FindProperty(iterator.propertyPath);
                if (destinationProperty == null || destinationProperty.propertyType != iterator.propertyType) continue;

                if (iterator.propertyType == SerializedPropertyType.Enum)
                {
                    string sourceEnumName = iterator.enumValueIndex >= 0 && iterator.enumValueIndex < iterator.enumNames.Length
                        ? iterator.enumNames[iterator.enumValueIndex]
                        : null;
                    if (string.IsNullOrEmpty(sourceEnumName)) continue;

                    int matchingIndex = Array.IndexOf(destinationProperty.enumNames, sourceEnumName);
                    if (matchingIndex >= 0) destinationProperty.enumValueIndex = matchingIndex;
                    continue;
                }

                try
                {
                    destinationObject.CopyFromSerializedProperty(iterator);
                }
                catch (Exception exception)
                {
                    Debug.LogWarning("Skipped incompatible dynamics property '" + iterator.propertyPath + "': " + exception.Message, destination);
                }
            }

            destinationObject.ApplyModifiedProperties();
        }

        [MenuItem("CONTEXT/VRCPhysBoneCollider/NINSA/Move To Child", false, 896)]
        private static void ContextMoveColliderToChild(MenuCommand command)
        {
            MoveColliderToChild(command.context as VRCPhysBoneCollider, true);
        }

        [MenuItem("CONTEXT/VRCPhysBoneCollider/NINSA/Convert To Contact Sender", false, 897)]
        private static void ContextColliderToSender(MenuCommand command)
        {
            ConvertComponent(command.context as VRCPhysBoneCollider, typeof(VRCContactSender), true);
        }

        [MenuItem("CONTEXT/VRCPhysBoneCollider/NINSA/Convert To Contact Receiver", false, 898)]
        private static void ContextColliderToReceiver(MenuCommand command)
        {
            ConvertComponent(command.context as VRCPhysBoneCollider, typeof(VRCContactReceiver), true);
        }

        [MenuItem("CONTEXT/VRCContactSender/NINSA/Convert To Receiver", false, 897)]
        private static void ContextSenderToReceiver(MenuCommand command)
        {
            ConvertComponent(command.context as VRCContactSender, typeof(VRCContactReceiver), true);
        }

        [MenuItem("CONTEXT/VRCContactSender/NINSA/Convert To Collider", false, 898)]
        private static void ContextSenderToCollider(MenuCommand command)
        {
            ConvertComponent(command.context as VRCContactSender, typeof(VRCPhysBoneCollider), true);
        }

        [MenuItem("CONTEXT/VRCContactReceiver/NINSA/Convert To Sender", false, 897)]
        private static void ContextReceiverToSender(MenuCommand command)
        {
            ConvertComponent(command.context as VRCContactReceiver, typeof(VRCContactSender), true);
        }

        [MenuItem("CONTEXT/VRCContactReceiver/NINSA/Convert To Collider", false, 898)]
        private static void ContextReceiverToCollider(MenuCommand command)
        {
            ConvertComponent(command.context as VRCContactReceiver, typeof(VRCPhysBoneCollider), true);
        }
    }

    [CustomEditor(typeof(VRCPhysBone), true)]
    [CanEditMultipleObjects]
    public sealed class AvatarDynamicsOverhaulPhysBoneInspector : UnityEditor.Editor
    {
        private static readonly string[] SectionOrder =
        {
            "Transforms", "Forces", "Limits", "Collisions", "Grab & Pose", "Stretch & Squish", "Options", "Gizmos"
        };

        private static readonly Dictionary<string, bool> SectionFoldouts = new Dictionary<string, bool>();

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Avatar Dynamics Overhaul", EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Open ADO", EditorStyles.miniButton, GUILayout.Width(76f)))
            {
                VRCPhysBone physBone = target as VRCPhysBone;
                if (physBone != null) AvatarDynamicsOverhaulWindow.OpenForAvatar(physBone.transform.root.gameObject);
            }
            EditorGUILayout.EndHorizontal();

            Dictionary<string, List<SerializedProperty>> sections = new Dictionary<string, List<SerializedProperty>>();
            foreach (string section in SectionOrder) sections[section] = new List<SerializedProperty>();

            SerializedProperty iterator = serializedObject.GetIterator();
            bool enterChildren = true;
            while (iterator.NextVisible(enterChildren))
            {
                enterChildren = false;
                if (iterator.propertyPath == "m_Script") continue;
                string section = GetSection(iterator.name);
                sections[section].Add(iterator.Copy());
            }

            foreach (string section in SectionOrder)
            {
                List<SerializedProperty> properties = sections[section];
                if (properties.Count == 0) continue;

                bool expanded;
                if (!SectionFoldouts.TryGetValue(section, out expanded)) expanded = true;
                expanded = EditorGUILayout.BeginFoldoutHeaderGroup(expanded, section);
                SectionFoldouts[section] = expanded;
                if (expanded)
                {
                    EditorGUI.indentLevel++;
                    foreach (SerializedProperty property in properties)
                        EditorGUILayout.PropertyField(property, true);
                    EditorGUI.indentLevel--;
                }
                EditorGUILayout.EndFoldoutHeaderGroup();
            }

            serializedObject.ApplyModifiedProperties();
        }

        private static string GetSection(string fieldName)
        {
            string field = fieldName.ToLowerInvariant();
            if (ContainsAny(field, "root", "endpoint", "multichild", "ignoretransform", "integration")) return "Transforms";
            if (ContainsAny(field, "pull", "spring", "stiff", "elastic", "damp", "friction", "immobile", "gravity", "falloff")) return "Forces";
            if (ContainsAny(field, "limit", "angle")) return "Limits";
            if (ContainsAny(field, "collider", "collision", "radius")) return "Collisions";
            if (ContainsAny(field, "grab", "posing", "pose", "snap", "movement")) return "Grab & Pose";
            if (ContainsAny(field, "stretch", "squish")) return "Stretch & Squish";
            if (ContainsAny(field, "gizmo", "opacity")) return "Gizmos";
            return "Options";
        }

        private static bool ContainsAny(string value, params string[] fragments)
        {
            foreach (string fragment in fragments)
                if (value.Contains(fragment)) return true;
            return false;
        }
    }
}
